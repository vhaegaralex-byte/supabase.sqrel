import { sql } from "drizzle-orm";
import type { SiteContent } from "@/lib/studio-types";
import {
  boolean,
  check,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    email: varchar("email", { length: 255 }).notNull().unique(),
    name: varchar("name", { length: 80 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    role: varchar("role", { length: 16 }).notNull().default("player"),
    balanceCents: integer("balance_cents").notNull().default(0),
    referralCode: varchar("referral_code", { length: 24 }).notNull().unique(),
    referredBy: uuid("referred_by"),
    referralRewardedAt: timestamp("referral_rewarded_at", { withTimezone: true }),
    ageConfirmed: boolean("age_confirmed").notNull().default(false),
    isSuspended: boolean("is_suspended").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("users_referred_by_idx").on(table.referredBy),
    check("users_balance_nonnegative", sql`${table.balanceCents} >= 0`),
  ],
);

export const sessions = pgTable(
  "sessions",
  {
    tokenHash: varchar("token_hash", { length: 64 }).primaryKey(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("sessions_user_idx").on(table.userId)],
);

export const platformSettings = pgTable("platform_settings", {
  id: integer("id").primaryKey(),
  winRate: integer("win_rate").notNull().default(42),
  bankrollCents: integer("bankroll_cents").notNull().default(0),
  referralBonusCents: integer("referral_bonus_cents").notNull().default(500),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  check("platform_bankroll_nonnegative", sql`${table.bankrollCents} >= 0`),
  check("platform_win_rate_range", sql`${table.winRate} >= 1 AND ${table.winRate} <= 75`),
]);

export const walletRequests = pgTable(
  "wallet_requests",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    kind: varchar("kind", { length: 16 }).notNull(),
    amountCents: integer("amount_cents").notNull(),
    status: varchar("status", { length: 16 }).notNull().default("pending"),
    method: varchar("method", { length: 32 }).notNull(),
    reference: varchar("reference", { length: 120 }),
    payoutDetails: text("payout_details"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  },
  (table) => [
    index("wallet_requests_user_idx").on(table.userId),
    index("wallet_requests_status_idx").on(table.status),
    check("wallet_requests_positive", sql`${table.amountCents} > 0`),
  ],
);

export const ledgerEntries = pgTable(
  "ledger_entries",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    kind: varchar("kind", { length: 32 }).notNull(),
    amountCents: integer("amount_cents").notNull(),
    description: varchar("description", { length: 180 }).notNull(),
    relatedId: uuid("related_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("ledger_entries_user_created_idx").on(table.userId, table.createdAt)],
);

export const gamePlays = pgTable(
  "game_plays",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    game: varchar("game", { length: 20 }).notNull(),
    betCents: integer("bet_cents").notNull(),
    payoutCents: integer("payout_cents").notNull().default(0),
    winRate: integer("win_rate").notNull(),
    won: boolean("won").notNull(),
    status: varchar("status", { length: 16 }).notNull().default("settled"),
    // Hidden while active: only the server knows when this round will crash.
    crashMultiplierBps: integer("crash_multiplier_bps").notNull().default(10000),
    cashoutMultiplierBps: integer("cashout_multiplier_bps"),
    reservedPayoutCents: integer("reserved_payout_cents").notNull().default(0),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    endsAt: timestamp("ends_at", { withTimezone: true }).notNull().defaultNow(),
    settledAt: timestamp("settled_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("game_plays_user_created_idx").on(table.userId, table.createdAt),
    index("game_plays_status_ends_idx").on(table.status, table.endsAt),
    uniqueIndex("game_plays_one_active_per_user").on(table.userId).where(sql`${table.status} = 'active'`),
    check("game_plays_reserved_nonnegative", sql`${table.reservedPayoutCents} >= 0`),
  ],
);

export const surveyCompletions = pgTable(
  "survey_completions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    surveyId: varchar("survey_id", { length: 48 }).notNull(),
    answers: jsonb("answers").$type<number[]>().notNull(),
    rewardCents: integer("reward_cents").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [uniqueIndex("survey_completions_user_survey_idx").on(table.userId, table.surveyId)],
);

export const studioSessions = pgTable("studio_sessions", {
  tokenHash: varchar("token_hash", { length: 64 }).primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [index("studio_sessions_user_idx").on(table.userId)]);

export const siteContent = pgTable("site_content", {
  id: integer("id").primaryKey(),
  draft: jsonb("draft").$type<SiteContent>().notNull(),
  published: jsonb("published").$type<SiteContent>().notNull(),
  version: integer("version").notNull().default(1),
  draftUpdatedAt: timestamp("draft_updated_at", { withTimezone: true }).notNull().defaultNow(),
  publishedAt: timestamp("published_at", { withTimezone: true }),
  publishedBy: uuid("published_by").references(() => users.id, { onDelete: "set null" }),
});

export const studioLoginAttempts = pgTable("studio_login_attempts", {
  email: varchar("email", { length: 255 }).primaryKey(),
  attempts: integer("attempts").notNull().default(0),
  lockedUntil: timestamp("locked_until", { withTimezone: true }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const studioInvites = pgTable("studio_invites", {
  tokenHash: varchar("token_hash", { length: 64 }).primaryKey(),
  email: varchar("email", { length: 255 }).notNull(),
  createdBy: uuid("created_by").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  usedAt: timestamp("used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [index("studio_invites_email_idx").on(table.email)]);

export const featureRequests = pgTable("feature_requests", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: varchar("title", { length: 100 }).notNull(),
  description: text("description").notNull(),
  priority: varchar("priority", { length: 16 }).notNull().default("medium"),
  status: varchar("status", { length: 20 }).notNull().default("idea"),
  assistantPlan: text("assistant_plan"),
  createdBy: uuid("created_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [index("feature_requests_created_idx").on(table.createdAt)]);

export const studioAudit = pgTable("studio_audit", {
  id: uuid("id").defaultRandom().primaryKey(),
  actorId: uuid("actor_id").references(() => users.id, { onDelete: "set null" }),
  action: varchar("action", { length: 48 }).notNull(),
  details: varchar("details", { length: 240 }).notNull(),
  targetId: uuid("target_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [index("studio_audit_created_idx").on(table.createdAt)]);
