import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { StudioApp } from "@/components/studio-app";
import { getStudioUser } from "@/lib/security";
import { loadStudioData } from "@/lib/studio-data";

export const dynamic = "force-dynamic";

export default async function StudioPage({ searchParams }: { searchParams: Promise<{ invite?: string; email?: string }> }) {
  const operator = await getStudioUser();
  const [counts, params] = await Promise.all([
    db.select({ count: sql<number>`count(*)::int` }).from(users).where(eq(users.role, "admin")),
    searchParams,
  ]);
  const initialData = operator ? await loadStudioData() : null;
  return <StudioApp
    initialData={initialData}
    needsSetup={counts[0]?.count === 0}
    setupConfigured={Boolean(process.env.STUDIO_SETUP_CODE || process.env.ADMIN_SETUP_CODE)}
    invitation={{ code: params.invite || "", email: params.email || "" }}
  />;
}
