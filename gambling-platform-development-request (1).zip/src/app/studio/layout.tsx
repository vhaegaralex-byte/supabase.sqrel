import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./studio.css";

export const metadata: Metadata = {
  title: "Lumi Studio — Operator workspace",
  description: "Private management workspace for LumiPlay operators.",
  robots: { index: false, follow: false },
};

export default function StudioLayout({ children }: { children: ReactNode }) {
  return <div className="studio-root">{children}</div>;
}
