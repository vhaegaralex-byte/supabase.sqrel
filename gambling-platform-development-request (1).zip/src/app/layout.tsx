import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import "./live-game.css";

export const metadata: Metadata = {
  title: "LumiPlay — Play your way",
  description: "Explore instant games, complete questionnaires, and manage your wallet in one clear, privacy-minded place. 18+ only.",
  robots: { index: false, follow: false },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
