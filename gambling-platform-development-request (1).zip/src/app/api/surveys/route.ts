import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { ledgerEntries, platformSettings, surveyCompletions, users } from "@/db/schema";
import { ensureSettings } from "@/lib/dashboard";
import { getPublishedContent } from "@/lib/site-content";
import { assertSameOrigin, fail, handleActionError, requireUser } from "@/lib/security";
import { surveys } from "@/lib/shared";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const user = await requireUser();
    if (!(await getPublishedContent()).surveysEnabled) fail("Questionnaires are temporarily unavailable.", 409);
    const body = await request.json() as Record<string, unknown>;
    const survey = surveys.find((item) => item.id === body.surveyId);
    if (!survey) fail("That questionnaire is not available.");
    const answers = body.answers;
    if (!Array.isArray(answers) || answers.length !== survey.questions.length ||
      !answers.every((answer, index) => Number.isInteger(answer) && answer >= 0 && answer < survey.questions[index].options.length)) {
      fail("Please answer every question.");
    }
    await ensureSettings();
    await db.transaction(async (tx) => {
      await tx.execute(sql`select id from platform_settings where id = 1 for update`);
      const [completed] = await tx.select({ id: surveyCompletions.id }).from(surveyCompletions)
        .where(and(eq(surveyCompletions.userId, user.id), eq(surveyCompletions.surveyId, survey.id))).limit(1);
      if (completed) fail("You already completed this questionnaire.", 409);
      const [settings] = await tx.select().from(platformSettings).where(eq(platformSettings.id, 1)).limit(1);
      if (settings.bankrollCents < survey.rewardCents) fail("This reward is temporarily unavailable. Please check back soon.", 409);
      const [completion] = await tx.insert(surveyCompletions).values({
        userId: user.id, surveyId: survey.id, answers: answers as number[], rewardCents: survey.rewardCents,
      }).returning({ id: surveyCompletions.id });
      await tx.update(platformSettings).set({
        bankrollCents: sql`${platformSettings.bankrollCents} - ${survey.rewardCents}`,
        updatedAt: new Date(),
      }).where(eq(platformSettings.id, 1));
      await tx.update(users).set({ balanceCents: sql`${users.balanceCents} + ${survey.rewardCents}` }).where(eq(users.id, user.id));
      await tx.insert(ledgerEntries).values({
        userId: user.id, kind: "survey", amountCents: survey.rewardCents,
        description: `${survey.title} · questionnaire reward`, relatedId: completion.id,
      });
    });
    return Response.json({ ok: true, rewardCents: survey.rewardCents });
  } catch (error) {
    return handleActionError(error);
  }
}
