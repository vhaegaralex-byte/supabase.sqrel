import { and, asc, eq, gte, isNotNull, isNull, sql } from "drizzle-orm";
import { db } from "@/db";
import { ledgerEntries, platformSettings, studioAudit, users, walletRequests } from "@/db/schema";
import { ensureSettings } from "@/lib/dashboard";
import { assertSameOrigin, fail, handleActionError, parseCents, requireAdmin } from "@/lib/security";
import { REFERRAL_QUALIFYING_DEPOSIT_CENTS } from "@/lib/shared";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const admin = await requireAdmin();
    const body = await request.json() as Record<string, unknown>;
    await ensureSettings();

    if (body.action === "rate") {
      const rate = Number(body.rate);
      if (!Number.isInteger(rate) || rate < 1 || rate > 75) fail("Choose a win chance between 1% and 75%.");
      await db.transaction(async (tx) => {
        await tx.update(platformSettings).set({ winRate: rate, updatedAt: new Date() }).where(eq(platformSettings.id, 1));
        await tx.insert(studioAudit).values({ actorId: admin.id, action: "odds_update", details: `Changed chance to reach 1.80× to ${rate}%` });
      });
      return Response.json({ ok: true, message: `Win chance updated to ${rate}%.` });
    }

    if (body.action === "referral_bonus") {
      const amountCents = parseCents(body.amount);
      if (amountCents < 100 || amountCents > 2_500) fail("Choose a referral reward between $1 and $25.");
      await db.transaction(async (tx) => {
        await tx.update(platformSettings).set({ referralBonusCents: amountCents, updatedAt: new Date() }).where(eq(platformSettings.id, 1));
        await tx.insert(studioAudit).values({ actorId: admin.id, action: "referral_bonus", details: `Set future referral rewards to $${(amountCents / 100).toFixed(2)}` });
      });
      return Response.json({ ok: true, message: "Referral reward updated for future qualifying referrals." });
    }

    if (body.action === "fund") {
      const amountCents = parseCents(body.amount);
      if (amountCents < 100 || amountCents > 100_000_000) fail("Record an amount between $1 and $1,000,000.");
      let bonusesPaid = 0;
      await db.transaction(async (tx) => {
        await tx.execute(sql`select id from platform_settings where id = 1 for update`);
        const [current] = await tx.select().from(platformSettings).where(eq(platformSettings.id, 1)).limit(1);
        let available = current.bankrollCents + amountCents;
        await tx.update(platformSettings).set({ bankrollCents: available, updatedAt: new Date() }).where(eq(platformSettings.id, 1));
        await tx.insert(ledgerEntries).values({
          userId: admin.id, kind: "bankroll_funding", amountCents,
          description: "Operator · verified prize pool funding",
        });
        await tx.insert(studioAudit).values({ actorId: admin.id, action: "pool_funding",
          details: `Recorded $${(amountCents / 100).toFixed(2)} of verified external prize-pool funding` });

        const pendingReferrals = await tx.select({ id: users.id, referredBy: users.referredBy })
          .from(users).where(and(isNotNull(users.referredBy), isNull(users.referralRewardedAt)))
          .orderBy(asc(users.createdAt)).limit(100);
        for (const referred of pendingReferrals) {
          if (!referred.referredBy || available < current.referralBonusCents) break;
          const [qualifyingDeposit] = await tx.select({ id: walletRequests.id }).from(walletRequests)
            .where(and(
              eq(walletRequests.userId, referred.id), eq(walletRequests.kind, "deposit"),
              eq(walletRequests.status, "approved"), gte(walletRequests.amountCents, REFERRAL_QUALIFYING_DEPOSIT_CENTS),
            )).limit(1);
          if (!qualifyingDeposit) continue;
          const [referrer] = await tx.update(users).set({
            balanceCents: sql`${users.balanceCents} + ${current.referralBonusCents}`,
          }).where(eq(users.id, referred.referredBy)).returning({ id: users.id });
          if (!referrer) continue;
          await tx.update(users).set({ referralRewardedAt: new Date() }).where(eq(users.id, referred.id));
          await tx.update(platformSettings).set({
            bankrollCents: sql`${platformSettings.bankrollCents} - ${current.referralBonusCents}`,
          }).where(eq(platformSettings.id, 1));
          await tx.insert(ledgerEntries).values({
            userId: referrer.id, kind: "referral", amountCents: current.referralBonusCents,
            description: "Referral reward · friend’s first approved deposit", relatedId: qualifyingDeposit.id,
          });
          available -= current.referralBonusCents;
          bonusesPaid++;
        }
      });
      return Response.json({ ok: true, message: `Funding recorded.${bonusesPaid ? ` ${bonusesPaid} pending referral reward${bonusesPaid === 1 ? "" : "s"} paid.` : ""}` });
    }

    if (body.action === "review") {
      const id = typeof body.id === "string" ? body.id : "";
      const decision = body.decision;
      if (!/^[0-9a-f-]{36}$/i.test(id) || (decision !== "approve" && decision !== "reject")) fail("Choose a valid request and decision.");
      await db.transaction(async (tx) => {
        await tx.execute(sql`select id from platform_settings where id = 1 for update`);
        await tx.execute(sql`select id from wallet_requests where id = ${id}::uuid for update`);
        const [item] = await tx.select().from(walletRequests).where(eq(walletRequests.id, id)).limit(1);
        if (!item || item.status !== "pending") fail("This request has already been reviewed or no longer exists.", 409);

        if (item.kind === "deposit") {
          if (decision === "approve") {
            await tx.update(users).set({ balanceCents: sql`${users.balanceCents} + ${item.amountCents}` }).where(eq(users.id, item.userId));
            await tx.insert(ledgerEntries).values({
              userId: item.userId, kind: "deposit", amountCents: item.amountCents,
              description: "Deposit · approved by operator", relatedId: item.id,
            });
          }
          await tx.update(walletRequests).set({ status: decision === "approve" ? "approved" : "rejected", reviewedAt: new Date() }).where(eq(walletRequests.id, item.id));

          if (decision === "approve" && item.amountCents >= REFERRAL_QUALIFYING_DEPOSIT_CENTS) {
            const [referred] = await tx.select({ referredBy: users.referredBy, rewardedAt: users.referralRewardedAt })
              .from(users).where(eq(users.id, item.userId)).limit(1);
            const [settings] = await tx.select().from(platformSettings).where(eq(platformSettings.id, 1)).limit(1);
            if (referred?.referredBy && !referred.rewardedAt && settings.bankrollCents >= settings.referralBonusCents) {
              const [referrer] = await tx.update(users).set({
                balanceCents: sql`${users.balanceCents} + ${settings.referralBonusCents}`,
              }).where(eq(users.id, referred.referredBy)).returning({ id: users.id });
              if (referrer) {
                await tx.update(users).set({ referralRewardedAt: new Date() }).where(eq(users.id, item.userId));
                await tx.update(platformSettings).set({
                  bankrollCents: sql`${platformSettings.bankrollCents} - ${settings.referralBonusCents}`,
                }).where(eq(platformSettings.id, 1));
                await tx.insert(ledgerEntries).values({
                  userId: referrer.id, kind: "referral", amountCents: settings.referralBonusCents,
                  description: "Referral reward · friend’s first approved deposit", relatedId: item.id,
                });
              }
            }
          }
        } else if (item.kind === "withdrawal") {
          if (decision === "reject") {
            await tx.update(users).set({ balanceCents: sql`${users.balanceCents} + ${item.amountCents}` }).where(eq(users.id, item.userId));
            await tx.insert(ledgerEntries).values({
              userId: item.userId, kind: "withdrawal_refund", amountCents: item.amountCents,
              description: "Withdrawal declined · funds returned", relatedId: item.id,
            });
          }
          await tx.update(walletRequests).set({ status: decision === "approve" ? "paid" : "rejected", reviewedAt: new Date() }).where(eq(walletRequests.id, item.id));
        } else {
          fail("Unknown request type.");
        }
        await tx.insert(studioAudit).values({ actorId: admin.id, targetId: item.id,
          action: "request_review", details: `${decision === "approve" ? "Approved" : "Declined"} ${item.kind} request for $${(item.amountCents / 100).toFixed(2)}` });
      });
      return Response.json({ ok: true, message: decision === "approve" ? "Request approved. Confirm any external transfer separately." : "Request declined." });
    }

    fail("Unknown operator action.");
  } catch (error) {
    return handleActionError(error);
  }
}
