import { and, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { gamePlays, ledgerEntries, platformSettings, users } from "@/db/schema";
import { ensureSettings } from "@/lib/dashboard";
import { chooseCrashMultiplierBps, crashTimeMs, publicRound, reconcileExpiredRounds, settleRound } from "@/lib/live-games";
import { getPublishedContent } from "@/lib/site-content";
import { assertSameOrigin, fail, handleActionError, parseCents, requireUser } from "@/lib/security";
import { MAX_BET_CENTS, MAX_CASHOUT_BPS, MIN_BET_CENTS, ROUND_DURATION_MS, type GameId } from "@/lib/shared";

export const dynamic = "force-dynamic";

function roundId(value: unknown): string {
  if (typeof value !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) {
    fail("Choose a valid round.");
  }
  return value;
}

export async function GET(request: Request) {
  try {
    const user = await requireUser();
    const id = roundId(new URL(request.url).searchParams.get("roundId"));
    const round = await settleRound(id, user.id);
    return Response.json(round, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    return handleActionError(error);
  }
}

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const body = await request.json() as Record<string, unknown>;

    if (body.action === "cashout") {
      const user = await requireUser();
      const settled = await settleRound(roundId(body.roundId), user.id, true);
      return Response.json(settled, { headers: { "Cache-Control": "private, no-store" } });
    }

    if (body.action !== "start") fail("Choose a valid game action.");
    const game = body.game;
    if (game !== "aviator" && game !== "tower") fail("Choose a valid game.");
    const gameId: GameId = game;
    const content = await getPublishedContent();
    if ((gameId === "aviator" && !content.aviatorEnabled) || (gameId === "tower" && !content.towerEnabled)) {
      fail("This game is not accepting new rounds right now.", 409);
    }
    const betCents = parseCents(body.amount);
    if (betCents < MIN_BET_CENTS || betCents > MAX_BET_CENTS) fail("Choose a stake between $1 and $100.");

    const user = await requireUser();
    if (!user.ageConfirmed) fail("You must be at least 18 to play.", 403);
    await ensureSettings();
    await reconcileExpiredRounds();

    const started = await db.transaction(async (tx) => {
      await tx.execute(sql`select id from platform_settings where id = 1 for update`);
      const [existing] = await tx.select({ game: gamePlays.game }).from(gamePlays)
        .where(and(eq(gamePlays.userId, user.id), eq(gamePlays.status, "active"))).limit(1);
      if (existing) fail(`You have a live ${existing.game === "aviator" ? "Aviator" : "Tower Rush"} round. Reopen it to cash out.`, 409);

      const [settings] = await tx.select().from(platformSettings).where(eq(platformSettings.id, 1)).limit(1);
      const reservedPayoutCents = Math.floor(betCents * MAX_CASHOUT_BPS / 10_000);
      if (settings.bankrollCents + betCents < reservedPayoutCents) {
        fail("Paid play is temporarily unavailable while the prize pool is replenished. Try a free demo instead.", 409);
      }
      const [deducted] = await tx.update(users)
        .set({ balanceCents: sql`${users.balanceCents} - ${betCents}` })
        .where(and(eq(users.id, user.id), gte(users.balanceCents, betCents)))
        .returning({ id: users.id });
      if (!deducted) fail("Not enough in your wallet. Add funds or try a free demo.", 409);

      const crashMultiplierBps = chooseCrashMultiplierBps(settings.winRate);
      const startedAt = new Date();
      const endsAt = new Date(Math.min(
        crashTimeMs(startedAt.getTime(), crashMultiplierBps),
        startedAt.getTime() + ROUND_DURATION_MS,
      ));
      const [play] = await tx.insert(gamePlays).values({
        userId: user.id,
        game: gameId,
        betCents,
        winRate: settings.winRate,
        won: false,
        status: "active",
        crashMultiplierBps,
        reservedPayoutCents,
        startedAt,
        endsAt,
      }).returning();
      await tx.update(platformSettings).set({
        bankrollCents: sql`${platformSettings.bankrollCents} + ${betCents} - ${reservedPayoutCents}`,
        updatedAt: startedAt,
      }).where(eq(platformSettings.id, 1));
      await tx.insert(ledgerEntries).values({
        userId: user.id,
        kind: "wager",
        amountCents: -betCents,
        description: `${gameId === "aviator" ? "Aviator" : "Tower Rush"} · live-round stake`,
        relatedId: play.id,
      });
      return publicRound(play);
    });
    return Response.json(started, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    return handleActionError(error);
  }
}
