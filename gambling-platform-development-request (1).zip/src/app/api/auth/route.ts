import { randomBytes } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { assertSameOrigin, createSession, deleteSession, fail, handleActionError, hashPassword, verifyPassword } from "@/lib/security";
import { getPublishedContent } from "@/lib/site-content";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const body = await request.json() as Record<string, unknown>;
    const action = body.action;

    if (action === "logout") {
      await deleteSession();
      return Response.json({ ok: true });
    }

    if (action === "register") {
      const name = typeof body.name === "string" ? body.name.trim().replace(/\s+/g, " ") : "";
      const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
      const password = typeof body.password === "string" ? body.password : "";
      const referral = typeof body.referral === "string" ? body.referral.trim().toUpperCase() : "";
      if (name.length < 2 || name.length > 60) fail("Enter your name (2–60 characters).");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 255) fail("Enter a valid email address.");
      if (password.length < 8 || password.length > 100) fail("Use a password between 8 and 100 characters.");
      if (body.ageConfirmed !== true) fail("You must confirm you are at least 18 to create an account.");

      let referredBy: string | null = null;
      if (referral) {
        if (!(await getPublishedContent()).referralsEnabled) fail("Referral signup is temporarily unavailable.", 409);
        const [referrer] = await db.select({ id: users.id }).from(users).where(eq(users.referralCode, referral)).limit(1);
        if (!referrer) fail("That referral code was not found.");
        referredBy = referrer.id;
      }

      const passwordHash = await hashPassword(password);
      const referralCode = `LUMI${randomBytes(5).toString("hex").toUpperCase()}`;
      let createdId: string;
      try {
        const [created] = await db.insert(users).values({
          name, email, passwordHash, referralCode, referredBy,
          role: "player", ageConfirmed: true,
        }).returning({ id: users.id });
        createdId = created.id;
      } catch (error) {
        if (error && typeof error === "object" && "code" in error && error.code === "23505") {
          fail("An account with that email already exists.", 409);
        }
        throw error;
      }
      await createSession(createdId);
      return Response.json({ ok: true });
    }

    if (action === "login") {
      const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
      const password = typeof body.password === "string" ? body.password : "";
      if (!email || !password) fail("Enter your email and password.");
      const [account] = await db.select({ id: users.id, passwordHash: users.passwordHash, isSuspended: users.isSuspended }).from(users).where(eq(users.email, email)).limit(1);
      if (!account || !(await verifyPassword(password, account.passwordHash))) fail("Incorrect email or password.", 401);
      if (account.isSuspended) fail("This account is suspended. Contact the operator for help.", 403);
      await createSession(account.id);
      return Response.json({ ok: true });
    }

    fail("Unknown account action.");
  } catch (error) {
    return handleActionError(error);
  }
}
