import { randomBytes } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { assertSameOrigin, fail, handleActionError, requireUser } from "@/lib/security";
import { getPublishedContent } from "@/lib/site-content";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const user = await requireUser();
    if (!(await getPublishedContent()).referralsEnabled) fail("Referrals are temporarily unavailable.", 409);
    const code = `LUMI${randomBytes(5).toString("hex").toUpperCase()}`;
    await db.update(users).set({ referralCode: code }).where(eq(users.id, user.id));
    return Response.json({ ok: true, code });
  } catch (error) {
    return handleActionError(error);
  }
}
