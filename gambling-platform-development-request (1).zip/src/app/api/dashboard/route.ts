import { loadDashboard } from "@/lib/dashboard";
import { handleActionError } from "@/lib/security";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const data = await loadDashboard();
    return Response.json(data, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    return handleActionError(error);
  }
}
