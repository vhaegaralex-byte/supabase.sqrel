import { assertSameOrigin, fail, handleActionError, requireStudioUser } from "@/lib/security";
import { planWithAssistant } from "@/lib/studio-assistant";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    await requireStudioUser();
    const body = await request.json() as Record<string, unknown>;
    const message = typeof body.message === "string" ? body.message.trim() : "";
    if (message.length < 10 || message.length > 1200) fail("Describe your idea in 10–1,200 characters.");
    const response = await planWithAssistant(message);
    return Response.json(response, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) { return handleActionError(error); }
}
