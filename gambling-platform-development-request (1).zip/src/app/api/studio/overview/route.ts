import { loadStudioData } from "@/lib/studio-data";
import { handleActionError } from "@/lib/security";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    return Response.json(await loadStudioData(), { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) { return handleActionError(error); }
}
