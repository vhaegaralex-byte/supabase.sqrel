import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { siteContent, studioAudit } from "@/db/schema";
import { assertSameOrigin, fail, handleActionError, requireStudioUser } from "@/lib/security";
import { ensureSiteContent, validateSiteContent } from "@/lib/site-content";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const operator = await requireStudioUser();
    const body = await request.json() as Record<string, unknown>;
    if (!(["draft", "publish", "revert"] as unknown[]).includes(body.action)) fail("Choose a valid publishing action.");
    const expectedVersion = Number(body.version);
    if (!Number.isInteger(expectedVersion) || expectedVersion < 1) fail("Refresh Studio before publishing.");
    const edited = body.action === "revert" ? null : validateSiteContent(body.content);
    await ensureSiteContent();
    const result = await db.transaction(async (tx) => {
      await tx.execute(sql`select id from site_content where id = 1 for update`);
      const [current] = await tx.select().from(siteContent).where(eq(siteContent.id, 1)).limit(1);
      if (current.version !== expectedVersion) fail("The site was published by another operator. Refresh before saving.", 409);
      const now = new Date();
      if (body.action === "revert") {
        await tx.update(siteContent).set({ draft: current.published, draftUpdatedAt: now }).where(eq(siteContent.id, 1));
        return { message: "Draft reset to the live version." };
      }
      if (!edited) fail("Enter valid site content.");
      if (body.action === "draft") {
        await tx.update(siteContent).set({ draft: edited, draftUpdatedAt: now }).where(eq(siteContent.id, 1));
        await tx.insert(studioAudit).values({ actorId: operator.id, action: "content_draft", details: "Saved a website draft" });
        return { message: "Draft saved. The player website has not changed." };
      }
      await tx.update(siteContent).set({
        draft: edited, published: edited, version: current.version + 1,
        draftUpdatedAt: now, publishedAt: now, publishedBy: operator.id,
      }).where(eq(siteContent.id, 1));
      await tx.insert(studioAudit).values({ actorId: operator.id, action: "content_publish", details: `Published website content · version ${current.version + 1}` });
      return { message: "Published! Your changes are live on the player website." };
    });
    return Response.json({ ok: true, ...result });
  } catch (error) { return handleActionError(error); }
}
