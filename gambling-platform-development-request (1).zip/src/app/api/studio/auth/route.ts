import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { studioInvites, studioLoginAttempts, users } from "@/db/schema";
import {
  assertSameOrigin, createStudioSession, deleteStudioSession, fail,
  getStudioUser, handleActionError, hashPassword, verifyPassword,
} from "@/lib/security";

export const dynamic = "force-dynamic";

function hash(value: string) { return createHash("sha256").update(value).digest("hex"); }
function validEmail(value: unknown) {
  if (typeof value !== "string") fail("Enter a valid email address.");
  const email = value.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 255) fail("Enter a valid email address.");
  return email;
}

export async function GET() {
  try {
    const operator = await getStudioUser();
    const [count] = await db.select({ total: sql<number>`count(*)::int` }).from(users).where(eq(users.role, "admin"));
    return Response.json({
      operator: operator ? { id: operator.id, name: operator.name, email: operator.email } : null,
      needsSetup: count.total === 0,
      setupConfigured: Boolean(process.env.STUDIO_SETUP_CODE || process.env.ADMIN_SETUP_CODE),
    }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) { return handleActionError(error); }
}

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const body = await request.json() as Record<string, unknown>;
    if (body.action === "logout") {
      await deleteStudioSession();
      return Response.json({ ok: true });
    }
    const email = validEmail(body.email);
    const password = typeof body.password === "string" ? body.password : "";
    if (!password) fail("Enter your password.");

    if (body.action === "login") {
      const outcome = await db.transaction(async (tx) => {
        await tx.insert(studioLoginAttempts).values({ email }).onConflictDoNothing();
        await tx.execute(sql`select email from studio_login_attempts where email = ${email} for update`);
        const [attempt] = await tx.select().from(studioLoginAttempts).where(eq(studioLoginAttempts.email, email)).limit(1);
        if (attempt.lockedUntil && attempt.lockedUntil > new Date()) return { state: "locked" as const };
        const [account] = await tx.select({ id: users.id, role: users.role, isSuspended: users.isSuspended, passwordHash: users.passwordHash })
          .from(users).where(eq(users.email, email)).limit(1);
        const valid = account?.role === "admin" && !account.isSuspended && await verifyPassword(password, account.passwordHash);
        if (!valid) {
          const attempts = (attempt.attempts || 0) + 1;
          await tx.update(studioLoginAttempts).set({
            attempts,
            lockedUntil: attempts >= 5 ? new Date(Date.now() + 15 * 60_000) : null,
            updatedAt: new Date(),
          }).where(eq(studioLoginAttempts.email, email));
          return { state: "invalid" as const };
        }
        await tx.delete(studioLoginAttempts).where(eq(studioLoginAttempts.email, email));
        return { state: "ok" as const, id: account.id };
      });
      if (outcome.state === "locked") fail("Too many attempts. Try again in 15 minutes.", 429);
      if (outcome.state === "invalid") fail("Incorrect operator email or password.", 401);
      await createStudioSession(outcome.id);
      return Response.json({ ok: true });
    }

    if (body.action === "setup" || body.action === "invite") {
      const name = typeof body.name === "string" ? body.name.trim().replace(/\s+/g, " ") : "";
      if (name.length < 2 || name.length > 60) fail("Enter a name between 2 and 60 characters.");
      if (password.length < 10 || password.length > 100) fail("Use a password between 10 and 100 characters.");
      const passwordHash = await hashPassword(password);
      const referralCode = `LUMI${randomBytes(5).toString("hex").toUpperCase()}`;
      let createdId: string;
      try {
        createdId = await db.transaction(async (tx) => {
          if (body.action === "setup") {
            const secret = process.env.STUDIO_SETUP_CODE || process.env.ADMIN_SETUP_CODE;
            if (!secret) fail("Set STUDIO_SETUP_CODE in the server environment before creating the owner account.", 503);
            const provided = typeof body.setupCode === "string" ? body.setupCode : "";
            if (!provided || !timingSafeEqual(Buffer.from(hash(provided), "hex"), Buffer.from(hash(secret), "hex"))) {
              fail("Invalid operator setup code.", 403);
            }
            await tx.execute(sql`select pg_advisory_xact_lock(79114461)`);
            const [count] = await tx.select({ total: sql<number>`count(*)::int` }).from(users).where(eq(users.role, "admin"));
            if (count.total !== 0) fail("An operator account already exists. Ask for an invitation instead.", 409);
          } else {
            const code = typeof body.inviteCode === "string" ? body.inviteCode.trim() : "";
            if (!/^[a-f0-9]{64}$/i.test(code)) fail("Enter a valid invitation code.", 403);
            const tokenHash = hash(code);
            await tx.execute(sql`select token_hash from studio_invites where token_hash = ${tokenHash} for update`);
            const [invite] = await tx.select().from(studioInvites).where(eq(studioInvites.tokenHash, tokenHash)).limit(1);
            if (!invite || invite.email !== email || invite.usedAt || invite.expiresAt <= new Date()) {
              fail("This invitation is invalid, expired, or belongs to another email.", 403);
            }
            await tx.update(studioInvites).set({ usedAt: new Date() }).where(eq(studioInvites.tokenHash, tokenHash));
          }
          const [created] = await tx.insert(users).values({
            name, email, passwordHash, referralCode, role: "admin", ageConfirmed: true,
          }).returning({ id: users.id });
          return created.id;
        });
      } catch (error) {
        if (error && typeof error === "object" && "code" in error && error.code === "23505") {
          fail("This email address already has an account. Use another email for the operator invitation.", 409);
        }
        throw error;
      }
      await createStudioSession(createdId);
      return Response.json({ ok: true });
    }
    fail("Unknown Studio account action.");
  } catch (error) { return handleActionError(error); }
}
