import { createHash, randomBytes } from "node:crypto";
import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { studioAudit, studioInvites, users } from "@/db/schema";
import { assertSameOrigin, fail, handleActionError, requireStudioUser } from "@/lib/security";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const operator = await requireStudioUser();
    const body = await request.json() as Record<string, unknown>;
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 255) fail("Enter a valid email address.");
    if (body.action === "revoke") {
      await db.delete(studioInvites).where(and(eq(studioInvites.email, email), isNull(studioInvites.usedAt)));
      await db.insert(studioAudit).values({ actorId: operator.id, action: "invite_revoke", details: `Revoked pending invitation for ${email}` });
      return Response.json({ ok: true, message: "Pending invitation revoked." });
    }
    if (body.action !== "invite") fail("Choose a valid team action.");
    const [existing] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing) fail("This email already has an account. Use a new email for this operator invitation.", 409);
    const inviteCode = randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1000);
    await db.transaction(async (tx) => {
      await tx.delete(studioInvites).where(and(eq(studioInvites.email, email), isNull(studioInvites.usedAt)));
      await tx.insert(studioInvites).values({
        tokenHash: createHash("sha256").update(inviteCode).digest("hex"),
        email, createdBy: operator.id, expiresAt,
      });
      await tx.insert(studioAudit).values({ actorId: operator.id, action: "invite_create", details: `Created 48-hour operator invitation for ${email}` });
    });
    return Response.json({ ok: true, inviteCode, email, expiresAt: expiresAt.toISOString(), message: "Invitation created. Copy the link now; the code is shown once." });
  } catch (error) { return handleActionError(error); }
}
