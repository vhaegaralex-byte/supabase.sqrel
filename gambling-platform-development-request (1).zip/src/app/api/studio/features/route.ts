import { eq } from "drizzle-orm";
import { db } from "@/db";
import { featureRequests, studioAudit } from "@/db/schema";
import { assertSameOrigin, fail, handleActionError, requireStudioUser } from "@/lib/security";
import { planWithAssistant } from "@/lib/studio-assistant";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const operator = await requireStudioUser();
    const body = await request.json() as Record<string, unknown>;
    if (body.action === "create") {
      const title = typeof body.title === "string" ? body.title.trim().replace(/\s+/g, " ") : "";
      const description = typeof body.description === "string" ? body.description.trim() : "";
      const priority = body.priority;
      if (title.length < 4 || title.length > 100) fail("Use a title between 4 and 100 characters.");
      if (description.length < 15 || description.length > 1500) fail("Describe the feature in 15–1,500 characters.");
      if (priority !== "low" && priority !== "medium" && priority !== "high") fail("Choose a valid priority.");
      const plan = await planWithAssistant(`${title}\n\n${description}`);
      const [feature] = await db.insert(featureRequests).values({
        title, description, priority, assistantPlan: plan.reply,
        createdBy: operator.id,
      }).returning({ id: featureRequests.id });
      await db.insert(studioAudit).values({ actorId: operator.id, targetId: feature.id,
        action: "feature_create", details: `Added feature request: ${title}`.slice(0, 240) });
      return Response.json({ ok: true, mode: plan.mode, message: "Feature request saved to your planning board." });
    }
    if (body.action === "status") {
      const id = typeof body.id === "string" ? body.id : "";
      const status = body.status;
      if (!/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(id)) fail("Choose a valid feature.");
      if (!["idea", "planned", "building", "released"].includes(String(status))) fail("Choose a valid status.");
      const [item] = await db.update(featureRequests).set({ status: status as string, updatedAt: new Date() })
        .where(eq(featureRequests.id, id)).returning({ title: featureRequests.title });
      if (!item) fail("Feature request not found.", 404);
      await db.insert(studioAudit).values({ actorId: operator.id, targetId: id,
        action: "feature_status", details: `Marked ${item.title} as ${status} (manual status only)` .slice(0, 240) });
      return Response.json({ ok: true, message: "Planning status updated. This does not deploy code." });
    }
    fail("Choose a valid feature action.");
  } catch (error) { return handleActionError(error); }
}
