import { and, desc, eq, ilike, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { handleActionError, requireStudioUser } from "@/lib/security";
import { playerSelection, serializePlayer } from "@/lib/studio-data";

export const dynamic = "force-dynamic";
const PAGE_SIZE = 20;

export async function GET(request: Request) {
  try {
    await requireStudioUser();
    const params = new URL(request.url).searchParams;
    const search = (params.get("search") || "").trim().slice(0, 80).replace(/[\\%_]/g, "\\$&");
    const status = params.get("status") || "all";
    const page = Math.min(500, Math.max(1, Number.parseInt(params.get("page") || "1", 10) || 1));
    const conditions = [eq(users.role, "player")];
    if (status === "active") conditions.push(eq(users.isSuspended, false));
    if (status === "suspended") conditions.push(eq(users.isSuspended, true));
    if (search) conditions.push(or(ilike(users.name, `%${search}%`), ilike(users.email, `%${search}%`), ilike(users.referralCode, `%${search}%`))!);
    const where = and(...conditions);
    const [rows, count] = await Promise.all([
      db.select(playerSelection).from(users).where(where).orderBy(desc(users.createdAt)).limit(PAGE_SIZE).offset((page - 1) * PAGE_SIZE),
      db.select({ total: sql<number>`count(*)::int` }).from(users).where(where),
    ]);
    return Response.json({ players: rows.map(serializePlayer), total: count[0]?.total ?? 0, page, pageSize: PAGE_SIZE }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) { return handleActionError(error); }
}
