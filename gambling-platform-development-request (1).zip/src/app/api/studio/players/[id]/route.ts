import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { gamePlays, ledgerEntries, platformSettings, sessions, studioAudit, users, walletRequests } from "@/db/schema";
import { ensureSettings } from "@/lib/dashboard";
import { reconcileExpiredRounds } from "@/lib/live-games";
import { assertSameOrigin, fail, handleActionError, parseCents, requireStudioUser } from "@/lib/security";
import { playerSelection, serializePlayer } from "@/lib/studio-data";
import type { PlayerDetail } from "@/lib/studio-types";

export const dynamic = "force-dynamic";
type Context = { params: Promise<{ id: string }> };

async function playerId(context: Context) {
  const { id } = await context.params;
  if (!/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(id)) fail("Player not found.", 404);
  return id;
}

export async function GET(_request: Request, context: Context) {
  try {
    await requireStudioUser();
    const id = await playerId(context);
    await reconcileExpiredRounds(id);
    const [rows, ledger, requests, plays] = await Promise.all([
      db.select(playerSelection).from(users).where(and(eq(users.id, id), eq(users.role, "player"))).limit(1),
      db.select({ id: ledgerEntries.id, kind: ledgerEntries.kind, amountCents: ledgerEntries.amountCents,
        description: ledgerEntries.description, createdAt: ledgerEntries.createdAt })
        .from(ledgerEntries).where(eq(ledgerEntries.userId, id)).orderBy(desc(ledgerEntries.createdAt)).limit(25),
      db.select({ id: walletRequests.id, kind: walletRequests.kind, amountCents: walletRequests.amountCents,
        status: walletRequests.status, createdAt: walletRequests.createdAt })
        .from(walletRequests).where(eq(walletRequests.userId, id)).orderBy(desc(walletRequests.createdAt)).limit(15),
      db.select({ id: gamePlays.id, game: gamePlays.game, status: gamePlays.status,
        betCents: gamePlays.betCents, payoutCents: gamePlays.payoutCents, createdAt: gamePlays.createdAt })
        .from(gamePlays).where(eq(gamePlays.userId, id)).orderBy(desc(gamePlays.createdAt)).limit(15),
    ]);
    if (!rows[0]) fail("Player not found.", 404);
    const result: PlayerDetail = {
      player: serializePlayer(rows[0]),
      ledger: ledger.map((item) => ({ ...item, createdAt: item.createdAt.toISOString() })),
      requests: requests.map((item) => ({ ...item, createdAt: item.createdAt.toISOString() })),
      plays: plays.map((item) => ({ ...item, createdAt: item.createdAt.toISOString() })),
    };
    return Response.json(result, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) { return handleActionError(error); }
}

export async function POST(request: Request, context: Context) {
  try {
    assertSameOrigin(request);
    const operator = await requireStudioUser();
    const id = await playerId(context);
    const body = await request.json() as Record<string, unknown>;
    const action = body.action;
    if (!["suspend", "restore", "credit", "debit", "rename"].includes(String(action))) fail("Choose a valid player action.");
    const reason = typeof body.reason === "string" ? body.reason.trim().replace(/\s+/g, " ") : "";
    const adjustment = action === "credit" || action === "debit";
    if (adjustment && (reason.length < 10 || reason.length > 140)) fail("Give a reason between 10 and 140 characters for wallet corrections.");
    const amountCents = adjustment ? parseCents(body.amount) : 0;
    if (adjustment && (amountCents < 100 || amountCents > 500_000)) fail("Wallet corrections must be between $1 and $5,000.");
    const newName = typeof body.name === "string" ? body.name.trim().replace(/\s+/g, " ") : "";
    if (action === "rename" && (newName.length < 2 || newName.length > 60)) fail("Enter a name between 2 and 60 characters.");
    await ensureSettings();
    await db.transaction(async (tx) => {
      // Lock settings before accounts, matching game and funding transactions.
      await tx.execute(sql`select id from platform_settings where id = 1 for update`);
      await tx.execute(sql`select id from users where id = ${id}::uuid for update`);
      const [player] = await tx.select({ id: users.id, role: users.role, name: users.name, balanceCents: users.balanceCents })
        .from(users).where(eq(users.id, id)).limit(1);
      if (!player || player.role !== "player") fail("Player not found.", 404);
      if (adjustment) {
        const [settings] = await tx.select().from(platformSettings).where(eq(platformSettings.id, 1)).limit(1);
        if (action === "credit" && settings.bankrollCents < amountCents) fail("Not enough unreserved prize-pool funds to credit this wallet.", 409);
        if (action === "debit" && player.balanceCents < amountCents) fail("The player's available wallet balance is too low.", 409);
        const delta = action === "credit" ? amountCents : -amountCents;
        await tx.update(users).set({ balanceCents: sql`${users.balanceCents} + ${delta}` }).where(eq(users.id, id));
        await tx.update(platformSettings).set({
          bankrollCents: sql`${platformSettings.bankrollCents} - ${delta}`,
          updatedAt: new Date(),
        }).where(eq(platformSettings.id, 1));
        await tx.insert(ledgerEntries).values({
          userId: id, kind: action === "credit" ? "operator_credit" : "operator_debit",
          amountCents: delta, description: `Operator correction · ${reason}`,
        });
        await tx.insert(studioAudit).values({
          actorId: operator.id, targetId: id, action: `player_${action}`,
          details: `${action === "credit" ? "Credited" : "Debited"} ${player.name} $${(amountCents / 100).toFixed(2)} · ${reason}`.slice(0, 240),
        });
      } else if (action === "suspend" || action === "restore") {
        await tx.update(users).set({ isSuspended: action === "suspend" }).where(eq(users.id, id));
        if (action === "suspend") await tx.delete(sessions).where(eq(sessions.userId, id));
        await tx.insert(studioAudit).values({ actorId: operator.id, targetId: id,
          action: `player_${action}`, details: `${action === "suspend" ? "Suspended" : "Restored"} ${player.name}` });
      } else {
        await tx.update(users).set({ name: newName }).where(eq(users.id, id));
        await tx.insert(studioAudit).values({ actorId: operator.id, targetId: id,
          action: "player_rename", details: `Updated player name from ${player.name} to ${newName}`.slice(0, 240) });
      }
    });
    return Response.json({ ok: true, message: adjustment ? "Wallet correction recorded and audited." : action === "suspend" ? "Player suspended and signed out." : action === "restore" ? "Player access restored." : "Player profile updated." });
  } catch (error) { return handleActionError(error); }
}
