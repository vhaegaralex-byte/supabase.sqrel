import { and, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { ledgerEntries, users, walletRequests } from "@/db/schema";
import { assertSameOrigin, encryptPrivate, fail, handleActionError, parseCents, requireUser } from "@/lib/security";

export const dynamic = "force-dynamic";

const methods = ["bank_transfer", "mobile_money", "other"];

export async function POST(request: Request) {
  try {
    assertSameOrigin(request);
    const user = await requireUser();
    const body = await request.json() as Record<string, unknown>;
    const action = body.action;
    const amountCents = parseCents(body.amount);
    if (amountCents < 1_000 || amountCents > 1_000_000) fail("Enter an amount between $10 and $10,000.");
    const method = typeof body.method === "string" ? body.method : "";
    if (!methods.includes(method)) fail("Choose a valid payment method.");

    if (action === "deposit") {
      const reference = typeof body.reference === "string" ? body.reference.trim() : "";
      if (reference.length < 3 || reference.length > 120) fail("Enter a transfer reference or short note (3–120 characters).");
      await db.insert(walletRequests).values({
        userId: user.id, kind: "deposit", amountCents, method, reference,
      });
      return Response.json({ ok: true, message: "Deposit request submitted for manual review." });
    }

    if (action === "withdrawal") {
      const details = typeof body.details === "string" ? body.details.trim() : "";
      if (details.length < 3 || details.length > 120) fail("Enter a payout destination (3–120 characters).");
      const encryptedDetails = encryptPrivate(details);
      await db.transaction(async (tx) => {
        const [updated] = await tx.update(users)
          .set({ balanceCents: sql`${users.balanceCents} - ${amountCents}` })
          .where(and(eq(users.id, user.id), gte(users.balanceCents, amountCents)))
          .returning({ id: users.id });
        if (!updated) fail("Your available balance is too low for this withdrawal.");
        const [created] = await tx.insert(walletRequests).values({
          userId: user.id, kind: "withdrawal", amountCents, method, payoutDetails: encryptedDetails,
        }).returning({ id: walletRequests.id });
        await tx.insert(ledgerEntries).values({
          userId: user.id, kind: "withdrawal_hold", amountCents: -amountCents,
          description: "Withdrawal requested · funds reserved", relatedId: created.id,
        });
      });
      return Response.json({ ok: true, message: "Withdrawal requested. Your funds are reserved during review." });
    }

    fail("Unknown wallet action.");
  } catch (error) {
    return handleActionError(error);
  }
}
