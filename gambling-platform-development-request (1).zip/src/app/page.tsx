import { Dashboard } from "@/components/dashboard";
import { loadDashboard } from "@/lib/dashboard";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const data = await loadDashboard();
  return <Dashboard initialData={data} />;
}
