"use client";

import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import {
  Activity, ArrowDownLeft, ArrowRight, ArrowUpRight, BarChart3, Bell, Check,
  CheckCircle2, ChevronDown, ChevronLeft, ChevronRight, CircleHelp, Clock3, Coins,
  Copy, ExternalLink, FileText, Gamepad2, Gift, Globe2, History, Info, KeyRound,
  Layers3, LayoutDashboard, LockKeyhole, LogOut, Menu, MessageCircle, MoreHorizontal,
  PenLine, Plane, Plus, Search, Send, Settings2, ShieldCheck, SlidersHorizontal,
  Sparkles, TrendingUp, UserCheck, UserPlus, UsersRound, Wallet, WandSparkles, X,
  type LucideIcon,
} from "lucide-react";
import { formatDate, formatMoney } from "@/lib/shared";
import {
  type PlayerDetail, type SiteContent, type StudioData, type StudioFeature,
  type StudioPlayer, type StudioRequest,
} from "@/lib/studio-types";

type View = "overview" | "players" | "payments" | "site" | "games" | "features" | "team";
type Notification = { text: string; error?: boolean } | null;
type PlayerList = { players: StudioPlayer[]; total: number; page: number; pageSize: number };
type ApiResponse = { ok?: boolean; error?: string; message?: string; [key: string]: unknown };

const nav: { label: string; items: { id: View; label: string; icon: LucideIcon }[] }[] = [
  { label: "WORKSPACE", items: [
    { id: "overview", label: "Overview", icon: LayoutDashboard },
    { id: "players", label: "Players", icon: UsersRound },
    { id: "payments", label: "Wallet requests", icon: Wallet },
  ] },
  { label: "BUILD & GROW", items: [
    { id: "site", label: "Site editor", icon: PenLine },
    { id: "games", label: "Games & odds", icon: Gamepad2 },
    { id: "features", label: "Feature lab", icon: WandSparkles },
  ] },
  { label: "SETTINGS", items: [{ id: "team", label: "Team & security", icon: ShieldCheck }] },
];

async function requestJson<T = ApiResponse>(url: string, body?: Record<string, unknown>): Promise<T> {
  const response = await fetch(url, body ? {
    method: "POST", credentials: "same-origin",
    headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  } : { credentials: "same-origin", cache: "no-store" });
  const payload = await response.json().catch(() => ({})) as T & { error?: string };
  if (!response.ok) throw new Error(payload.error || "That didn't work. Please try again.");
  return payload;
}

function StudioMark({ inverted = false }: { inverted?: boolean }) {
  return <span className={`st-brand ${inverted ? "st-brand-inverted" : ""}`}><span className="st-brand-symbol"><Sparkles size={21} strokeWidth={2.4} /></span><span>lumi<span className="st-brand-period">.</span><small>STUDIO</small></span></span>;
}
function Avatar({ name, size = "normal" }: { name: string; size?: "normal" | "small" }) {
  return <span className={`st-avatar ${size === "small" ? "st-avatar-small" : ""}`}>{name.trim().charAt(0).toUpperCase() || "?"}</span>;
}
function Status({ value }: { value: string }) {
  return <span className={`st-status st-status-${value}`}><i />{value === "paid" ? "Paid" : value === "approved" ? "Approved" : value === "rejected" ? "Declined" : value === "active" ? "Active" : value === "suspended" ? "Suspended" : value.replaceAll("_", " ")}</span>;
}
function Heading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return <div className="st-heading"><div><p className="st-eyebrow">{eyebrow}</p><h1>{title}</h1><p>{description}</p></div>{action && <div className="st-heading-action">{action}</div>}</div>;
}
function IconBadge({ icon: Icon, tone = "mint" }: { icon: LucideIcon; tone?: "mint" | "violet" | "peach" | "blue" }) {
  return <span className={`st-icon-badge st-icon-${tone}`}><Icon size={19} strokeWidth={2} /></span>;
}
function Empty({ icon: Icon, title, text }: { icon: LucideIcon; title: string; text: string }) {
  return <div className="st-empty"><span><Icon size={25} /></span><strong>{title}</strong><p>{text}</p></div>;
}

function AuthScreen({ needsSetup, setupConfigured, invitation, onSuccess }: {
  needsSetup: boolean; setupConfigured: boolean; invitation: { code: string; email: string };
  onSuccess: (data: StudioData) => void;
}) {
  const [mode, setMode] = useState<"login" | "setup" | "invite">(invitation.code ? "invite" : needsSetup ? "setup" : "login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState(invitation.email);
  const [password, setPassword] = useState("");
  const [code, setCode] = useState(invitation.code);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(""); setBusy(true);
    try {
      await requestJson("/api/studio/auth", {
        action: mode === "login" ? "login" : mode, name, email, password,
        setupCode: mode === "setup" ? code : undefined,
        inviteCode: mode === "invite" ? code : undefined,
      });
      onSuccess(await requestJson<StudioData>("/api/studio/overview"));
    } catch (issue) { setError(issue instanceof Error ? issue.message : "Please try again."); }
    finally { setBusy(false); }
  }
  return <div className="st-auth-shell">
    <aside className="st-auth-story"><StudioMark inverted /><div className="st-auth-story-main"><span className="st-auth-orbit">✳</span><span className="st-label-light">YOUR SPACE TO MAKE IT BETTER</span><h1>Everything behind<br />the magic.<br /><em>All in one place.</em></h1><p>Shape the player experience, look after your community, and bring what&apos;s next to life.</p></div><div className="st-auth-story-foot"><span><ShieldCheck size={16} /> Private operator access</span><span>Connected to LumiPlay <span className="st-online-dot" /></span></div><div className="st-auth-circle st-auth-circle-one" /><div className="st-auth-circle st-auth-circle-two" /></aside>
    <main className="st-auth-main"><div className="st-auth-top"><span>OPERATOR PORTAL</span><a href="/" target="_blank" rel="noreferrer">Visit player site <ExternalLink size={14} /></a></div><div className="st-auth-form-wrap"><div className="st-auth-lock"><LockKeyhole size={21} /></div><p className="st-eyebrow">WELCOME TO LUMI STUDIO</p><h2>{mode === "setup" ? "Set up your workspace." : mode === "invite" ? "Join the team." : "Welcome back."}</h2><p className="st-auth-sub">{mode === "setup" ? "Create the first protected operator account to get started." : mode === "invite" ? "You were invited to help manage LumiPlay." : "Sign in with your operator account to pick up where you left off."}</p>
      {mode === "setup" && !setupConfigured && <div className="st-alert st-alert-amber"><Info size={17} /><span>Set <strong>STUDIO_SETUP_CODE</strong> in the server environment before registering an owner.</span></div>}
      {error && <div className="st-alert st-alert-error"><Info size={17} /><span>{error}</span></div>}
      <form onSubmit={(event) => void submit(event)} className="st-auth-form">{mode !== "login" && <label>Full name<input value={name} onChange={(event) => setName(event.target.value)} placeholder="Your name" autoComplete="name" minLength={2} maxLength={60} required /></label>}<label>Email address<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@company.com" autoComplete="email" required /></label><label>Password<input type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder={mode === "login" ? "Enter your password" : "At least 10 characters"} autoComplete={mode === "login" ? "current-password" : "new-password"} minLength={mode === "login" ? 1 : 10} required /></label>{mode !== "login" && <label>{mode === "setup" ? "Private setup code" : "Invitation code"}<input type="password" value={code} onChange={(event) => setCode(event.target.value)} placeholder={mode === "setup" ? "From your server environment" : "From your invitation link"} required /></label>}<button className="st-button st-button-dark st-auth-submit" disabled={busy || (mode === "setup" && !setupConfigured)}>{busy ? "One moment..." : mode === "setup" ? "Create operator account" : mode === "invite" ? "Accept invitation" : "Sign in to Studio"}<ArrowRight size={18} /></button></form>
      <div className="st-auth-options">{mode !== "login" ? <button onClick={() => { setMode("login"); setError(""); setCode(""); }}>Already have access? Sign in</button> : <>{needsSetup && <button onClick={() => { setMode("setup"); setError(""); }}>Set up owner account</button>}<button onClick={() => { setMode("invite"); setError(""); }}>Have an invitation?</button></>}</div><p className="st-auth-caption"><ShieldCheck size={15} /> Operator-only access. Player accounts can&apos;t sign in here.</p></div><div className="st-auth-bottom">© Lumi Studio · For authorized operators only</div></main>
  </div>;
}

function Overview({ data, navigate }: { data: StudioData; navigate: (view: View) => void }) {
  const pending = data.requests.filter((item) => item.status === "pending").slice(0, 3);
  const max = Math.max(1, ...data.activitySeries.map((day) => day.count));
  return <>
    <Heading eyebrow="WORKSPACE / OVERVIEW" title={`Good to see you, ${data.operator.name.split(" ")[0]} ✳`} description="Here's what's happening across LumiPlay today." action={<span className="st-today"><span /> Everything is up to date</span>} />
    <section className="st-hero"><div className="st-hero-copy"><span className="st-hero-tag"><Sparkles size={14} /> YOUR CONTROL CENTER</span><h2>Make every<br />moment <em>count.</em></h2><p>From the first hello to the next big feature — you have the tools to shape it all.</p><div className="st-hero-actions"><button className="st-button st-button-lime" onClick={() => navigate("site")}>Edit your website <ArrowRight size={17} /></button><button className="st-button st-button-hero-ghost" onClick={() => navigate("features")}>Explore feature lab <ArrowUpRight size={17} /></button></div></div><div className="st-hero-art" aria-hidden="true"><div className="st-hero-orbit orbit-outer" /><div className="st-hero-orbit orbit-inner" /><div className="st-floating-card st-floating-one"><span>✳ &nbsp; LUMI IS LIVE</span><strong>Good things<br />are happening.</strong><i /></div><div className="st-floating-card st-floating-two"><span><span className="st-mini-dot" /> LIVE SITE</span><div className="st-floating-bars"><i /><i /><i /><i /><i /></div></div><span className="st-hero-plus">✦</span></div></section>
    <div className="st-metrics"><button className="st-metric" onClick={() => navigate("players")}><IconBadge icon={UsersRound} tone="violet" /><span className="st-metric-label">Total players</span><strong>{data.counts.players.toLocaleString()}</strong><small>{data.counts.suspended ? `${data.counts.suspended} suspended` : "Your growing community"}</small><ArrowUpRight className="st-metric-arrow" size={17} /></button><button className="st-metric" onClick={() => navigate("games")}><IconBadge icon={Coins} tone="mint" /><span className="st-metric-label">Available prize pool</span><strong>{formatMoney(data.settings.bankrollCents)}</strong><small>After live-round reserves</small><ArrowUpRight className="st-metric-arrow" size={17} /></button><button className="st-metric" onClick={() => navigate("payments")}><IconBadge icon={Clock3} tone="peach" /><span className="st-metric-label">Needs your review</span><strong>{data.counts.pending}</strong><small>Deposit & withdrawal requests</small><ArrowUpRight className="st-metric-arrow" size={17} /></button><button className="st-metric" onClick={() => navigate("games")}><IconBadge icon={Activity} tone="blue" /><span className="st-metric-label">Game rounds</span><strong>{data.counts.totalPlays.toLocaleString()}</strong><small>{data.counts.activeRounds} live right now</small><ArrowUpRight className="st-metric-arrow" size={17} /></button></div>
    <div className="st-overview-grid"><section className="st-card st-chart-card"><div className="st-card-head"><div><span className="st-eyebrow">AT A GLANCE</span><h3>Game activity</h3><p>Paid rounds started in the last seven days</p></div><span className="st-chart-period"><BarChart3 size={15} /> Last 7 days</span></div><div className="st-chart"><div className="st-chart-y"><span>{max}</span><span>{Math.ceil(max / 2)}</span><span>0</span></div><div className="st-chart-bars">{data.activitySeries.map((day, index) => <div className="st-chart-column" key={`${day.label}-${index}`} title={`${day.count} rounds`}><div className="st-chart-bar-track"><span style={{ height: `${Math.max(3, day.count / max * 100)}%` }} className={index === 6 ? "is-current" : ""} /></div><small>{day.label}</small></div>)}</div></div><div className="st-chart-foot"><span className="st-legend-dot" /> Rounds played <span className="st-chart-total">{data.activitySeries.reduce((sum, day) => sum + day.count, 0)} this week</span></div></section><section className="st-card st-queue-card"><div className="st-card-head"><div><span className="st-eyebrow">DON&apos;T MISS A THING</span><h3>Needs attention</h3><p>Requests waiting for a decision</p></div><button className="st-text-action" onClick={() => navigate("payments")}>View all <ArrowRight size={15} /></button></div>{pending.length ? <div className="st-mini-list">{pending.map((item) => <button className="st-mini-row" key={item.id} onClick={() => navigate("payments")}><span className={`st-mini-icon ${item.kind === "deposit" ? "st-mini-green" : "st-mini-violet"}`}>{item.kind === "deposit" ? <ArrowDownLeft size={17} /> : <ArrowUpRight size={17} />}</span><span><strong>{item.userName}</strong><small>{item.kind === "deposit" ? "Deposit request" : "Withdrawal request"} · {formatDate(item.createdAt)}</small></span><b>{formatMoney(item.amountCents)}</b><ChevronRight size={16} /></button>)}</div> : <Empty icon={CheckCircle2} title="You're all caught up" text="New wallet requests will show up here." />}<button className="st-queue-footer" onClick={() => navigate("payments")}>Open wallet review <ArrowRight size={16} /></button></section></div>
    <div className="st-overview-bottom"><section className="st-card st-recent-card"><div className="st-card-head"><div><span className="st-eyebrow">YOUR COMMUNITY</span><h3>Newest players</h3></div><button className="st-text-action" onClick={() => navigate("players")}>See all players <ArrowRight size={15} /></button></div>{data.recentPlayers.length ? data.recentPlayers.map((player) => <button className="st-player-preview" key={player.id} onClick={() => navigate("players")}><Avatar name={player.name} size="small" /><span><strong>{player.name}</strong><small>{player.email}</small></span><span className="st-player-preview-date">{formatDate(player.createdAt)}</span></button>) : <Empty icon={UsersRound} title="A fresh start" text="Players will appear here as they join." />}</section><section className="st-publish-card"><div className="st-publish-card-top"><span className="st-publish-icon"><Globe2 size={22} /></span><span className="st-publish-live"><i /> WEBSITE LIVE</span></div><h3>Your site, your story.</h3><p>Update your homepage, set an announcement, and choose which activities appear. Publish changes without touching code.</p><div className="st-publish-preview"><span>lumi.play</span><span>Version {data.content.version} <CheckCircle2 size={14} /></span></div><button className="st-button st-button-dark" onClick={() => navigate("site")}>Open site editor <ArrowRight size={16} /></button></section></div>
  </>;
}

function Players({ data, search, setSearch, onPost, notify, busy }: {
  data: StudioData; search: string; setSearch: (value: string) => void;
  onPost: (path: string, body: Record<string, unknown>) => Promise<ApiResponse | null>;
  notify: (text: string, error?: boolean) => void; busy: boolean;
}) {
  const [status, setStatus] = useState("all");
  const [page, setPage] = useState(1);
  const [list, setList] = useState<PlayerList | null>(null);
  const [revision, setRevision] = useState(0);
  const [detail, setDetail] = useState<PlayerDetail | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("");
  const [newName, setNewName] = useState("");
  useEffect(() => {
    const controller = new AbortController();
    const timer = setTimeout(() => {
      void fetch(`/api/studio/players?search=${encodeURIComponent(search)}&status=${status}&page=${page}`, { cache: "no-store", signal: controller.signal })
        .then(async (response) => { if (!response.ok) throw new Error("Couldn't load players."); return response.json() as Promise<PlayerList>; })
        .then((payload) => setList(payload))
        .catch((error: unknown) => { if (!controller.signal.aborted) notify(error instanceof Error ? error.message : "Couldn't load players.", true); });
    }, 180);
    return () => { clearTimeout(timer); controller.abort(); };
  }, [search, status, page, revision, notify]);
  async function openPlayer(id: string) {
    setLoadingDetail(true); setDetail(null); setAmount(""); setReason("");
    try {
      const result = await requestJson<PlayerDetail>(`/api/studio/players/${id}`);
      setDetail(result); setNewName(result.player.name);
    } catch (error) { notify(error instanceof Error ? error.message : "Couldn't load player.", true); }
    finally { setLoadingDetail(false); }
  }
  async function act(action: string, extra: Record<string, unknown> = {}) {
    if (!detail) return;
    if (action === "suspend" && !window.confirm(`Suspend ${detail.player.name}? Their active sessions will be revoked.`)) return;
    if ((action === "debit" || action === "credit") && !window.confirm(`${action === "credit" ? "Credit" : "Debit"} ${amount} for ${detail.player.name}? This creates a permanent ledger record.`)) return;
    const id = detail.player.id;
    const saved = await onPost(`/api/studio/players/${id}`, { action, amount, reason, name: newName, ...extra });
    if (saved) { setAmount(""); setReason(""); setRevision((value) => value + 1); await openPlayer(id); }
  }
  return <>
    <Heading eyebrow="WORKSPACE / PLAYERS" title="Your community." description="Find accounts, review activity, and make accountable changes." action={<span className="st-outline-count"><UsersRound size={16} /> {data.counts.players} players</span>} />
    <div className="st-card st-players-card"><div className="st-table-toolbar"><div><h3>All players</h3><p>Every account, one clear view.</p></div><div className="st-table-tools"><label className="st-search-field"><Search size={17} /><input value={search} onChange={(event) => { setSearch(event.target.value); setPage(1); }} placeholder="Search name, email, code..." aria-label="Search players" /></label><select aria-label="Filter player status" value={status} onChange={(event) => { setStatus(event.target.value); setPage(1); }}><option value="all">All status</option><option value="active">Active</option><option value="suspended">Suspended</option></select></div></div><div className="st-table-wrap"><table className="st-table"><thead><tr><th>PLAYER</th><th>STATUS</th><th>WALLET</th><th>ROUNDS</th><th>JOINED</th><th aria-label="Open" /></tr></thead><tbody>{list?.players.map((player) => <tr key={player.id} onClick={() => void openPlayer(player.id)} tabIndex={0} onKeyDown={(event) => { if (event.key === "Enter") void openPlayer(player.id); }}><td><div className="st-person-cell"><Avatar name={player.name} size="small" /><span><strong>{player.name}</strong><small>{player.email}</small></span></div></td><td><Status value={player.isSuspended ? "suspended" : "active"} /></td><td className="st-mono">{formatMoney(player.balanceCents)}</td><td>{player.playCount}</td><td>{formatDate(player.createdAt)}</td><td><ChevronRight size={17} /></td></tr>)}</tbody></table>{list && !list.players.length && <Empty icon={Search} title="No players found" text="Try another name, email, referral code, or filter." />}{!list && <div className="st-table-loading">Loading players...</div>}</div><div className="st-table-footer"><span>Showing {list?.players.length ?? 0} of {list?.total ?? 0} players</span><div><button disabled={page <= 1} onClick={() => setPage((value) => value - 1)} aria-label="Previous page"><ChevronLeft size={17} /></button><span>Page {page} of {Math.max(1, Math.ceil((list?.total ?? 0) / (list?.pageSize ?? 20)))}</span><button disabled={page >= Math.ceil((list?.total ?? 0) / (list?.pageSize ?? 20))} onClick={() => setPage((value) => value + 1)} aria-label="Next page"><ChevronRight size={17} /></button></div></div></div>
    {(detail || loadingDetail) && <div className="st-drawer-backdrop" onMouseDown={() => { setDetail(null); setLoadingDetail(false); }}><aside className="st-player-drawer" onMouseDown={(event) => event.stopPropagation()} aria-label="Player details"><button className="st-drawer-close" onClick={() => { setDetail(null); setLoadingDetail(false); }} aria-label="Close player details"><X size={19} /></button>{!detail ? <p>Loading player...</p> : <><div className="st-drawer-profile"><Avatar name={detail.player.name} /><div><span className="st-eyebrow">PLAYER PROFILE</span><h2>{detail.player.name}</h2><p>{detail.player.email}</p></div></div><div className="st-drawer-summary"><div><small>AVAILABLE WALLET</small><strong>{formatMoney(detail.player.balanceCents)}</strong></div><div><small>GAME ROUNDS</small><strong>{detail.player.playCount}</strong></div><div><small>FRIENDS INVITED</small><strong>{detail.player.inviteCount}</strong></div></div><div className="st-drawer-row"><span>Status</span><Status value={detail.player.isSuspended ? "suspended" : "active"} /></div><div className="st-drawer-row"><span>Referral code</span><strong>{detail.player.referralCode}</strong></div><div className="st-drawer-row"><span>Joined</span><strong>{formatDate(detail.player.createdAt)}</strong></div><section className="st-drawer-section"><h3>Account controls</h3><div className="st-drawer-rename"><input aria-label="Player display name" value={newName} onChange={(event) => setNewName(event.target.value)} maxLength={60} /><button className="st-button st-button-outline" disabled={busy || newName === detail.player.name} onClick={() => void act("rename")}>Save name</button></div><button className={`st-button ${detail.player.isSuspended ? "st-button-outline" : "st-button-danger-outline"}`} disabled={busy} onClick={() => void act(detail.player.isSuspended ? "restore" : "suspend")}>{detail.player.isSuspended ? <UserCheck size={16} /> : <LockKeyhole size={16} />}{detail.player.isSuspended ? "Restore player access" : "Suspend player access"}</button></section><section className="st-drawer-section"><h3>Audited wallet correction</h3><p>Credits use funded prize-pool money. Debits return available wallet funds to the pool. This does not transfer real money.</p><div className="st-drawer-fields"><label>Amount (USD)<input type="number" min="1" max="5000" step="0.01" placeholder="0.00" value={amount} onChange={(event) => setAmount(event.target.value)} /></label><label>Reason (required)<input value={reason} onChange={(event) => setReason(event.target.value)} maxLength={140} placeholder="Why is this correction needed?" /></label></div><div className="st-drawer-actions"><button className="st-button st-button-outline" disabled={busy || !amount || reason.length < 10} onClick={() => void act("debit")}>Debit wallet</button><button className="st-button st-button-dark" disabled={busy || !amount || reason.length < 10} onClick={() => void act("credit")}>Credit wallet</button></div></section><section className="st-drawer-section"><h3>Recent wallet activity</h3>{detail.ledger.length ? detail.ledger.map((entry) => <div className="st-drawer-history" key={entry.id}><span><strong>{entry.description}</strong><small>{formatDate(entry.createdAt)}</small></span><b className={entry.amountCents >= 0 ? "st-positive" : ""}>{entry.amountCents >= 0 ? "+" : "−"}{formatMoney(Math.abs(entry.amountCents))}</b></div>) : <p>No wallet activity yet.</p>}</section><section className="st-drawer-section"><h3>Recent rounds & requests</h3>{detail.plays.slice(0, 5).map((play) => <div className="st-drawer-history" key={play.id}><span><strong>{play.game === "aviator" ? "Aviator" : "Tower Rush"} · {play.status.replaceAll("_", " ")}</strong><small>{formatDate(play.createdAt)}</small></span><b>{formatMoney(play.betCents)}</b></div>)}{detail.requests.slice(0, 5).map((item) => <div className="st-drawer-history" key={item.id}><span><strong>{item.kind} · {item.status}</strong><small>{formatDate(item.createdAt)}</small></span><b>{formatMoney(item.amountCents)}</b></div>)}{!detail.plays.length && !detail.requests.length && <p>No rounds or requests yet.</p>}</section></>}</aside></div>}
  </>;
}

function Payments({ data, onPost, busy }: { data: StudioData; onPost: (path: string, body: Record<string, unknown>) => Promise<ApiResponse | null>; busy: boolean }) {
  const [tab, setTab] = useState<"pending" | "history">("pending");
  const rows = data.requests.filter((item) => tab === "pending" ? item.status === "pending" : item.status !== "pending");
  async function review(item: StudioRequest, decision: "approve" | "reject") {
    if (decision === "approve") {
      const text = item.kind === "withdrawal"
        ? `Have you ALREADY sent ${formatMoney(item.amountCents)} to ${item.userName} outside this app? Marking paid does not send money.`
        : `Have you independently VERIFIED ${formatMoney(item.amountCents)} was received from ${item.userName}? This will credit their wallet.`;
      if (!window.confirm(text)) return;
    } else if (!window.confirm(`Decline this ${item.kind} request? ${item.kind === "withdrawal" ? "Reserved funds will return to the player." : "No wallet funds will be added."}`)) return;
    await onPost("/api/admin", { action: "review", id: item.id, decision });
  }
  return <><Heading eyebrow="FINANCE / WALLET REQUESTS" title="Every request, in hand." description="Review deposits and withdrawals carefully. External transfers happen outside this platform." action={<span className="st-outline-count"><Clock3 size={16} /> {data.counts.pending} to review</span>} /><div className="st-finance-note"><ShieldCheck size={21} /><div><strong>Verify first. Approve second.</strong><span>There is no payment processor connected. A deposit only credits the wallet after independent verification; a withdrawal is only marked paid after you send it externally.</span></div></div><div className="st-payments-layout"><section className="st-card st-payments-card"><div className="st-card-head"><div><span className="st-eyebrow">MANUAL REVIEW</span><h3>Wallet requests</h3></div><div className="st-tab-switch"><button className={tab === "pending" ? "active" : ""} onClick={() => setTab("pending")}>Pending <span>{data.counts.pending}</span></button><button className={tab === "history" ? "active" : ""} onClick={() => setTab("history")}>History</button></div></div><div className="st-payment-list">{rows.length ? rows.map((item) => <article className="st-payment-row" key={item.id}><span className={`st-payment-icon ${item.kind === "deposit" ? "is-deposit" : "is-withdrawal"}`}>{item.kind === "deposit" ? <ArrowDownLeft size={20} /> : <ArrowUpRight size={20} />}</span><div className="st-payment-info"><div><strong>{item.userName}</strong><Status value={item.status} /></div><p>{item.userEmail} · {formatDate(item.createdAt)}</p><small>{item.kind === "deposit" ? "Deposit" : "Withdrawal"} via {item.method.replaceAll("_", " ")}</small>{item.reference && <small>Reference: {item.reference}</small>}{item.payoutDetails && <small className="st-private-detail"><LockKeyhole size={13} /> Payout destination: {item.payoutDetails}</small>}</div><div className="st-payment-action"><strong>{formatMoney(item.amountCents)}</strong>{item.status === "pending" && <div><button className="st-button st-button-outline" disabled={busy} onClick={() => void review(item, "reject")}>Decline</button><button className="st-button st-button-dark" disabled={busy} onClick={() => void review(item, "approve")}>{item.kind === "deposit" ? "Verify & credit" : "Mark paid"}</button></div>}</div></article>) : <Empty icon={CheckCircle2} title={tab === "pending" ? "All caught up" : "No completed requests yet"} text={tab === "pending" ? "There are no requests to review right now." : "Reviewed requests will be recorded here."} />}</div></section><aside className="st-finance-aside"><div className="st-card st-finance-stat"><IconBadge icon={ArrowDownLeft} tone="mint" /><span>Approved deposits</span><strong>{formatMoney(data.counts.depositsCents)}</strong><small>Verified and credited to wallets</small></div><div className="st-card st-finance-stat"><IconBadge icon={ArrowUpRight} tone="violet" /><span>Paid withdrawals</span><strong>{formatMoney(data.counts.withdrawalsCents)}</strong><small>Manually marked after external payout</small></div><div className="st-card st-finance-guide"><span className="st-eyebrow">REVIEW CHECKLIST</span><h3>A safer workflow</h3><p><Check size={15} /> Match the transfer to the request.</p><p><Check size={15} /> Confirm the amount and destination.</p><p><Check size={15} /> Record the decision once verified.</p></div></aside></div></>;
}

function SiteEditor({ data, onPost, busy }: { data: StudioData; onPost: (path: string, body: Record<string, unknown>) => Promise<ApiResponse | null>; busy: boolean }) {
  const [draft, setDraft] = useState<SiteContent>(data.content.draft);
  const dirty = JSON.stringify(draft) !== JSON.stringify(data.content.draft);
  const unpublished = JSON.stringify(draft) !== JSON.stringify(data.content.published);
  const update = <K extends keyof SiteContent>(key: K, value: SiteContent[K]) => setDraft((current) => ({ ...current, [key]: value }));
  async function save(action: "draft" | "publish" | "revert") {
    const done = await onPost("/api/studio/content", { action, content: draft, version: data.content.version });
    if (done && action === "revert") setDraft(data.content.published);
  }
  const switches: { key: keyof SiteContent; title: string; detail: string; icon: LucideIcon }[] = [
    { key: "aviatorEnabled", title: "Aviator", detail: "Allow new flight rounds", icon: Plane },
    { key: "towerEnabled", title: "Tower Rush", detail: "Allow new tower rounds", icon: Layers3 },
    { key: "surveysEnabled", title: "Questionnaires", detail: "Show and accept new responses", icon: FileText },
    { key: "referralsEnabled", title: "Referrals", detail: "Show invites and accept new codes", icon: Gift },
  ];
  return <><Heading eyebrow="BUILD & GROW / SITE EDITOR" title="Make it yours." description="Edit the words and activities players see. Preview, save a draft, then publish when you're ready." action={<span className="st-outline-count"><span className="st-online-dot" /> Live version {data.content.version}</span>} /><div className="st-editor-topline"><span><Globe2 size={16} /> Player site · Homepage</span><span>{unpublished ? "Unpublished changes" : "Everything is published"}</span><a href="/" target="_blank" rel="noreferrer">Open website <ExternalLink size={14} /></a></div><div className="st-editor-layout"><div className="st-editor-forms"><section className="st-card st-editor-section"><div className="st-editor-section-head"><IconBadge icon={PenLine} tone="violet" /><div><h3>Hero section</h3><p>The first thing visitors see on your homepage.</p></div></div><div className="st-field-grid"><label className="st-field st-field-full">Eyebrow text<input value={draft.heroEyebrow} onChange={(event) => update("heroEyebrow", event.target.value)} maxLength={65} /></label><label className="st-field">Main headline<input value={draft.heroTitle} onChange={(event) => update("heroTitle", event.target.value)} maxLength={60} /></label><label className="st-field">Highlight line<input value={draft.heroHighlight} onChange={(event) => update("heroHighlight", event.target.value)} maxLength={60} /></label><label className="st-field st-field-full">Description<textarea value={draft.heroDescription} onChange={(event) => update("heroDescription", event.target.value)} maxLength={260} rows={3} /></label></div></section><section className="st-card st-editor-section"><div className="st-editor-section-head"><IconBadge icon={Bell} tone="peach" /><div><h3>Announcement bar</h3><p>A short update above the homepage banner.</p></div><label className="st-toggle" aria-label="Show announcement"><input type="checkbox" checked={draft.announcementEnabled} onChange={(event) => update("announcementEnabled", event.target.checked)} /><span /></label></div><label className="st-field">Announcement message<input value={draft.announcement} onChange={(event) => update("announcement", event.target.value)} maxLength={160} placeholder="Something exciting is happening..." /></label></section><section className="st-card st-editor-section"><div className="st-editor-section-head"><IconBadge icon={Gamepad2} tone="mint" /><div><h3>Visible activities</h3><p>Switch off new activity access without deleting player history.</p></div></div><div className="st-switch-list">{switches.map((setting) => { const Icon = setting.icon; return <label className="st-switch-row" key={setting.key}><span className="st-switch-icon"><Icon size={18} /></span><span><strong>{setting.title}</strong><small>{setting.detail}</small></span><span className="st-toggle"><input type="checkbox" checked={draft[setting.key] === true} onChange={(event) => update(setting.key, event.target.checked)} /><span /></span></label>; })}</div><p className="st-editor-hint"><Info size={15} /> An existing paid round remains cash-out accessible even when its game is turned off.</p></section></div><aside className="st-editor-preview"><div className="st-preview-head"><div><span className="st-eyebrow">LIVE PREVIEW</span><h3>See it before they do</h3></div><span><span className="st-online-dot" /> Draft view</span></div><div className="st-browser"><div className="st-browser-top"><span className="st-browser-dots"><i /><i /><i /></span><span>lumiplay.com</span><ExternalLink size={13} /></div><div className="st-browser-body"><div className="st-browser-nav"><span>✳ lumi<span>.</span></span><i /><i /><i /></div>{draft.announcementEnabled && <div className="st-preview-announcement">✦ {draft.announcement || "Your announcement here"}</div>}<div className="st-preview-hero"><small>✦ {draft.heroEyebrow || "YOUR MESSAGE"}</small><h4>{draft.heroTitle || "Your headline"}<br /><em>{draft.heroHighlight || "Your highlight"}</em></h4><p>{draft.heroDescription || "Your description will appear here."}</p><b>Explore games →</b><span className="st-preview-planet">✳</span></div><div className="st-preview-cards">{draft.aviatorEnabled && <span><Plane size={15} /> Aviator</span>}{draft.towerEnabled && <span><Layers3 size={15} /> Tower Rush</span>}{draft.surveysEnabled && <span><Gift size={15} /> Rewards</span>}{!draft.aviatorEnabled && !draft.towerEnabled && !draft.surveysEnabled && <small>No activities visible</small>}</div></div></div><div className="st-preview-note"><CheckCircle2 size={16} /> Preview only. Players see the latest published version until you publish.</div><div className="st-publish-actions"><button className="st-button st-button-outline" onClick={() => void save("revert")} disabled={busy || !unpublished}>Reset draft</button><button className="st-button st-button-outline" onClick={() => void save("draft")} disabled={busy || !dirty}>Save draft</button><button className="st-button st-button-dark" onClick={() => void save("publish")} disabled={busy || !unpublished}>Publish to site <ArrowUpRight size={16} /></button></div><p className="st-published-date">{data.content.publishedAt ? `Last published ${formatDate(data.content.publishedAt)}` : "Default content is live. Your first publish creates version 2."}</p></aside></div></>;
}

function GamesSettings({ data, onPost, busy }: { data: StudioData; onPost: (path: string, body: Record<string, unknown>) => Promise<ApiResponse | null>; busy: boolean }) {
  const [rate, setRate] = useState(data.settings.winRate);
  const [fundAmount, setFundAmount] = useState("");
  const [bonus, setBonus] = useState(String(data.settings.referralBonusCents / 100));
  async function fund(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!window.confirm(`Record $${fundAmount} of funds you have actually set aside outside this app? This is not a bank transfer.`)) return;
    if (await onPost("/api/admin", { action: "fund", amount: fundAmount })) setFundAmount("");
  }
  return <><Heading eyebrow="BUILD & GROW / GAMES & ODDS" title="You set the pace." description="Manage transparent game odds and the money reserved for player winnings." action={<span className="st-outline-count"><ShieldCheck size={16} /> Server controlled</span>} /><div className="st-odds-banner"><div><span>FAIRNESS FIRST</span><h2>Clarity makes<br />better play.</h2><p>Players see the configured chance to reach 1.80× before starting. Changes apply to new rounds only.</p></div><div className="st-odds-banner-art">{data.settings.winRate}<small>%</small></div></div><div className="st-settings-grid"><section className="st-card st-settings-panel"><IconBadge icon={SlidersHorizontal} tone="violet" /><h3>Chance to reach 1.80×</h3><p>A round can crash before or after 1.80×. Other cash-out points have different odds.</p><div className="st-rate"><strong>{rate}<span>%</span></strong><small>for new rounds</small></div><input aria-label="Chance to reach 1.80 multiplier" className="st-range" type="range" min="1" max="75" value={rate} onChange={(event) => setRate(Number(event.target.value))} /><div className="st-range-ends"><span>1% less frequent</span><span>75% more frequent</span></div><button className="st-button st-button-dark" onClick={() => void onPost("/api/admin", { action: "rate", rate })} disabled={busy || rate === data.settings.winRate}>Save new chance <ArrowRight size={16} /></button></section><section className="st-card st-settings-panel"><IconBadge icon={Coins} tone="mint" /><h3>Prize pool</h3><p>Money you have independently set aside to cover game winnings and rewards.</p><strong className="st-pool-number">{formatMoney(data.settings.bankrollCents)}</strong><small className="st-pool-caption">Available after active-round reserves</small><form onSubmit={(event) => void fund(event)} className="st-settings-form"><label>Record verified funding (USD)<input type="number" min="1" max="1000000" step="0.01" placeholder="0.00" value={fundAmount} onChange={(event) => setFundAmount(event.target.value)} required /></label><button className="st-button st-button-dark" disabled={busy}>Record funding <Plus size={16} /></button></form></section></div><div className="st-settings-grid st-settings-bottom"><section className="st-card st-settings-panel st-bonus-panel"><IconBadge icon={Gift} tone="peach" /><h3>Referral reward</h3><p>Paid from available prize-pool funds when a referred player qualifies. Applies to future rewards.</p><div className="st-bonus-input"><label>Reward amount (USD)<input type="number" min="1" max="25" step="0.01" value={bonus} onChange={(event) => setBonus(event.target.value)} /></label><button className="st-button st-button-outline" disabled={busy || bonus === String(data.settings.referralBonusCents / 100)} onClick={() => void onPost("/api/admin", { action: "referral_bonus", amount: bonus })}>Save reward</button></div></section><section className="st-card st-settings-panel st-security-panel"><IconBadge icon={LockKeyhole} tone="blue" /><h3>Protected by design</h3><p>The server picks each crash point. The full possible 3.00× payout is reserved before a paid round can start. If the pool is short, new paid rounds cannot start.</p><div><CheckCircle2 size={16} /> No client-side cash settlement</div><div><CheckCircle2 size={16} /> Every balance movement recorded</div></section></div></>;
}

function Features({ data, onPost, busy, notify }: { data: StudioData; onPost: (path: string, body: Record<string, unknown>) => Promise<ApiResponse | null>; busy: boolean; notify: (text: string, error?: boolean) => void }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState("medium");
  const [prompt, setPrompt] = useState("");
  const [asking, setAsking] = useState(false);
  const [messages, setMessages] = useState<{ who: "operator" | "assistant"; text: string }[]>([{ who: "assistant", text: data.aiConfigured ? "Hi! Tell me what you'd like to build next. I can help shape the idea into a practical plan, but publishing new code still needs a development and deployment process." : "Welcome to the planning guide. Describe your idea and I'll outline next steps. Connect OPENAI_API_KEY on the server for conversational AI help; code changes still require development and deployment." }]);
  async function ask(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const message = prompt.trim(); if (message.length < 10) return;
    setMessages((items) => [...items, { who: "operator", text: message }]);
    setPrompt(""); setAsking(true);
    try {
      const result = await requestJson<{ reply: string; mode: "ai" | "planning" }>("/api/studio/assistant", { message });
      setMessages((items) => [...items, { who: "assistant", text: result.reply }]);
    } catch (error) { notify(error instanceof Error ? error.message : "Planning response unavailable.", true); }
    finally { setAsking(false); }
  }
  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const saved = await onPost("/api/studio/features", { action: "create", title, description, priority });
    if (saved) { setTitle(""); setDescription(""); setPriority("medium"); }
  }
  return <><Heading eyebrow="BUILD & GROW / FEATURE LAB" title="What's next starts here." description="Capture an idea, plan it out, and keep your future releases organized." action={<span className="st-outline-count"><WandSparkles size={16} /> {data.features.length} ideas tracked</span>} /><div className="st-feature-callout"><span className="st-feature-callout-icon"><Sparkles size={23} /></span><div><strong>From idea to something real.</strong><p>Site text and activity switches publish right away in Site editor. New functionality needs code, testing, compliance review where relevant, and a real deployment. This workspace plans and tracks that work; it does not deploy code.</p></div><a href="/" target="_blank" rel="noreferrer">View live site <ExternalLink size={15} /></a></div><div className="st-feature-grid"><section className="st-card st-feature-form"><div className="st-card-head"><div><span className="st-eyebrow">CAPTURE AN IDEA</span><h3>Request a feature</h3></div><IconBadge icon={Plus} tone="mint" /></div><p>Write what you want your players or team to be able to do.</p><form onSubmit={(event) => void create(event)}><label>Feature title<input value={title} onChange={(event) => setTitle(event.target.value)} minLength={4} maxLength={100} placeholder="e.g. Player spending limits" required /></label><label>What should it do?<textarea value={description} onChange={(event) => setDescription(event.target.value)} minLength={15} maxLength={1500} placeholder="Describe the experience and why it matters..." rows={5} required /></label><label>Priority<select value={priority} onChange={(event) => setPriority(event.target.value)}><option value="low">Nice to have</option><option value="medium">Important</option><option value="high">High priority</option></select></label><button className="st-button st-button-dark" disabled={busy}>Save & plan feature <ArrowRight size={16} /></button></form></section><section className="st-card st-assistant-card"><div className="st-assistant-top"><span className="st-assistant-avatar"><Sparkles size={22} /></span><div><span className="st-eyebrow">YOUR PLANNING PARTNER</span><h3>Studio assistant</h3></div><span className={`st-assistant-mode ${data.aiConfigured ? "is-ai" : ""}`}><span className="st-online-dot" /> {data.aiConfigured ? "AI connected" : "Planning guide"}</span></div><div className="st-chat-messages" aria-live="polite">{messages.map((message, index) => <div className={`st-chat-message ${message.who === "operator" ? "from-operator" : "from-assistant"}`} key={index}>{message.who === "assistant" && <span className="st-chat-icon"><Sparkles size={13} /></span>}<p>{message.text}</p></div>)}{asking && <div className="st-chat-message from-assistant"><span className="st-chat-icon"><Sparkles size={13} /></span><p>Putting a plan together...</p></div>}</div><form className="st-chat-input" onSubmit={(event) => void ask(event)}><input aria-label="Ask Studio assistant" value={prompt} onChange={(event) => setPrompt(event.target.value)} placeholder="Ask about a new feature..." maxLength={1200} minLength={10} required /><button disabled={asking || prompt.trim().length < 10} aria-label="Send idea"><Send size={17} /></button></form><small>No player personal or payment details are sent to the planning assistant.</small></section></div><div className="st-feature-board"><div className="st-section-title"><div><span className="st-eyebrow">YOUR ROADMAP</span><h2>Ideas in motion</h2></div><span>{data.features.length} saved</span></div>{data.features.length ? <div className="st-feature-list">{data.features.map((feature: StudioFeature) => <article className="st-feature-item" key={feature.id}><div className="st-feature-item-top"><span className={`st-priority st-priority-${feature.priority}`}>{feature.priority} priority</span><Status value={feature.status} /><span>{formatDate(feature.createdAt)}</span></div><h3>{feature.title}</h3><p>{feature.description}</p>{feature.assistantPlan && <details><summary>View planning notes <ChevronDown size={15} /></summary><div>{feature.assistantPlan}</div></details>}<div className="st-feature-item-foot"><span>Tracking status · does not deploy code</span><select aria-label={`Status for ${feature.title}`} value={feature.status} onChange={(event) => void onPost("/api/studio/features", { action: "status", id: feature.id, status: event.target.value })} disabled={busy}><option value="idea">Idea</option><option value="planned">Planned</option><option value="building">Building</option><option value="released">Released (manual)</option></select></div></article>)}</div> : <div className="st-card"><Empty icon={WandSparkles} title="Your next idea goes here" text="Save a feature request to start a thoughtful, trackable roadmap." /></div>}</div></>;
}

function Team({ data, onPost, busy, notify }: { data: StudioData; onPost: (path: string, body: Record<string, unknown>) => Promise<ApiResponse | null>; busy: boolean; notify: (text: string, error?: boolean) => void }) {
  const [email, setEmail] = useState("");
  const [inviteLink, setInviteLink] = useState("");
  async function invite(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const response = await onPost("/api/studio/team", { action: "invite", email });
    if (response && typeof response.inviteCode === "string") {
      setInviteLink(`${window.location.origin}/studio?invite=${response.inviteCode}&email=${encodeURIComponent(email.trim().toLowerCase())}`);
      setEmail("");
    }
  }
  async function copy() {
    try { await navigator.clipboard.writeText(inviteLink); notify("Invitation link copied."); }
    catch { notify("Copy unavailable. Select the link to copy it.", true); }
  }
  return <><Heading eyebrow="SETTINGS / TEAM & SECURITY" title="Keep the right people close." description="Manage operator access, invitations, and the actions taken in Studio." /><div className="st-team-grid"><div className="st-team-main"><section className="st-card st-team-card"><div className="st-card-head"><div><span className="st-eyebrow">ACCESS CONTROL</span><h3>Operators</h3><p>Only trusted operators can access this workspace.</p></div><span className="st-outline-count">{data.team.length} members</span></div><div className="st-team-list">{data.team.map((member) => <div className="st-team-person" key={member.id}><Avatar name={member.name} size="small" /><div><strong>{member.name} {member.id === data.operator.id && <span>YOU</span>}</strong><small>{member.email}</small></div><Status value="active" /></div>)}</div></section><section className="st-card st-team-card"><div className="st-card-head"><div><span className="st-eyebrow">INVITE A TEAMMATE</span><h3>Add an operator</h3><p>Invitation links expire after 48 hours and work once.</p></div><IconBadge icon={UserPlus} tone="violet" /></div><form onSubmit={(event) => void invite(event)} className="st-team-invite-form"><label>New operator email<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="teammate@company.com" required /></label><button className="st-button st-button-dark" disabled={busy}>Create invitation <ArrowRight size={16} /></button></form>{inviteLink && <div className="st-invite-created"><strong><CheckCircle2 size={16} /> Your one-time link is ready</strong><div><input aria-label="New invitation link" readOnly value={inviteLink} /><button onClick={() => void copy()} aria-label="Copy invitation link"><Copy size={16} /></button></div><small>Share privately. For security, this full link is shown only now.</small></div>}{data.invites.some((item) => !item.usedAt && new Date(item.expiresAt) > new Date()) && <div className="st-pending-invites"><h4>Pending invitations</h4>{data.invites.filter((item) => !item.usedAt && new Date(item.expiresAt) > new Date()).map((item) => <div key={`${item.email}-${item.createdAt}`}><span>{item.email}<small>Expires {formatDate(item.expiresAt)}</small></span><button onClick={() => void onPost("/api/studio/team", { action: "revoke", email: item.email })} disabled={busy}>Revoke</button></div>)}</div>}</section><section className="st-card st-team-card"><div className="st-card-head"><div><span className="st-eyebrow">ACCOUNTABILITY</span><h3>Recent operator activity</h3></div><IconBadge icon={History} tone="peach" /></div>{data.audit.length ? <div className="st-audit-list">{data.audit.map((item) => <div key={item.id}><span className="st-audit-dot" /><span><strong>{item.details}</strong><small>{item.actorName} · {formatDate(item.createdAt)}</small></span></div>)}</div> : <Empty icon={History} title="No actions yet" text="Published changes and operator decisions will show up here." />}</section></div><aside className="st-team-side"><div className="st-team-security"><span><ShieldCheck size={23} /></span><h3>Security starts here.</h3><p>Studio uses a separate operator-only session, one-time invitations, hashed passwords, and audited account changes.</p><div><Check size={16} /> No shared operator passwords</div><div><Check size={16} /> Private setup code for first owner</div><div><Check size={16} /> Every wallet correction logged</div></div><div className="st-card st-team-reminder"><KeyRound size={19} /><strong>Keep setup secrets private</strong><p>Never share STUDIO_SETUP_CODE or API keys in chat, website copy, or payment notes. Rotate credentials if exposed.</p></div></aside></div></>;
}

export function StudioApp({ initialData, needsSetup: initialNeedsSetup, setupConfigured, invitation }: {
  initialData: StudioData | null; needsSetup: boolean; setupConfigured: boolean;
  invitation: { code: string; email: string };
}) {
  const [data, setData] = useState<StudioData | null>(initialData);
  const [needsSetup, setNeedsSetup] = useState(initialNeedsSetup);
  const [view, setView] = useState<View>("overview");
  const [search, setSearch] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notification, setNotification] = useState<Notification>(null);
  function notify(text: string, error = false) { setNotification({ text, error }); }
  async function refresh() {
    const updated = await requestJson<StudioData>("/api/studio/overview");
    setData(updated);
    return updated;
  }
  async function onPost(path: string, body: Record<string, unknown>): Promise<ApiResponse | null> {
    setBusy(true);
    try {
      const response = await requestJson<ApiResponse>(path, body);
      await refresh();
      notify(response.message || "Changes saved.");
      return response;
    } catch (error) {
      notify(error instanceof Error ? error.message : "Please try again.", true);
      return null;
    } finally { setBusy(false); }
  }
  function navigate(next: View) { setView(next); setMobileOpen(false); window.scrollTo({ top: 0, behavior: "smooth" }); }
  async function logout() {
    try { await requestJson("/api/studio/auth", { action: "logout" }); setNeedsSetup(false); setData(null); setView("overview"); }
    catch (error) { notify(error instanceof Error ? error.message : "Couldn't sign out.", true); }
  }
  if (!data) return <AuthScreen key={needsSetup ? "setup" : "login"} needsSetup={needsSetup} setupConfigured={setupConfigured} invitation={invitation} onSuccess={(result) => { setNeedsSetup(false); setData(result); }} />;
  const title = nav.flatMap((group) => group.items).find((item) => item.id === view)?.label || "Overview";
  return <div className="st-shell"><aside className={`st-sidebar ${mobileOpen ? "st-sidebar-open" : ""}`}><div className="st-sidebar-brand"><StudioMark inverted /><button className="st-mobile-close" aria-label="Close menu" onClick={() => setMobileOpen(false)}><X size={21} /></button></div><div className="st-sidebar-tenant"><span className="st-tenant-icon"><Globe2 size={18} /></span><span><strong>LumiPlay</strong><small>Live workspace</small></span><ChevronDown size={15} /></div><nav className="st-sidebar-nav">{nav.map((group) => <div className="st-nav-group" key={group.label}><p>{group.label}</p>{group.items.map((item) => { const Icon = item.icon; return <button key={item.id} className={view === item.id ? "selected" : ""} onClick={() => navigate(item.id)}><Icon size={18} strokeWidth={view === item.id ? 2.3 : 1.85} /><span>{item.label}</span>{item.id === "payments" && data.counts.pending > 0 && <b>{data.counts.pending}</b>}{item.id === "features" && <span className="st-nav-star">✦</span>}</button>; })}</div>)}</nav><div className="st-sidebar-spacer" /><div className="st-sidebar-support"><span>✳</span><strong>Your space to create.</strong><p>Site copy publishes now. New features need a development release.</p><button onClick={() => navigate("features")}>Plan a feature <ArrowRight size={14} /></button></div><a className="st-sidebar-live" href="/" target="_blank" rel="noreferrer"><ExternalLink size={17} /> Visit player website <ArrowUpRight size={15} /></a><div className="st-sidebar-user"><Avatar name={data.operator.name} size="small" /><span><strong>{data.operator.name}</strong><small>Operator account</small></span><button onClick={() => void logout()} aria-label="Sign out"><LogOut size={18} /></button></div></aside>{mobileOpen && <button className="st-mobile-backdrop" aria-label="Close menu" onClick={() => setMobileOpen(false)} />}
    <div className="st-main"><header className="st-topbar"><div className="st-topbar-left"><button className="st-menu-button" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu size={22} /></button><div className="st-crumb"><span>Workspace</span><ChevronRight size={15} /><strong>{title}</strong></div></div><div className="st-topbar-right"><label className="st-global-search"><Search size={17} /><input aria-label="Find a player" placeholder="Search players..." value={search} onChange={(event) => { setSearch(event.target.value); if (event.target.value) setView("players"); }} /><span>⌘ K</span></label><span className="st-header-live"><i /> Site live</span><a className="st-header-link" href="/" target="_blank" rel="noreferrer" aria-label="Open player website"><ExternalLink size={18} /></a><span className="st-header-divider" /><Avatar name={data.operator.name} size="small" /></div></header><main className="st-content">{view === "overview" && <Overview data={data} navigate={navigate} />}{view === "players" && <Players data={data} search={search} setSearch={setSearch} onPost={onPost} notify={notify} busy={busy} />}{view === "payments" && <Payments data={data} onPost={onPost} busy={busy} />}{view === "site" && <SiteEditor data={data} onPost={onPost} busy={busy} />}{view === "games" && <GamesSettings data={data} onPost={onPost} busy={busy} />}{view === "features" && <Features data={data} onPost={onPost} busy={busy} notify={notify} />}{view === "team" && <Team data={data} onPost={onPost} busy={busy} notify={notify} />}<footer className="st-footer"><span>✳ &nbsp; Lumi Studio · Connected to LumiPlay</span><span>Operator-only workspace &nbsp;·&nbsp; 18+ responsible play</span></footer></main></div>{notification && <div className={`st-toast ${notification.error ? "is-error" : ""}`} role="status"><span>{notification.error ? <Info size={18} /> : <CheckCircle2 size={18} />}</span><p>{notification.text}</p><button onClick={() => setNotification(null)} aria-label="Dismiss notification"><X size={16} /></button></div>}
  </div>;
}
