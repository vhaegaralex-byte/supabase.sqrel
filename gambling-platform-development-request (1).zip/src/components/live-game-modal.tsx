"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowRight, CheckCircle2, Clock3, Coins, Info, Layers3, Plane, Play, RefreshCw, ShieldCheck, Sparkles, Wallet, X, Zap } from "lucide-react";
import {
  MAX_CASHOUT_BPS, ROUND_DURATION_MS, formatMoney, formatMultiplier, multiplierAt,
  type DashboardData, type GameId, type LiveRound,
} from "@/lib/shared";

type GameMode = "demo" | "paid";
type Phase = "idle" | "starting" | "live" | "result";
type RoundResult = {
  status: "cashed_out" | "crashed";
  demo: boolean;
  betCents: number;
  payoutCents: number;
  multiplierBps: number;
  crashMultiplierBps: number | null;
};

type Props = {
  game: GameId;
  user: DashboardData["user"];
  activeRound: LiveRound | null;
  winRate: number;
  bankrollCents: number;
  onClose: () => void;
  onAuth: () => void;
  onResume: (game: GameId) => void;
  onRefresh: () => Promise<void>;
  notify: (message: string, error?: boolean) => void;
};

async function postPlay(body: Record<string, unknown>): Promise<LiveRound> {
  const response = await fetch("/api/play", {
    method: "POST", headers: { "Content-Type": "application/json" },
    credentials: "same-origin", body: JSON.stringify(body),
  });
  const payload = await response.json().catch(() => ({})) as LiveRound & { error?: string };
  if (!response.ok) throw new Error(payload.error || "The round couldn't be updated. Please try again.");
  return payload;
}

function demoCrashPoint(winRate: number) {
  const draws = new Uint32Array(2);
  window.crypto.getRandomValues(draws);
  const reachesReference = draws[0] / 2 ** 32 < winRate / 100;
  return reachesReference ? 18_001 + draws[1] % 16_000 : 10_000 + draws[1] % 8_000;
}

export function LiveGameModal({ game, user, activeRound, winRate, bankrollCents, onClose, onAuth, onResume, onRefresh, notify }: Props) {
  const resumed = activeRound?.game === game ? activeRound : null;
  const otherRound = activeRound && activeRound.game !== game ? activeRound : null;
  const [mode, setMode] = useState<GameMode>(resumed ? "paid" : "demo");
  const [amount, setAmount] = useState(resumed ? String(resumed.betCents / 100) : "5");
  const [phase, setPhase] = useState<Phase>(resumed ? "live" : "idle");
  const [round, setRound] = useState<LiveRound | null>(resumed);
  const [result, setResult] = useState<RoundResult | null>(null);
  const [displayBps, setDisplayBps] = useState(resumed ? resumed.multiplierBps : 10_000);
  const [cashoutPending, setCashoutPending] = useState(false);
  const [connectionIssue, setConnectionIssue] = useState(false);
  const demoStartedAt = useRef(0);
  const demoCrashBps = useRef(0);
  const clockOffset = useRef(0);
  const settled = useRef(false);
  const card = game === "aviator"
    ? { title: "Aviator", subtitle: "Take flight. Time your cash out.", icon: Plane, image: "/images/aviator-game.jpg" }
    : { title: "Tower Rush", subtitle: "Watch it rise. Bank it before it falls.", icon: Layers3, image: "/images/tower-game.jpg" };
  const CardIcon = card.icon;

  function finishDemo(status: "cashed_out" | "crashed", bps: number) {
    if (settled.current) return;
    settled.current = true;
    const betCents = Math.round(Number(amount) * 100);
    setDisplayBps(bps);
    setResult({
      status, demo: true, betCents,
      payoutCents: status === "cashed_out" ? Math.floor(betCents * bps / 10_000) : 0,
      multiplierBps: bps, crashMultiplierBps: status === "crashed" ? bps : null,
    });
    setPhase("result");
  }

  function finishPaid(next: LiveRound) {
    if (settled.current || next.status === "active") return;
    settled.current = true;
    setDisplayBps(next.multiplierBps);
    setResult({
      status: next.status === "crashed" ? "crashed" : "cashed_out",
      demo: false, betCents: next.betCents, payoutCents: next.payoutCents,
      multiplierBps: next.multiplierBps, crashMultiplierBps: next.crashMultiplierBps,
    });
    setPhase("result");
    void onRefresh().catch(() => notify("Round settled, but your wallet couldn't refresh. Reopen your wallet to check it.", true));
  }

  useEffect(() => {
    if (phase !== "live") return;
    let frame = 0;
    let lastFrame = 0;
    const tick = (time: number) => {
      if (time - lastFrame >= 45) {
        lastFrame = time;
        if (mode === "demo") {
          const elapsed = Date.now() - demoStartedAt.current;
          const crashMs = Math.ceil((demoCrashBps.current - 10_000) * 2 / 5);
          if (elapsed >= crashMs && crashMs <= ROUND_DURATION_MS) {
            finishDemo("crashed", demoCrashBps.current);
            return;
          }
          if (elapsed >= ROUND_DURATION_MS) {
            finishDemo("cashed_out", MAX_CASHOUT_BPS);
            return;
          }
          setDisplayBps(multiplierAt(demoStartedAt.current, Date.now()));
        } else if (round) {
          setDisplayBps(multiplierAt(new Date(round.startedAt).getTime(), Date.now() + clockOffset.current));
        }
      }
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  // A running round's start timestamp does not change. The clock is intentionally driven by rAF.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, mode, round?.id]);

  useEffect(() => {
    if (phase !== "live" || mode !== "paid" || !round?.id) return;
    let alive = true;
    let inFlight = false;
    const poll = async () => {
      if (inFlight) return;
      inFlight = true;
      try {
        const response = await fetch(`/api/play?roundId=${encodeURIComponent(round.id)}`, {
          credentials: "same-origin", cache: "no-store",
        });
        if (!response.ok) throw new Error("The connection was interrupted.");
        const current = await response.json() as LiveRound;
        if (!alive) return;
        setConnectionIssue(false);
        if (current.status !== "active") finishPaid(current);
        else clockOffset.current = new Date(current.serverTime).getTime() - Date.now();
      } catch {
        if (alive) setConnectionIssue(true);
      } finally {
        inFlight = false;
      }
    };
    void poll();
    const timer = setInterval(() => void poll(), 350);
    return () => { alive = false; clearInterval(timer); };
  // The round ID is stable throughout this polling session.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, mode, round?.id]);

  async function start() {
    if (phase === "live" || phase === "starting" || otherRound) return;
    const stake = Number(amount);
    if (!Number.isFinite(stake) || stake < 1 || stake > 100 || !/^\d+(?:\.\d{1,2})?$/.test(amount)) {
      notify("Choose a stake between $1 and $100, with up to two decimals.", true);
      return;
    }
    if (mode === "paid" && !user) { onClose(); onAuth(); return; }
    settled.current = false;
    setResult(null);
    setDisplayBps(10_000);
    setConnectionIssue(false);
    if (mode === "demo") {
      demoCrashBps.current = demoCrashPoint(winRate);
      demoStartedAt.current = Date.now();
      setPhase("live");
      return;
    }
    setPhase("starting");
    try {
      const started = await postPlay({ action: "start", game, amount });
      clockOffset.current = new Date(started.serverTime).getTime() - Date.now();
      setRound(started);
      setAmount(String(started.betCents / 100));
      setPhase("live");
      void onRefresh().catch(() => {});
    } catch (error) {
      setPhase("idle");
      notify(error instanceof Error ? error.message : "Unable to start the round.", true);
      void onRefresh().catch(() => {});
    }
  }

  async function cashOut() {
    if (phase !== "live" || cashoutPending) return;
    if (mode === "demo") {
      const elapsed = Date.now() - demoStartedAt.current;
      const crashMs = Math.ceil((demoCrashBps.current - 10_000) * 2 / 5);
      if (elapsed >= crashMs && crashMs <= ROUND_DURATION_MS) finishDemo("crashed", demoCrashBps.current);
      else if (elapsed >= ROUND_DURATION_MS) finishDemo("cashed_out", MAX_CASHOUT_BPS);
      else finishDemo("cashed_out", multiplierAt(demoStartedAt.current, Date.now()));
      return;
    }
    if (!round) return;
    setCashoutPending(true);
    try {
      const final = await postPlay({ action: "cashout", roundId: round.id });
      finishPaid(final);
    } catch (error) {
      notify(error instanceof Error ? error.message : "Cash out couldn't be confirmed. Check the live round status.", true);
      setConnectionIssue(true);
    } finally {
      setCashoutPending(false);
    }
  }

  const stageBps = result?.multiplierBps ?? displayBps;
  const progress = Math.min(1, Math.max(0, (stageBps - 10_000) / 20_000));
  const planeX = 34 + progress * 440;
  const planeY = 219 - Math.pow(progress, 1.4) * 164;
  const flightPath = `M 24 225 Q ${Math.max(70, planeX * .53)} ${223 - progress * 28} ${planeX} ${planeY}`;
  const levelsBuilt = Math.min(7, Math.max(0, Math.floor(progress * 7) + (phase === "live" ? 1 : 0)));
  const stakeCents = phase === "live" && mode === "paid" && round ? round.betCents : Math.round((Number(amount) || 0) * 100);
  const estimatedPayout = Math.floor(stakeCents * stageBps / 10_000);
  const isPlaying = phase === "live" || phase === "starting";

  return <div className="modal-backdrop" onMouseDown={onClose}>
    <div className="dialog live-dialog" role="dialog" aria-modal="true" aria-label={`${card.title} live game`} onMouseDown={(event) => event.stopPropagation()}>
      <button className="dialog-close" onClick={onClose} aria-label="Close game"><X size={19} /></button>
      <div className={`live-arena live-arena-${game} ${phase === "live" ? "live-arena-running" : ""} ${result?.status === "crashed" ? "live-arena-crashed" : ""}`}
        style={{ backgroundImage: `linear-gradient(180deg, rgba(12,17,36,.52), rgba(7,15,30,.92)), url('${card.image}')` }}>
        <div className="live-arena-top">
          <span className="live-status"><span className={phase === "live" ? "live-status-pulse" : ""} />{phase === "live" ? "ROUND LIVE" : phase === "starting" ? "STARTING" : result ? "ROUND COMPLETE" : "READY TO PLAY"}</span>
          <span className="live-mode-badge">{mode === "demo" ? <><Sparkles size={13} /> FREE DEMO</> : <><Coins size={13} /> PAID ROUND</>}</span>
        </div>
        <div className="live-arena-heading"><span>{game === "aviator" ? "SKY RUN · 01" : "TOWER CLIMB · 02"}</span><h3>{card.title}</h3></div>
        <div className="live-multiplier" aria-live={phase === "result" ? "polite" : "off"}>
          <span>{phase === "live" ? game === "aviator" ? "THE PLANE IS FLYING" : "THE TOWER IS RISING" : result?.status === "crashed" ? game === "aviator" ? "THE PLANE CRASHED" : "THE TOWER FELL" : result ? "NICE TIMING — CASHED OUT" : phase === "starting" ? "GETTING READY" : "WATCH IT CLIMB"}</span>
          <strong className={result?.status === "crashed" ? "multiplier-crashed" : ""}>{formatMultiplier(stageBps)}</strong>
          <small>{phase === "live" ? "Cash out before the round ends" : result?.status === "crashed" ? "Stake lost this round" : result ? `${result.demo ? "Demo" : "Wallet"} payout ${formatMoney(result.payoutCents)}` : "Your moment. Your call."}</small>
        </div>
        <div className="live-scene" aria-hidden="true">
          {game === "aviator" ? <>
            <div className="live-graph-lines" />
            <svg className="live-flight-svg" viewBox="0 0 520 260" preserveAspectRatio="none">
              <defs><linearGradient id="flightGlow" x1="0" x2="1"><stop stopColor="#ffc8e4" /><stop offset="1" stopColor="#d7f889" /></linearGradient></defs>
              <path d={flightPath} fill="none" stroke="#ff78b8" opacity=".24" strokeWidth="18" strokeLinecap="round" />
              <path d={flightPath} fill="none" stroke="url(#flightGlow)" strokeWidth="4" strokeLinecap="round" />
              <circle cx={planeX} cy={planeY} r="6" fill="#eaffc3" />
            </svg>
            <span className="live-plane" style={{ left: `${7 + progress * 81}%`, bottom: `${10 + progress * 61}%` }}><Plane size={31} strokeWidth={2.2} /></span>
            <span className="live-graph-axis">1.00× <i /> 1.80× <i /> 3.00×</span>
          </> : <>
            <div className="live-tower-halo" />
            <div className={`live-tower-stack ${result?.status === "crashed" ? "tower-falling" : ""}`}>
              {Array.from({ length: 7 }, (_, index) => <span key={index}
                className={`live-tower-block ${index < levelsBuilt ? "tower-block-built" : ""}`}
                style={{ width: `${192 - index * 14}px`, transitionDelay: `${index * 35}ms` }}>
                <span>{String(index + 1).padStart(2, "0")}</span><span>{index < levelsBuilt ? "✦" : "·"}</span>
              </span>)}
            </div>
            <span className="live-tower-base">BUILD · HOLD · CASH OUT</span>
          </>}
        </div>
        <div className="live-arena-footer"><span><ShieldCheck size={14} /> {mode === "demo" ? "Practice only · no cash value" : "Server decides the final outcome"}</span><span>MAX {formatMultiplier(MAX_CASHOUT_BPS)}</span></div>
      </div>

      <div className="live-controls">
        <div className="live-control-heading"><span className="live-icon"><CardIcon size={19} /></span><div><span className="section-eyebrow">LIVE CASH-OUT GAME</span><h2>{card.title}</h2></div></div>
        <p className="live-description">{card.subtitle} The multiplier rises in real time. Cash out before the round crashes to collect the displayed multiplier.</p>
        <div className="live-odds"><span><Zap size={15} /> {phase === "live" && mode === "paid" && round ? round.winRate : winRate}% chance to reach 1.80×</span><span>Up to 3.00×</span></div>
        {otherRound && <div className="live-other-round"><Info size={19} /><p>Your {otherRound.game === "aviator" ? "Aviator" : "Tower Rush"} round is still live. Reopen it to watch and cash out.</p><button className="button button-secondary button-small" onClick={() => onResume(otherRound.game)}>Resume round <ArrowRight size={15} /></button></div>}
        {phase === "live" ? <>
          <div className="live-running-panel"><div><small>YOUR STAKE</small><strong>{formatMoney(stakeCents)}</strong></div><div><small>ESTIMATED CASH OUT</small><strong className="live-green">{formatMoney(estimatedPayout)}</strong></div></div>
          <div className="live-risk-track"><span style={{ width: `${Math.max(2, progress * 100)}%` }} /></div>
          <div className="live-risk-labels"><span>1.00×</span><span>1.80×</span><span>3.00×</span></div>
          <button className="button button-primary live-action live-cashout-button" onClick={() => void cashOut()} disabled={cashoutPending}>
            {cashoutPending ? "Confirming cash out..." : <>Cash out · {formatMoney(estimatedPayout)} <ArrowRight size={20} /></>}
          </button>
          {connectionIssue && <p className="live-connection"><Info size={15} /> Reconnecting. Only the server can confirm a paid cash out.</p>}
          <p className="live-smallprint">{mode === "paid" ? "Estimate only — the server uses the multiplier when your request arrives. Closing this window will not pause the round." : "Demo only — this round cannot add money to your wallet."}</p>
        </> : <>
          {result && <div className={`live-result-panel ${result.status === "crashed" ? "result-lost" : "result-cashed"}`}><span>{result.status === "crashed" ? <RefreshCw size={19} /> : <CheckCircle2 size={19} />}</span><div><strong>{result.status === "crashed" ? "This round crashed" : `Cashed out at ${formatMultiplier(result.multiplierBps)}`}</strong><p>{result.status === "crashed" ? `${formatMoney(result.betCents)} ${result.demo ? "demo stake" : "stake"} was lost. Try another round if you wish.` : `${formatMoney(result.payoutCents)} ${result.demo ? "in demo winnings (not withdrawable)" : "credited to your wallet"}.`}</p></div></div>}
          <div className="live-mode-switch" role="group" aria-label="Play mode"><button type="button" className={mode === "demo" ? "selected" : ""} onClick={() => setMode("demo")} disabled={isPlaying}><Sparkles size={16} /> Free demo</button><button type="button" className={mode === "paid" ? "selected" : ""} onClick={() => setMode("paid")} disabled={isPlaying}><Wallet size={16} /> Play for money</button></div>
          <label className="form-label" htmlFor={`live-stake-${game}`}>Your {mode === "demo" ? "demo " : ""}stake<div className="input-with-prefix"><span>$</span><input id={`live-stake-${game}`} type="number" min="1" max="100" step="0.01" value={amount} onChange={(event) => setAmount(event.target.value)} disabled={isPlaying} /></div></label>
          <div className="live-stakes">{[1, 5, 10, 25].map((value) => <button key={value} type="button" className={amount === String(value) ? "selected" : ""} onClick={() => setAmount(String(value))} disabled={isPlaying}>${value}</button>)}</div>
          <div className="live-preview"><span>At 1.80× you could cash out</span><strong>{formatMoney(Math.floor(stakeCents * 1.8))}</strong></div>
          <button className="button button-primary live-action" onClick={() => void start()} disabled={isPlaying || !!otherRound}>
            {phase === "starting" ? "Starting your round..." : mode === "paid" && !user ? "Create account to play" : result ? "Play another round" : mode === "demo" ? "Start free demo" : "Start live round"}
            {phase === "starting" ? <RefreshCw size={18} className="live-spin" /> : <Play size={17} fill="currentColor" />}
          </button>
          <p className="live-smallprint">{mode === "demo" ? "Free practice · no real funds, no withdrawals." : `Wallet: ${formatMoney(user?.balanceCents ?? 0)} · Available prize pool: ${formatMoney(bankrollCents)}`}</p>
        </>}
        <div className="live-rule-note"><Info size={16} /><span>The configured chance is the chance to <strong>reach 1.80×</strong>, not a guaranteed win. Cashing out earlier or later has different odds; a round can crash at any moment. At 3.00× a surviving round is cashed out automatically.</span></div>
      </div>
    </div>
  </div>;
}
