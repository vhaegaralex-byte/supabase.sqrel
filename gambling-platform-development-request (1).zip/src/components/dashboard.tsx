"use client";

import { useEffect, useRef, useState, useSyncExternalStore, type FormEvent, type ReactNode } from "react";
import {
  Activity, ArrowDownLeft, ArrowRight, ArrowUpRight, BadgeCheck, Bell, CalendarDays,
  Check, CheckCircle2, ChevronDown, ChevronRight, CircleHelp, Clock3, Coins, Copy,
  CreditCard, ExternalLink, Gift, Gamepad2, History, Info, Layers3, LayoutDashboard, LockKeyhole,
  LogOut, Menu, Minus, Plane, Play, Plus, RefreshCw, Search, Send, Settings2,
  ShieldCheck, SlidersHorizontal, Smartphone, Sparkles, Target, TrendingUp, Trophy,
  UsersRound, Wallet, X, Zap, type LucideIcon,
} from "lucide-react";
import { LiveGameModal } from "@/components/live-game-modal";
import {
  formatDate, formatMoney, formatMultiplier, surveys,
  type AdminRequestView, type DashboardData, type GameId, type PageId, type TransactionView,
} from "@/lib/shared";

type ModalState =
  | { type: "auth"; mode: "login" | "register" }
  | { type: "game"; game: GameId }
  | { type: "wallet"; mode: "deposit" | "withdrawal" }
  | { type: "survey"; surveyId: string }
  | null;

type Toast = { message: string; error: boolean } | null;

const gameCards = [
  { id: "aviator" as const, title: "Aviator", subtitle: "Take off. Time your moment.", image: "/images/aviator-game.jpg", tag: "INSTANT PLAY", icon: Plane, tone: "pink" },
  { id: "tower" as const, title: "Tower Rush", subtitle: "Stack your way to the top.", image: "/images/tower-game.jpg", tag: "FAN FAVORITE", icon: Layers3, tone: "blue" },
];

const navGroups: { label: string; items: { id: PageId; label: string; icon: LucideIcon }[] }[] = [
  { label: "DISCOVER", items: [
    { id: "overview", label: "Overview", icon: LayoutDashboard },
    { id: "games", label: "Games", icon: Gamepad2 },
    { id: "earn", label: "Earn rewards", icon: Gift },
  ] },
  { label: "YOUR SPACE", items: [
    { id: "wallet", label: "My wallet", icon: Wallet },
    { id: "referrals", label: "Referrals", icon: UsersRound },
    { id: "activity", label: "Activity", icon: History },
  ] },
];

async function postJson<T>(path: string, body: unknown): Promise<T> {
  const response = await fetch(path, {
    method: "POST", headers: { "Content-Type": "application/json" },
    credentials: "same-origin", body: JSON.stringify(body),
  });
  const payload = await response.json().catch(() => ({})) as { error?: string };
  if (!response.ok) throw new Error(payload.error || "Please try again.");
  return payload as T;
}

function Logo({ compact = false }: { compact?: boolean }) {
  return <div className={`brand ${compact ? "brand-compact" : ""}`}>
    <div className="brand-mark"><Sparkles size={22} strokeWidth={2.5} /></div>
    <span>lumi<span className="brand-dot">.</span><small>PLAY</small></span>
  </div>;
}

function StatusPill({ status }: { status: string }) {
  const label = status === "paid" ? "Paid" : status === "approved" ? "Approved" : status === "rejected" ? "Declined" : "Pending";
  return <span className={`status-pill status-${status}`}><span className="status-dot" />{label}</span>;
}

function SectionHeading({ eyebrow, title, action, onAction }: { eyebrow?: string; title: string; action?: string; onAction?: () => void }) {
  return <div className="section-heading">
    <div>{eyebrow && <p className="section-eyebrow">{eyebrow}</p>}<h2>{title}</h2></div>
    {action && <button className="text-link" onClick={onAction}>{action}<ArrowRight size={17} /></button>}
  </div>;
}

function PageIntro({ eyebrow, title, description, aside }: { eyebrow: string; title: string; description: string; aside?: ReactNode }) {
  return <div className="page-intro">
    <div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p className="intro-subtitle">{description}</p></div>
    {aside}
  </div>;
}

function GameCard({ card, onOpen }: { card: (typeof gameCards)[number]; onOpen: () => void }) {
  const Icon = card.icon;
  return <article className="feature-card game-feature">
    <button className={`feature-art feature-art-${card.tone}`} style={{ backgroundImage: `url('${card.image}')` }} onClick={onOpen} aria-label={`Open ${card.title}`}>
      <span className="art-label"><span className="live-dot" />{card.tag}</span>
      <span className="art-corner"><ArrowUpRight size={19} /></span>
    </button>
    <div className="feature-body">
      <div className="feature-title-row"><span className={`feature-icon feature-icon-${card.tone}`}><Icon size={19} /></span><div><h3>{card.title}</h3><p>{card.subtitle}</p></div></div>
      <div className="feature-footer"><span><Zap size={14} /> Live cash-out</span><button onClick={onOpen}>Play now <ArrowRight size={16} /></button></div>
    </div>
  </article>;
}

function SurveyFeatureCard({ onOpen }: { onOpen: () => void }) {
  return <article className="feature-card game-feature">
    <button className="feature-art feature-art-purple" style={{ backgroundImage: "url('/images/survey-game.jpg')" }} onClick={onOpen} aria-label="Explore questionnaires">
      <span className="art-label art-label-purple"><span className="live-dot" />EARN REWARDS</span>
      <span className="art-corner"><ArrowUpRight size={19} /></span>
    </button>
    <div className="feature-body">
      <div className="feature-title-row"><span className="feature-icon feature-icon-purple"><Gift size={19} /></span><div><h3>Quick questionnaires</h3><p>Share your thoughts. Get rewarded.</p></div></div>
      <div className="feature-footer"><span><Clock3 size={14} /> 2–3 minutes</span><button onClick={onOpen}>Explore <ArrowRight size={16} /></button></div>
    </div>
  </article>;
}

function EmptyState({ icon: Icon, title, detail, action, onAction }: { icon: LucideIcon; title: string; detail: string; action?: string; onAction?: () => void }) {
  return <div className="empty-state"><span className="empty-icon"><Icon size={25} /></span><h3>{title}</h3><p>{detail}</p>{action && <button className="button button-secondary button-small" onClick={onAction}>{action}<ArrowRight size={15} /></button>}</div>;
}

function TransactionList({ entries, limit = 8 }: { entries: TransactionView[]; limit?: number }) {
  if (!entries.length) return <EmptyState icon={Activity} title="Nothing here yet" detail="Your wallet activity will appear here after your first transaction." />;
  return <div className="transaction-list">{entries.slice(0, limit).map((entry) => {
    const positive = entry.amountCents > 0;
    const Icon = entry.kind === "win" ? Trophy : entry.kind === "cashout" ? Zap : entry.kind === "survey" ? Gift : entry.kind === "referral" ? UsersRound : positive ? ArrowDownLeft : ArrowUpRight;
    return <div className="transaction-row" key={entry.id}>
      <span className={`transaction-icon ${positive ? "transaction-positive" : "transaction-negative"}`}><Icon size={18} /></span>
      <div className="transaction-description"><strong>{entry.description}</strong><span>{formatDate(entry.createdAt)}</span></div>
      <strong className={positive ? "money-positive" : "money-negative"}>{positive ? "+" : "−"}{formatMoney(Math.abs(entry.amountCents))}</strong>
    </div>;
  })}</div>;
}

function GuestGate({ title, detail, onJoin }: { title: string; detail: string; onJoin: () => void }) {
  return <div className="guest-gate"><span className="guest-gate-icon"><LockKeyhole size={28} /></span><h2>{title}</h2><p>{detail}</p><button className="button button-primary" onClick={onJoin}>Create your account <ArrowRight size={18} /></button><span>Already have an account? <button onClick={onJoin}>Get started</button></span></div>;
}

function Overview({ data, navigate, openGame, openSurvey, openWallet, openAuth }: {
  data: DashboardData; navigate: (page: PageId) => void; openGame: (game: GameId) => void;
  openSurvey: () => void; openWallet: (mode: "deposit" | "withdrawal") => void; openAuth: () => void;
}) {
  const name = data.user?.name.split(" ")[0];
  return <>
    <PageIntro eyebrow="YOUR PLAYGROUND" title={name ? `Good to see you, ${name} ✳` : "A little more play in your day ✳"} description="A fresh way to play, explore, and get rewarded. Make yourself at home." aside={<div className="date-chip"><CalendarDays size={16} /> Your space, your pace</div>} />
    {data.content.announcementEnabled && <div className="player-announcement"><Sparkles size={17} /><span>{data.content.announcement}</span></div>}
    <section className="hero-banner">
      <div className="hero-image" />
      <div className="hero-content"><span className="hero-kicker"><span className="hero-kicker-star">✦</span> {data.content.heroEyebrow}</span>
        <h2>{data.content.heroTitle}<br /><em>{data.content.heroHighlight}</em></h2>
        <p>{data.content.heroDescription}</p>
        <div className="hero-actions"><button className="button button-primary" onClick={() => navigate("games")}>Explore games <ArrowUpRight size={18} /></button><button className="button button-ghost" onClick={() => navigate("help")}><span className="play-circle"><Play size={12} fill="currentColor" /></span> How it works</button></div>
      </div>
      <div className="hero-float hero-float-top"><span className="float-spark">✳</span><span>Make it<br /><strong>your moment</strong></span></div>
    </section>
    {data.activeRound && <button className="resume-round-banner" onClick={() => data.activeRound && openGame(data.activeRound.game)}><span className="resume-round-icon">{data.activeRound.game === "aviator" ? <Plane size={21} /> : <Layers3 size={21} />}</span><span><strong>Your {data.activeRound.game === "aviator" ? "Aviator" : "Tower Rush"} round is live</strong><small>Jump back in to watch and cash out before it ends.</small></span><span className="resume-round-link">Resume round <ArrowRight size={17} /></span></button>}
    <section className={`stats-grid stats-grid-${1 + Number(data.content.referralsEnabled) + Number(data.content.surveysEnabled)}`}>
      <button className="stat-card" onClick={() => navigate("wallet")}><span className="stat-icon stat-green"><Wallet size={20} /></span><span className="stat-copy"><small>Wallet balance</small><strong>{formatMoney(data.user?.balanceCents ?? 0)}</strong><span>{data.user ? "Available to play or withdraw" : "Sign up to get started"}</span></span><ChevronRight className="stat-arrow" size={18} /></button>
      {data.content.referralsEnabled && <button className="stat-card" onClick={() => navigate("referrals")}><span className="stat-icon stat-purple"><UsersRound size={20} /></span><span className="stat-copy"><small>Referral rewards</small><strong>{formatMoney(data.referral.earnedCents)}</strong><span>{data.referral.invited} {data.referral.invited === 1 ? "friend" : "friends"} invited so far</span></span><ChevronRight className="stat-arrow" size={18} /></button>}
      {data.content.surveysEnabled && <button className="stat-card" onClick={() => navigate("earn")}><span className="stat-icon stat-orange"><Gift size={20} /></span><span className="stat-copy"><small>Questionnaires</small><strong>{data.completions.length} <span className="stat-denominator">/ {surveys.length}</span></strong><span>Small questions, real rewards</span></span><ChevronRight className="stat-arrow" size={18} /></button>}
    </section>
    <section className="section-block"><SectionHeading eyebrow="PICK YOUR NEXT ADVENTURE" title="Something fun for everyone" action="See all activities" onAction={() => navigate("games")} /><div className="feature-grid">{gameCards.filter((card) => card.id === "aviator" ? data.content.aviatorEnabled : data.content.towerEnabled).map((card) => <GameCard key={card.id} card={card} onOpen={() => openGame(card.id)} />)}{data.content.surveysEnabled && <SurveyFeatureCard onOpen={openSurvey} />}{!data.content.aviatorEnabled && !data.content.towerEnabled && !data.content.surveysEnabled && <p className="no-results">New activities are being prepared. Check back soon.</p>}</div></section>
    <div className={`lower-grid ${data.content.referralsEnabled ? "" : "lower-grid-single"}`}>
      {data.content.referralsEnabled && <section className="referral-promo"><div className="promo-rings" /><span className="mini-kicker">BETTER TOGETHER</span><h2>Good things are<br />better shared.</h2><p>Invite a friend. When their first eligible deposit is approved, you earn {formatMoney(data.settings.referralBonusCents)} from the prize pool.</p><button className="button button-light" onClick={() => data.user ? navigate("referrals") : openAuth()}>Get your referral code <ArrowRight size={17} /></button><div className="promo-people"><span>A</span><span>J</span><span>+</span></div></section>}
      <section className="mini-activity panel"><div className="panel-header"><div><p className="section-eyebrow">KEEPING YOU IN THE LOOP</p><h2>Recent activity</h2></div><button className="icon-link" onClick={() => navigate("activity")} aria-label="View all activity"><ArrowUpRight size={19} /></button></div>{data.transactions.length ? <TransactionList entries={data.transactions} limit={3} /> : <EmptyState icon={History} title="A fresh start" detail="Your plays, rewards, and wallet updates will show up here." />}</section>
    </div>
    <div className="trust-strip"><span><ShieldCheck size={16} /> Private by design</span><span><SlidersHorizontal size={16} /> Clear game odds</span><span><Clock3 size={16} /> Manual payment review</span><span className="trust-age">18+ · Play responsibly</span></div>
  </>;
}

function GamesPage({ data, search, setSearch, openGame, openSurvey }: { data: DashboardData; search: string; setSearch: (value: string) => void; openGame: (game: GameId) => void; openSurvey: () => void }) {
  const matchedGames = gameCards.filter((card) =>
    (card.id === "aviator" ? data.content.aviatorEnabled : data.content.towerEnabled) &&
    `${card.title} ${card.subtitle}`.toLowerCase().includes(search.toLowerCase()));
  const showSurvey = data.content.surveysEnabled && "quick questionnaires earn rewards survey".includes(search.toLowerCase());
  return <>
    <PageIntro eyebrow="THE GAME ROOM" title="Find your kind of fun." description="Two instant games, one simple rule: know the odds, choose your stake, and play at your own pace." aside={<span className="subtle-chip"><span className="live-dot" /> Games available to try</span>} />
    <div className="games-feature-banner"><div><span className="mini-kicker">INSTANT PLAY, YOUR WAY</span><h2>Ready when you are.</h2><p>Watch every second unfold. Try a free demo, then choose when to cash out of a live paid round before it crashes.</p></div><div className="games-banner-orb"><Gamepad2 size={48} /></div></div>
    <div className="content-toolbar"><div><h2>Explore activities</h2><p>Choose a game or take a little break to earn.</p></div><div className="toolbar-search"><Search size={17} /><input aria-label="Filter activities" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Find an activity..." /></div></div>
    <div className="feature-grid">{matchedGames.map((card) => <GameCard key={card.id} card={card} onOpen={() => openGame(card.id)} />)}{showSurvey && <SurveyFeatureCard onOpen={openSurvey} />}{!matchedGames.length && !showSurvey && <div className="no-results">No activities match “{search}”. Try another search.</div>}</div>
    <section className="how-grid"><div><span className="how-icon"><Target size={21} /></span><h3>Know before you play</h3><p>There is a {data.settings.winRate}% chance the round reaches 1.80×. Cash out earlier or later for different odds, up to 3.00×.</p></div><div><span className="how-icon"><Coins size={21} /></span><h3>Choose your stake</h3><p>Paid stakes are $1–$100. Demo rounds use no real balance and have no cash value.</p></div><div><span className="how-icon"><ShieldCheck size={21} /></span><h3>Stay in control</h3><p>Keep it fun, set your own limits, and take breaks whenever you need to. 18+ only.</p></div></section>
  </>;
}

function EarnPage({ data, openSurvey, openAuth }: { data: DashboardData; openSurvey: (id: string) => void; openAuth: () => void }) {
  if (!data.content.surveysEnabled) return <><PageIntro eyebrow="EARN REWARDS" title="A little pause." description="Questionnaires are not available right now." /><EmptyState icon={Gift} title="Back soon" detail="New rewards will appear here when the operator makes them available." /></>;
  return <>
    <PageIntro eyebrow="EARN REWARDS" title="Your thoughts have value." description="Answer a few fun questions about what you like. Complete each questionnaire once to earn a wallet reward." />
    <div className="earn-hero"><div><span className="mini-kicker">A LITTLE EXTRA, JUST FOR YOU</span><h2>Share your take.<br /><em>Get a little back.</em></h2><p>No sensitive questions. Just preferences and feedback that help make LumiPlay better.</p><span className="earn-progress">{data.completions.length} of {surveys.length} completed <span className="progress-track"><span style={{ width: `${data.completions.length / surveys.length * 100}%` }} /></span></span></div><div className="earn-hero-image" /></div>
    <SectionHeading eyebrow="AVAILABLE NOW" title="Quick questionnaires" />
    <div className="survey-list">{surveys.map((survey, index) => {
      const complete = data.completions.includes(survey.id);
      return <article className="survey-row" key={survey.id}><span className={`survey-number survey-number-${index}`}>{complete ? <Check size={22} /> : String(index + 1).padStart(2, "0")}</span><div className="survey-row-copy"><div><h3>{survey.title}</h3>{complete && <span className="completed-label"><CheckCircle2 size={14} /> Completed</span>}</div><p>{survey.description}</p><span><Clock3 size={14} /> About {survey.minutes} min <i /> {survey.questions.length} questions</span></div><strong>+{formatMoney(survey.rewardCents)}</strong><button className={`button ${complete ? "button-disabled" : "button-secondary"} button-small`} disabled={complete} onClick={() => data.user ? openSurvey(survey.id) : openAuth()}>{complete ? "Done" : "Start"}<ArrowRight size={15} /></button></article>;
    })}</div>
    <div className="info-note"><Info size={18} /><p>Rewards are funded by the operator prize pool and credited after completion, while funds are available. Each questionnaire can be completed once per account.</p></div>
  </>;
}

function WalletPage({ data, openWallet, openAuth }: { data: DashboardData; openWallet: (mode: "deposit" | "withdrawal") => void; openAuth: () => void }) {
  return <>
    <PageIntro eyebrow="MY WALLET" title="Your money, made clear." description="See what you have, what is pending, and every movement in one place." />
    {!data.user ? <GuestGate title="Your wallet starts here" detail="Create an account to request deposits, track your balance, and manage withdrawals." onJoin={openAuth} /> : <>
      <div className="wallet-top-grid"><div className="wallet-balance-card"><div className="wallet-balance-top"><span><Wallet size={18} /> AVAILABLE BALANCE</span><span className="wallet-card-spark">✳</span></div><strong>{formatMoney(data.user.balanceCents)}</strong><p>Ready for games or an eligible withdrawal.</p><div className="wallet-card-actions"><button className="button button-primary" onClick={() => openWallet("deposit")}><Plus size={18} /> Request deposit</button><button className="button button-outline-light" onClick={() => openWallet("withdrawal")}><ArrowUpRight size={17} /> Withdraw</button></div><div className="wallet-card-orbit" /></div><div className="wallet-guidance panel"><span className="guidance-icon"><ShieldCheck size={22} /></span><h3>Clear from start to finish.</h3><p>Deposits are credited only after an operator verifies the payment. Withdrawals reserve your funds while they are reviewed.</p><div><LockKeyhole size={15} /> Payout details are encrypted at rest</div><div><Clock3 size={15} /> Requests are reviewed manually</div></div></div>
      <div className="wallet-content-grid"><section className="panel list-panel"><div className="panel-header"><div><p className="section-eyebrow">WHAT&apos;S HAPPENING</p><h2>Requests</h2></div><span className="count-pill">{data.requests.length}</span></div>{data.requests.length ? <div className="request-list">{data.requests.map((item) => <div className="request-row" key={item.id}><span className={`transaction-icon ${item.kind === "deposit" ? "transaction-positive" : "transaction-negative"}`}>{item.kind === "deposit" ? <ArrowDownLeft size={18} /> : <ArrowUpRight size={18} />}</span><div><strong>{item.kind === "deposit" ? "Deposit request" : "Withdrawal request"}</strong><span>{formatDate(item.createdAt)} · {item.method.replaceAll("_", " ")}</span></div><strong>{formatMoney(item.amountCents)}</strong><StatusPill status={item.status} /></div>)}</div> : <EmptyState icon={Clock3} title="No requests yet" detail="Your deposit and withdrawal requests will be listed here." />}</section><section className="panel list-panel"><div className="panel-header"><div><p className="section-eyebrow">EVERY STEP, VISIBLE</p><h2>Wallet activity</h2></div><span className="count-pill">{data.transactions.length}</span></div><TransactionList entries={data.transactions} limit={8} /></section></div>
      <div className="info-note"><Info size={18} /><p>LumiPlay does not process payments online in this setup. Requests are manual records; an operator must verify deposits and separately make payouts. Never share a password or card number in a reference field.</p></div>
    </>}
  </>;
}

function ReferralsPage({ data, openAuth, onCopy, onRegenerate, busy }: { data: DashboardData; openAuth: () => void; onCopy: (text: string, label: string) => void; onRegenerate: () => void; busy: boolean }) {
  const origin = useSyncExternalStore(() => () => {}, () => window.location.origin, () => "");
  const link = data.user ? `${origin}/?ref=${data.user.referralCode}` : "";
  if (!data.content.referralsEnabled) return <><PageIntro eyebrow="REFERRALS" title="Sharing is on pause." description="New referrals are unavailable right now." /><EmptyState icon={UsersRound} title="Check back soon" detail="Your past rewards stay in your account activity. New invitations will return when enabled." /></>;
  return <>
    <PageIntro eyebrow="REFERRALS" title="Bring your people along." description="Good things are even better together. Share your link, and get rewarded when a friend qualifies." />
    {!data.user ? <GuestGate title="Your invite link is waiting" detail="Join LumiPlay to get a unique referral code you can share with friends." onJoin={openAuth} /> : <>
      <div className="referral-hero"><div className="referral-hero-copy"><span className="mini-kicker">SHARE THE GOOD STUFF</span><h2>Invite a friend.<br /><em>Earn {formatMoney(data.settings.referralBonusCents)}.</em></h2><p>When someone joins with your code and their first deposit of $10+ is approved, the reward comes to your wallet from the operator prize pool.</p></div><div className="referral-hero-art"><div className="referral-orbit orbit-one" /><div className="referral-orbit orbit-two" /><div className="referral-center"><UsersRound size={41} /></div><span className="referral-bubble bubble-one">✦</span><span className="referral-bubble bubble-two">+</span></div></div>
      <div className="referral-layout"><section className="panel referral-code-panel"><div className="panel-header"><div><p className="section-eyebrow">MADE JUST FOR YOU</p><h2>Your referral link</h2></div><span className="panel-header-icon"><Send size={18} /></span></div><p>Send this to a friend. Your code is added automatically when they sign up.</p><div className="copy-field"><span>{link}</span><button onClick={() => onCopy(link, "Link copied") } aria-label="Copy referral link"><Copy size={17} /></button></div><div className="code-actions"><div><span>Your code</span><strong>{data.user.referralCode}</strong></div><button className="button button-secondary button-small" onClick={() => onCopy(data.user!.referralCode, "Code copied")}><Copy size={15} /> Copy code</button></div><button className="regenerate-link" onClick={onRegenerate} disabled={busy}><RefreshCw size={14} /> Generate a new code</button><small>Generating a new code disables the old code for future signups. Existing referrals remain yours.</small></section><div className="referral-side"><div className="referral-metric panel"><span className="stat-icon stat-purple"><UsersRound size={20} /></span><div><small>Friends invited</small><strong>{data.referral.invited}</strong></div></div><div className="referral-metric panel"><span className="stat-icon stat-green"><Gift size={20} /></span><div><small>Rewards earned</small><strong>{formatMoney(data.referral.earnedCents)}</strong></div></div></div></div>
      <SectionHeading eyebrow="SIMPLE AS THAT" title="How it works" /><div className="steps-grid"><div><span>01</span><h3>Share your link</h3><p>Invite a friend who is at least 18 and new to LumiPlay.</p></div><div><span>02</span><h3>They join & deposit</h3><p>They use your code and have their first $10+ deposit approved by the operator.</p></div><div><span>03</span><h3>You get rewarded</h3><p>{formatMoney(data.settings.referralBonusCents)} is credited when prize-pool funds are available.</p></div></div>
    </>}
  </>;
}

function ActivityPage({ data, openAuth }: { data: DashboardData; openAuth: () => void }) {
  return <><PageIntro eyebrow="YOUR ACTIVITY" title="The whole picture." description="A simple, transparent record of your plays, rewards, and wallet movements." />{!data.user ? <GuestGate title="Your story starts with an account" detail="Once you join, every wallet update and paid game round will be easy to find here." onJoin={openAuth} /> : <div className="activity-grid"><section className="panel list-panel"><div className="panel-header"><div><p className="section-eyebrow">MONEY MOVEMENTS</p><h2>Transactions</h2></div><span className="count-pill">{data.transactions.length}</span></div><TransactionList entries={data.transactions} limit={30} /></section><section className="panel list-panel"><div className="panel-header"><div><p className="section-eyebrow">YOUR ROUNDS</p><h2>Game history</h2></div><span className="count-pill">{data.plays.length}</span></div>{data.plays.length ? <div className="transaction-list">{data.plays.map((play) => <div className="transaction-row" key={play.id}><span className={`transaction-icon ${play.won ? "transaction-positive" : "transaction-negative"}`}>{play.game === "aviator" ? <Plane size={18} /> : <Layers3 size={18} />}</span><div className="transaction-description"><strong>{play.game === "aviator" ? "Aviator" : "Tower Rush"} · {play.status === "active" ? "Live now" : play.status === "cashed_out" ? `Cashed out ${formatMultiplier(play.cashoutMultiplierBps ?? 10_000)}` : play.status === "crashed" ? "Crashed" : play.won ? "Win" : "No win"}</strong><span>{formatDate(play.createdAt)} · {formatMoney(play.betCents)} stake</span></div><strong className={play.payoutCents > 0 ? "money-positive" : "money-negative"}>{play.status === "active" ? "LIVE" : play.payoutCents > 0 ? `+${formatMoney(play.payoutCents)}` : "—"}</strong></div>)}</div> : <EmptyState icon={Gamepad2} title="No paid rounds yet" detail="Free demo rounds don't use money and aren't saved to your activity." />}</section></div>}</>;
}

function AdminRequest({ item, review, busy }: { item: AdminRequestView; review: (id: string, decision: "approve" | "reject") => void; busy: boolean }) {
  return <div className="admin-request"><div className="admin-request-top"><span className={`transaction-icon ${item.kind === "deposit" ? "transaction-positive" : "transaction-negative"}`}>{item.kind === "deposit" ? <ArrowDownLeft size={18} /> : <ArrowUpRight size={18} />}</span><div className="admin-request-person"><strong>{item.userName}</strong><span>{item.userEmail} · {formatDate(item.createdAt)}</span></div><strong className="admin-request-amount">{formatMoney(item.amountCents)}</strong><span className={`request-type ${item.kind}`}>{item.kind}</span></div><div className="admin-request-detail"><span>Method: <strong>{item.method.replaceAll("_", " ")}</strong></span>{item.reference && <span>Reference: <strong>{item.reference}</strong></span>}{item.payoutDetails && <span>Payout destination: <strong>{item.payoutDetails}</strong></span>}</div><div className="admin-request-actions"><button className="button button-secondary button-small" onClick={() => review(item.id, "reject")} disabled={busy}><X size={15} /> Decline</button><button className="button button-primary button-small" onClick={() => review(item.id, "approve")} disabled={busy}><Check size={15} /> {item.kind === "deposit" ? "Verify & credit" : "Mark paid"}</button></div></div>;
}

function AdminPage({ data, onAction, busy }: { data: DashboardData; onAction: (body: Record<string, unknown>) => Promise<boolean>; busy: boolean }) {
  const [rate, setRate] = useState(String(data.settings.winRate));
  const [fundAmount, setFundAmount] = useState("");
  if (!data.admin) return null;
  return <>
    <PageIntro eyebrow="OPERATOR WORKSPACE" title="Behind the good stuff." description="Manage prize-pool funding, transparent game odds, and manual payment requests." aside={<span className="admin-badge"><BadgeCheck size={16} /> Operator access</span>} />
    <div className="admin-stats"><div className="admin-stat panel"><span className="stat-icon stat-green"><Coins size={21} /></span><small>Prize pool available</small><strong>{formatMoney(data.settings.bankrollCents)}</strong><p>Available after reserves for active game rounds</p></div><div className="admin-stat panel"><span className="stat-icon stat-purple"><UsersRound size={21} /></span><small>Total accounts</small><strong>{data.admin.totalPlayers}</strong><p>Including your operator account</p></div><div className="admin-stat panel"><span className="stat-icon stat-orange"><Clock3 size={21} /></span><small>Requests to review</small><strong>{data.admin.pending.length}</strong><p>Deposits and withdrawals awaiting action</p></div></div>
    <div className="admin-controls"><section className="panel control-panel"><div className="panel-header"><div><p className="section-eyebrow">GAME SETTINGS</p><h2>Win chance</h2></div><span className="panel-header-icon"><SlidersHorizontal size={19} /></span></div><p>Set the chance that a round survives to 1.80×. Players choose when to cash out; earlier and later cash-outs have different odds. Changes affect new rounds only.</p><div className="rate-display"><strong>{rate}<span>%</span></strong><span>chance to reach 1.80×</span></div><input className="rate-slider" type="range" min="1" max="75" step="1" value={rate} onChange={(e) => setRate(e.target.value)} aria-label="Win chance percentage" style={{ background: `linear-gradient(90deg, #c7f278 ${Number(rate) / 75 * 100}%, #2d3944 ${Number(rate) / 75 * 100}%)` }} /><div className="slider-labels"><span>1% less frequent</span><span>75% more frequent</span></div><button className="button button-primary button-small control-save" disabled={busy || Number(rate) === data.settings.winRate} onClick={() => void onAction({ action: "rate", rate: Number(rate) })}>Save win chance <ArrowRight size={16} /></button></section><section className="panel control-panel"><div className="panel-header"><div><p className="section-eyebrow">PRIZE POOL</p><h2>Record funding</h2></div><span className="panel-header-icon"><Wallet size={19} /></span></div><p>Record funds you have actually set aside outside this platform. This is an accounting action, not a charge or bank transfer.</p><form onSubmit={async (e) => { e.preventDefault(); if (await onAction({ action: "fund", amount: fundAmount })) setFundAmount(""); }}><label className="form-label" htmlFor="fund-amount">Amount in USD</label><div className="input-with-prefix"><span>$</span><input id="fund-amount" type="number" min="1" max="1000000" step="0.01" placeholder="0.00" value={fundAmount} onChange={(e) => setFundAmount(e.target.value)} required /></div><button className="button button-primary button-small control-save" disabled={busy}>Record verified funding <Plus size={16} /></button></form><div className="control-footnote"><Info size={15} /> Total recorded funding: {formatMoney(data.admin.fundingTotalCents)}</div></section></div>
    <div className="admin-section-heading"><SectionHeading eyebrow="MANUAL REVIEW" title="Pending requests" /><span className="count-pill">{data.admin.pending.length} waiting</span></div>
    <div className="admin-queue">{data.admin.pending.length ? data.admin.pending.map((item) => <AdminRequest key={item.id} item={item} busy={busy} review={(id, decision) => void onAction({ action: "review", id, decision })} />) : <EmptyState icon={CheckCircle2} title="All caught up" detail="New deposit and withdrawal requests will show up here for review." />}</div>
    {data.admin.recent.length > 0 && <section className="panel admin-recent"><div className="panel-header"><div><p className="section-eyebrow">AUDIT TRAIL</p><h2>Recently reviewed</h2></div></div>{data.admin.recent.map((item) => <div className="recent-row" key={item.id}><div><strong>{item.userName} · {item.kind}</strong><span>{formatDate(item.createdAt)}</span></div><strong>{formatMoney(item.amountCents)}</strong><StatusPill status={item.status} /></div>)}</section>}
    <div className="info-note"><Info size={18} /><p>No payment processor is connected. Only approve a deposit after independently verifying funds, and mark a withdrawal paid only after making the external payout. For a live-money launch, obtain applicable legal, licensing, identity, and payment compliance review.</p></div>
  </>;
}

function HelpPage({ winRate }: { winRate: number }) {
  const faqs = [
    { q: "How do the games work?", a: `Both games run live as the multiplier rises. You may request a cash out before the preselected crash point; if the round crashes first, the stake is lost. The operator setting gives a ${winRate}% chance to reach 1.80×; cashing out at other multipliers has different odds. Paid crash points and cash-outs are decided on the server using cryptographic randomness and server time. Surviving rounds cash out automatically at 3.00×. Demo rounds use no real money and cannot be withdrawn.` },
    { q: "How do deposits and withdrawals work?", a: "This setup uses manual requests; it does not charge you or send money online. An operator independently verifies a deposit before crediting your wallet. A withdrawal reserves your balance until an operator makes the payout externally or returns the funds if declined." },
    { q: "When do referral rewards arrive?", a: "A referral reward is earned after a new friend joins with your code and their first deposit of at least $10 is approved. Rewards are paid from the operator-funded prize pool when sufficient funds are available." },
    { q: "What information is kept private?", a: "Passwords are salted and hashed, sessions use HttpOnly cookies, and payout destinations are encrypted at rest. Your personal wallet activity is visible only to you; payout details are available only to an operator for manual review. No system can promise absolute security." },
  ];
  return <><PageIntro eyebrow="GOOD TO KNOW" title="Everything, out in the open." description="Clear answers, transparent rules, and a reminder that you are always in control." /><div className="help-hero"><span className="help-hero-icon"><ShieldCheck size={31} /></span><div><span className="mini-kicker">YOUR WELLBEING COMES FIRST</span><h2>Keep play fun, not a plan to earn.</h2><p>Games involve chance and can result in a loss. Never play with money you need, set your own limits, and take a break when it stops feeling fun. LumiPlay is for adults 18+ only.</p></div></div><div className="help-layout"><section className="panel faq-panel"><SectionHeading eyebrow="ANSWERS AT A GLANCE" title="Frequently asked questions" />{faqs.map((faq) => <details className="faq-item" key={faq.q}><summary>{faq.q}<Plus size={18} /></summary><p>{faq.a}</p></details>)}</section><aside className="help-side"><div className="panel help-side-card"><span className="stat-icon stat-green"><Target size={20} /></span><h3>Know your odds</h3><p>Chance to reach 1.80×</p><strong>{winRate}%</strong><span>Cash out any time before a crash · max 3.00×</span></div><div className="panel help-side-card"><span className="stat-icon stat-purple"><LockKeyhole size={20} /></span><h3>Privacy matters</h3><p>Only the information needed for your account and requests is collected. Never put passwords or card numbers in a payment note.</p></div></aside></div></>;
}

function AuthModal({ mode: initialMode, referral, onClose, onSuccess, busy }: { mode: "login" | "register"; referral: string; onClose: () => void; onSuccess: (body: Record<string, unknown>) => Promise<boolean>; busy: boolean }) {
  const [mode, setMode] = useState(initialMode);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState(referral);
  const [age, setAge] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const ok = await onSuccess({ action: mode, name, email, password, referral: code, ageConfirmed: age });
    if (ok) onClose();
  }
  return <div className="modal-backdrop" onMouseDown={onClose}><div className="dialog auth-dialog" role="dialog" aria-modal="true" aria-label={mode === "register" ? "Create an account" : "Sign in"} onMouseDown={(e) => e.stopPropagation()}><button className="dialog-close" onClick={onClose} aria-label="Close"><X size={19} /></button><div className="auth-art"><Logo /><div className="auth-art-center"><span className="auth-spark">✳</span><h2>Good things<br />start here.</h2><p>A little more fun, a little more you.</p></div><div className="auth-art-foot"><ShieldCheck size={17} /> Private by design · 18+ only</div></div><div className="auth-form-side"><span className="section-eyebrow">WELCOME TO LUMIPLAY</span><h2>{mode === "register" ? "Let’s make it yours." : "Welcome back."}</h2><p>{mode === "register" ? "Create your account to play, earn, and keep everything in one place." : "Pick up right where you left off."}</p><div className="auth-switch"><button className={mode === "register" ? "active" : ""} onClick={() => setMode("register")}>Sign up</button><button className={mode === "login" ? "active" : ""} onClick={() => setMode("login")}>Log in</button></div><form onSubmit={(e) => void submit(e)}>{mode === "register" && <label className="form-label">Your name<input type="text" autoComplete="name" placeholder="What should we call you?" value={name} onChange={(e) => setName(e.target.value)} required minLength={2} maxLength={60} /></label>}<label className="form-label">Email address<input type="email" autoComplete="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} required /></label><label className="form-label">Password<div className="password-field"><input type={showPassword ? "text" : "password"} autoComplete={mode === "register" ? "new-password" : "current-password"} placeholder={mode === "register" ? "At least 8 characters" : "Your password"} value={password} onChange={(e) => setPassword(e.target.value)} minLength={mode === "register" ? 8 : 1} required /><button type="button" onClick={() => setShowPassword(!showPassword)} aria-label={showPassword ? "Hide password" : "Show password"}>{showPassword ? "Hide" : "Show"}</button></div></label>{mode === "register" && <><label className="form-label">Referral code <span className="optional">optional</span><input type="text" placeholder="Have a code? Add it here" value={code} onChange={(e) => setCode(e.target.value)} maxLength={24} /></label><label className="check-label"><input type="checkbox" checked={age} onChange={(e) => setAge(e.target.checked)} required /><span>I confirm I am at least 18 years old and understand games involve financial risk.</span></label></>}<button className="button button-primary auth-submit" disabled={busy}>{busy ? "Just a moment..." : mode === "register" ? "Create account" : "Log in"}<ArrowRight size={17} /></button></form><div className="auth-bottom">{mode === "register" ? "Already part of the fun?" : "New around here?"} <button onClick={() => setMode(mode === "register" ? "login" : "register")}>{mode === "register" ? "Log in" : "Create an account"}</button></div><small className="auth-disclaimer">Operator? Use the separate <a href="/studio">Lumi Studio</a> sign-in. Never share your password.</small></div></div></div>;
}

function WalletModal({ initialMode, balanceCents, onClose, onSubmit, busy }: { initialMode: "deposit" | "withdrawal"; balanceCents: number; onClose: () => void; onSubmit: (body: Record<string, unknown>) => Promise<boolean>; busy: boolean }) {
  const [mode, setMode] = useState(initialMode);
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("bank_transfer");
  const [reference, setReference] = useState("");
  const [details, setDetails] = useState("");
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const ok = await onSubmit({ action: mode, amount, method, reference, details });
    if (ok) onClose();
  }
  return <div className="modal-backdrop" onMouseDown={onClose}><div className="dialog compact-dialog" role="dialog" aria-modal="true" aria-label="Manage wallet" onMouseDown={(e) => e.stopPropagation()}><button className="dialog-close" onClick={onClose} aria-label="Close"><X size={19} /></button><span className="dialog-icon"><Wallet size={23} /></span><span className="section-eyebrow">YOUR WALLET</span><h2>{mode === "deposit" ? "Request a deposit" : "Request a withdrawal"}</h2><p className="dialog-subtitle">{mode === "deposit" ? "Submit the details of a payment for an operator to verify." : `Available balance: ${formatMoney(balanceCents)}. Funds are reserved while your request is reviewed.`}</p><div className="mode-switch"><button className={mode === "deposit" ? "active" : ""} onClick={() => setMode("deposit")}><ArrowDownLeft size={16} /> Deposit</button><button className={mode === "withdrawal" ? "active" : ""} onClick={() => setMode("withdrawal")}><ArrowUpRight size={16} /> Withdraw</button></div><form onSubmit={(e) => void submit(e)}><label className="form-label">Amount (USD)<div className="input-with-prefix"><span>$</span><input type="number" min="10" max="10000" step="0.01" placeholder="10.00" value={amount} onChange={(e) => setAmount(e.target.value)} required /></div></label><label className="form-label">Method<select value={method} onChange={(e) => setMethod(e.target.value)}><option value="bank_transfer">Bank transfer</option><option value="mobile_money">Mobile money</option><option value="other">Other agreed method</option></select></label>{mode === "deposit" ? <label className="form-label">Transfer reference or note<input type="text" placeholder="Reference provided by your operator" value={reference} onChange={(e) => setReference(e.target.value)} minLength={3} maxLength={120} required /></label> : <label className="form-label">Payout destination<input type="text" placeholder="Account or payment handle" value={details} onChange={(e) => setDetails(e.target.value)} minLength={3} maxLength={120} required /></label>}<div className="modal-note"><Info size={17} /><span>{mode === "deposit" ? "This request does not send money. Your balance is credited only after an operator independently verifies an external payment." : "Your payout destination is encrypted at rest. An operator must separately send the payout before marking it paid."}</span></div><button className="button button-primary full-width" disabled={busy}>{busy ? "Submitting..." : mode === "deposit" ? "Submit deposit request" : "Request withdrawal"}<ArrowRight size={17} /></button></form></div></div>;
}

function SurveyModal({ surveyId, onClose, onSubmit, busy }: { surveyId: string; onClose: () => void; onSubmit: (body: Record<string, unknown>) => Promise<boolean>; busy: boolean }) {
  const survey = surveys.find((item) => item.id === surveyId);
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  if (!survey) return null;
  const question = survey.questions[step];
  const selected = answers[step];
  async function next() {
    if (selected === undefined) return;
    if (step < survey!.questions.length - 1) { setStep(step + 1); return; }
    const ok = await onSubmit({ surveyId: survey!.id, answers });
    if (ok) onClose();
  }
  return <div className="modal-backdrop" onMouseDown={onClose}><div className="dialog compact-dialog survey-dialog" role="dialog" aria-modal="true" aria-label={survey.title} onMouseDown={(e) => e.stopPropagation()}><button className="dialog-close" onClick={onClose} aria-label="Close"><X size={19} /></button><span className="dialog-icon dialog-icon-purple"><Gift size={23} /></span><span className="section-eyebrow">QUICK QUESTIONNAIRE · +{formatMoney(survey.rewardCents)}</span><h2>{survey.title}</h2><p className="dialog-subtitle">Just your preferences — no sensitive questions.</p><div className="survey-progress"><span>Question {step + 1} of {survey.questions.length}</span><span>{Math.round((step + 1) / survey.questions.length * 100)}%</span><div className="progress-track"><span style={{ width: `${(step + 1) / survey.questions.length * 100}%` }} /></div></div><h3 className="question-title">{question.prompt}</h3><div className="answer-options">{question.options.map((option, index) => <button className={selected === index ? "selected" : ""} key={option} onClick={() => setAnswers((current) => { const next = [...current]; next[step] = index; return next; })}><span>{selected === index ? <Check size={15} /> : ""}</span>{option}</button>)}</div><div className="survey-actions">{step > 0 && <button className="button button-secondary" onClick={() => setStep(step - 1)}>Back</button>}<button className="button button-primary" onClick={() => void next()} disabled={selected === undefined || busy}>{busy ? "Saving..." : step === survey.questions.length - 1 ? `Finish & earn ${formatMoney(survey.rewardCents)}` : "Next question"}<ArrowRight size={17} /></button></div></div></div>;
}

export function Dashboard({ initialData }: { initialData: DashboardData }) {
  const [data, setData] = useState(initialData);
  const [page, setPage] = useState<PageId>("overview");
  const [modal, setModal] = useState<ModalState>(null);
  const [toast, setToast] = useState<Toast>(null);
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");
  const [mobileNav, setMobileNav] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [referralFromLink, setReferralFromLink] = useState("");
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const ref = new URLSearchParams(window.location.search).get("ref");
    if (ref && !initialData.user) { setReferralFromLink(ref.toUpperCase()); setModal({ type: "auth", mode: "register" }); }
  }, [initialData.user]);
  useEffect(() => {
    if (!modal) return;
    const onKeyDown = (event: KeyboardEvent) => { if (event.key === "Escape") setModal(null); };
    document.addEventListener("keydown", onKeyDown);
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKeyDown); document.body.style.overflow = oldOverflow; };
  }, [modal]);
  function notify(message: string, error = false) {
    setToast({ message, error });
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 4400);
  }
  async function refresh() {
    const response = await fetch("/api/dashboard", { cache: "no-store", credentials: "same-origin" });
    if (!response.ok) throw new Error("Couldn't refresh your dashboard.");
    setData(await response.json() as DashboardData);
  }
  async function run(path: string, body: Record<string, unknown>, fallback = "All set!") {
    setBusy(true);
    try {
      const result = await postJson<{ message?: string }>(path, body);
      await refresh();
      notify(result.message || fallback);
      return true;
    } catch (error) {
      notify(error instanceof Error ? error.message : "Please try again.", true);
      return false;
    } finally { setBusy(false); }
  }
  function navigate(next: PageId) {
    setPage(next); setMobileNav(false); setProfileOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  function openAuth(mode: "login" | "register" = "register") { setModal({ type: "auth", mode }); setProfileOpen(false); }
  function openWallet(mode: "deposit" | "withdrawal") { if (!data.user) openAuth(); else setModal({ type: "wallet", mode }); }
  function openSurvey(id?: string) { if (!data.user) openAuth(); else if (id) setModal({ type: "survey", surveyId: id }); else navigate("earn"); }
  async function copyText(text: string, message: string) {
    try { await navigator.clipboard.writeText(text); notify(message); }
    catch { notify("Copy isn't available here. Select the text to copy it.", true); }
  }
  async function logOut() { if (await run("/api/auth", { action: "logout" }, "You've been signed out.")) navigate("overview"); }

  let content: ReactNode;
  switch (page) {
    case "games": content = <GamesPage data={data} search={search} setSearch={setSearch} openGame={(game) => setModal({ type: "game", game })} openSurvey={() => openSurvey()} />; break;
    case "earn": content = <EarnPage data={data} openSurvey={(id) => openSurvey(id)} openAuth={() => openAuth()} />; break;
    case "wallet": content = <WalletPage data={data} openWallet={openWallet} openAuth={() => openAuth()} />; break;
    case "referrals": content = <ReferralsPage data={data} openAuth={() => openAuth()} onCopy={(text, label) => void copyText(text, label)} onRegenerate={() => void run("/api/referrals", {}, "New referral code ready.")} busy={busy} />; break;
    case "activity": content = <ActivityPage data={data} openAuth={() => openAuth()} />; break;
    case "admin": content = data.user?.role === "admin" ? <AdminPage data={data} onAction={(body) => run("/api/admin", body)} busy={busy} /> : <Overview data={data} navigate={navigate} openGame={(game) => setModal({ type: "game", game })} openSurvey={() => openSurvey()} openWallet={openWallet} openAuth={() => openAuth()} />; break;
    case "help": content = <HelpPage winRate={data.settings.winRate} />; break;
    default: content = <Overview data={data} navigate={navigate} openGame={(game) => setModal({ type: "game", game })} openSurvey={() => openSurvey()} openWallet={openWallet} openAuth={() => openAuth()} />;
  }

  return <div className="app-shell"><aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}><div className="sidebar-top"><Logo /><button className="mobile-sidebar-close" onClick={() => setMobileNav(false)} aria-label="Close menu"><X size={20} /></button></div><div className="sidebar-content">{navGroups.map((group) => <div className="nav-group" key={group.label}><span className="nav-group-label">{group.label}</span>{group.items.filter((item) => item.id !== "earn" || data.content.surveysEnabled).filter((item) => item.id !== "referrals" || data.content.referralsEnabled).map((item) => { const Icon = item.icon; return <button key={item.id} className={`nav-item ${page === item.id ? "nav-active" : ""}`} onClick={() => navigate(item.id)}><Icon size={19} strokeWidth={page === item.id ? 2.25 : 1.8} /><span>{item.label}</span>{item.id === "earn" && <span className="nav-new">NEW</span>}</button>; })}</div>)}{data.user?.role === "admin" && <div className="nav-group admin-nav-group"><span className="nav-group-label">MANAGE</span><button className={`nav-item ${page === "admin" ? "nav-active" : ""}`} onClick={() => navigate("admin")}><Settings2 size={19} /><span>Quick controls</span><span className="admin-nav-dot" /></button><a className="nav-item" href="/studio"><ExternalLink size={19} /><span>Open Lumi Studio</span></a></div>}<div className="sidebar-spacer" /><div className="sidebar-help-card"><div className="sidebar-help-icon"><ShieldCheck size={20} /></div><strong>Play happy. Play smart.</strong><p>The best kind of play is the kind you control.</p><button onClick={() => navigate("help")}>Learn more <ArrowRight size={14} /></button></div><button className={`sidebar-help-link ${page === "help" ? "active" : ""}`} onClick={() => navigate("help")}><CircleHelp size={18} /> Help & safety <ChevronRight size={16} /></button></div><div className="sidebar-bottom">{data.user ? <><div className="user-avatar">{data.user.name.charAt(0).toUpperCase()}</div><div className="sidebar-user-text"><strong>{data.user.name}</strong><span>{data.user.role === "admin" ? "Operator account" : "Player account"}</span></div><button className="sidebar-logout" onClick={() => void logOut()} aria-label="Sign out"><LogOut size={17} /></button></> : <><div className="user-avatar guest-avatar"><Sparkles size={18} /></div><div className="sidebar-user-text"><strong>Just exploring?</strong><span>Join the good stuff</span></div><button className="sidebar-join" onClick={() => openAuth()} aria-label="Create account"><ArrowRight size={18} /></button></>}</div></aside>{mobileNav && <button className="mobile-scrim" aria-label="Close menu" onClick={() => setMobileNav(false)} />}
    <div className="main-area"><header className="topbar"><div className="topbar-left"><button className="mobile-menu-button" onClick={() => setMobileNav(true)} aria-label="Open menu"><Menu size={22} /></button><div className="mobile-brand"><Logo compact /></div><div className="breadcrumb"><span>Discover</span><ChevronRight size={15} /><strong>{page === "overview" ? "Overview" : page === "earn" ? "Earn rewards" : page === "admin" ? "Admin studio" : page === "help" ? "Help & safety" : page.charAt(0).toUpperCase() + page.slice(1)}</strong></div></div><div className="topbar-right"><label className="header-search"><Search size={18} /><input value={search} onChange={(e) => { setSearch(e.target.value); if (e.target.value) setPage("games"); }} placeholder="Search activities..." aria-label="Search activities" /><span>⌘ K</span></label><button className="header-icon-button" onClick={() => notify("You're all caught up!")} aria-label="Notifications"><Bell size={19} /><i /></button>{data.activeRound && <button className="header-live-round" onClick={() => setModal({ type: "game", game: data.activeRound!.game })}><span className="live-dot" /> Live round <ArrowRight size={14} /></button>}<span className="header-divider" />{data.user ? <><button className="header-balance" onClick={() => navigate("wallet")}><Wallet size={17} />{formatMoney(data.user.balanceCents)}</button><div className="profile-wrap"><button className="header-profile" onClick={() => setProfileOpen(!profileOpen)} aria-label="Account menu"><span className="header-avatar">{data.user.name.charAt(0).toUpperCase()}</span><ChevronDown size={16} /></button>{profileOpen && <div className="profile-menu"><div><strong>{data.user.name}</strong><span>{data.user.email}</span></div><button onClick={() => navigate("wallet")}><Wallet size={16} /> My wallet</button>{data.user.role === "admin" && <button onClick={() => navigate("admin")}><Settings2 size={16} /> Admin studio</button>}<button onClick={() => void logOut()}><LogOut size={16} /> Sign out</button></div>}</div></> : <><button className="header-login" onClick={() => openAuth("login")}>Log in</button><button className="button button-primary header-join" onClick={() => openAuth("register")}>Join now <ArrowRight size={16} /></button></>}</div></header><main className="content-container">{content}<footer className="site-footer"><div><Logo compact /><span>Good play starts with clear choices.</span></div><div><button onClick={() => navigate("help")}>How it works</button><button onClick={() => navigate("help")}>Privacy & safety</button><span>18+ only · Play responsibly</span></div></footer></main></div>
    {modal?.type === "auth" && <AuthModal key={`auth-${modal.mode}`} mode={modal.mode} referral={referralFromLink} onClose={() => setModal(null)} onSuccess={(body) => run("/api/auth", body, body.action === "register" ? "Welcome to LumiPlay!" : "Welcome back!")} busy={busy} />}
    {modal?.type === "wallet" && <WalletModal key={`wallet-${modal.mode}`} initialMode={modal.mode} balanceCents={data.user?.balanceCents ?? 0} onClose={() => setModal(null)} onSubmit={(body) => run("/api/wallet", body)} busy={busy} />}
    {modal?.type === "game" && <LiveGameModal key={`game-${modal.game}`} game={modal.game} user={data.user} activeRound={data.activeRound} winRate={data.settings.winRate} bankrollCents={data.settings.bankrollCents} onClose={() => setModal(null)} onAuth={() => openAuth()} onResume={(game) => setModal({ type: "game", game })} onRefresh={refresh} notify={notify} />}
    {modal?.type === "survey" && <SurveyModal key={`survey-${modal.surveyId}`} surveyId={modal.surveyId} onClose={() => setModal(null)} onSubmit={(body) => run("/api/surveys", body, "Questionnaire complete! Reward added to your wallet.")} busy={busy} />}
    {toast && <div className={`toast ${toast.error ? "toast-error" : ""}`} role="status"><span>{toast.error ? <Info size={18} /> : <CheckCircle2 size={18} />}</span>{toast.message}<button onClick={() => setToast(null)} aria-label="Dismiss message"><X size={15} /></button></div>}
  </div>;
}
