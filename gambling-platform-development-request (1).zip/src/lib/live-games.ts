import "server-only";
import { randomInt } from "node:crypto";
import { and, asc, eq, lte, sql } from "drizzle-orm";
import { db } from "@/db";
import { gamePlays, ledgerEntries, platformSettings, users } from "@/db/schema";
import { fail } from "@/lib/security";
import {
  MAX_CASHOUT_BPS, ROUND_DURATION_MS, formatMultiplier, multiplierAt,
  type GameId, type LiveRound,
} from "@/lib/shared";

type StoredRound = typeof gamePlays.$inferSelect;

// Exactly winRate% of preselected crash points survive to 1.80×.
// Other cash-out points have different odds; no outcome is guaranteed.
export function chooseCrashMultiplierBps(winRate: number) {
  const reachesReference = randomInt(10_000) < winRate * 100;
  return reachesReference ? randomInt(18_001, 34_001) : randomInt(10_000, 18_000);
}

export function crashTimeMs(startedAtMs: number, crashMultiplierBps: number) {
  return startedAtMs + Math.ceil((crashMultiplierBps - 10_000) * 2 / 5);
}

export function publicRound(round: StoredRound, nowMs = Date.now()): LiveRound {
  return {
    id: round.id,
    game: round.game as GameId,
    status: round.status as LiveRound["status"],
    betCents: round.betCents,
    payoutCents: round.payoutCents,
    winRate: round.winRate,
    startedAt: round.startedAt.toISOString(),
    serverTime: new Date(nowMs).toISOString(),
    multiplierBps: round.status === "cashed_out"
      ? round.cashoutMultiplierBps ?? 10_000
      : round.status === "crashed"
        ? round.crashMultiplierBps
        : multiplierAt(round.startedAt.getTime(), nowMs),
    crashMultiplierBps: round.status === "crashed" ? round.crashMultiplierBps : null,
  };
}

/** The settings row is always locked before the round row in all game transactions. */
export async function settleRound(id: string, ownerId: string | null, requestCashout = false): Promise<LiveRound | null> {
  return db.transaction(async (tx) => {
    await tx.execute(sql`select id from platform_settings where id = 1 for update`);
    await tx.execute(sql`select id from game_plays where id = ${id}::uuid for update`);
    const [round] = await tx.select().from(gamePlays).where(eq(gamePlays.id, id)).limit(1);
    if (!round) {
      if (ownerId) fail("Round not found.", 404);
      return null;
    }
    if (ownerId && round.userId !== ownerId) fail("Round not found.", 404);
    if (round.status !== "active") return publicRound(round);

    const nowMs = Date.now();
    const endMs = round.endsAt.getTime();
    if (!requestCashout && nowMs < endMs) return publicRound(round, nowMs);

    const maxTimeMs = round.startedAt.getTime() + ROUND_DURATION_MS;
    const crashed = nowMs >= endMs && crashTimeMs(round.startedAt.getTime(), round.crashMultiplierBps) <= maxTimeMs;
    const cashoutBps = crashed ? null : nowMs >= maxTimeMs ? MAX_CASHOUT_BPS : multiplierAt(round.startedAt.getTime(), nowMs);
    const payoutCents = cashoutBps === null ? 0 : Math.floor(round.betCents * cashoutBps / 10_000);
    const status = crashed ? "crashed" : "cashed_out";
    const [updated] = await tx.update(gamePlays).set({
      status,
      won: payoutCents > round.betCents,
      payoutCents,
      cashoutMultiplierBps: cashoutBps,
      settledAt: new Date(nowMs),
    }).where(eq(gamePlays.id, round.id)).returning();

    // At start, the stake entered the pool and the full 3× liability was reserved.
    // Return the unused reserve now; credit the actual payout exactly once.
    await tx.update(platformSettings).set({
      bankrollCents: sql`${platformSettings.bankrollCents} + ${round.reservedPayoutCents} - ${payoutCents}`,
      updatedAt: new Date(nowMs),
    }).where(eq(platformSettings.id, 1));
    if (payoutCents > 0) {
      await tx.update(users).set({ balanceCents: sql`${users.balanceCents} + ${payoutCents}` })
        .where(eq(users.id, round.userId));
      await tx.insert(ledgerEntries).values({
        userId: round.userId,
        kind: "cashout",
        amountCents: payoutCents,
        description: `${round.game === "aviator" ? "Aviator" : "Tower Rush"} · cash out ${formatMultiplier(cashoutBps!)}`,
        relatedId: round.id,
      });
    }
    return publicRound(updated, nowMs);
  });
}

/** Lazily clear expired rounds, including when a player closed the browser. */
export async function reconcileExpiredRounds(ownerId?: string) {
  const condition = ownerId
    ? and(eq(gamePlays.status, "active"), eq(gamePlays.userId, ownerId), lte(gamePlays.endsAt, new Date()))
    : and(eq(gamePlays.status, "active"), lte(gamePlays.endsAt, new Date()));
  const expired = await db.select({ id: gamePlays.id }).from(gamePlays)
    .where(condition).orderBy(asc(gamePlays.endsAt)).limit(100);
  for (const round of expired) await settleRound(round.id, null);
}
