import type { SiteContent } from "@/lib/studio-types";

export const REFERENCE_MULTIPLIER_BPS = 18_000; // 1.80×: the operator's configured survival chance applies here.
export const MAX_CASHOUT_BPS = 30_000; // 3.00×: surviving rounds cash out automatically at this point.
export const ROUND_DURATION_MS = 8_000;
export const MIN_BET_CENTS = 100;
export const MAX_BET_CENTS = 10_000;
export const REFERRAL_QUALIFYING_DEPOSIT_CENTS = 1_000;

export function multiplierAt(startedAtMs: number, nowMs: number) {
  return Math.min(MAX_CASHOUT_BPS, 10_000 + Math.floor(Math.max(0, nowMs - startedAtMs) * 2.5));
}

export function formatMultiplier(bps: number) {
  return `${(bps / 10_000).toFixed(2)}×`;
}

export const surveys = [
  {
    id: "play-style",
    title: "Your play style",
    description: "Tell us what makes a great game session for you.",
    rewardCents: 75,
    minutes: 2,
    questions: [
      { prompt: "What do you enjoy most about a game?", options: ["Quick rounds", "A clever challenge", "Seeing progress", "Playing with friends"] },
      { prompt: "When do you usually like to play?", options: ["On a short break", "In the evening", "On weekends", "Whenever I have time"] },
      { prompt: "What should we add more of?", options: ["Simple games", "Strategy games", "Free challenges", "Helpful guides"] },
    ],
  },
  {
    id: "game-night",
    title: "The perfect game night",
    description: "Help shape the next things we build.",
    rewardCents: 100,
    minutes: 3,
    questions: [
      { prompt: "Which kind of game feels most exciting?", options: ["Fast-paced", "Skill-based", "Relaxed", "A mix of everything"] },
      { prompt: "What matters most in a game lobby?", options: ["Clear rules", "Easy navigation", "Fresh choices", "Fast loading"] },
      { prompt: "How do you hear about new games?", options: ["Friends", "Social media", "In-app discovery", "I like to explore"] },
    ],
  },
  {
    id: "better-together",
    title: "Better together",
    description: "Share feedback on rewards and community.",
    rewardCents: 125,
    minutes: 3,
    questions: [
      { prompt: "Which reward sounds most useful?", options: ["Questionnaire rewards", "Referral rewards", "New game previews", "Loyalty perks"] },
      { prompt: "How often would you like new activities?", options: ["Every week", "A few times a month", "Once a month", "Only occasionally"] },
      { prompt: "What should we improve first?", options: ["Game variety", "Wallet clarity", "More ways to earn", "Support resources"] },
    ],
  },
] as const;

export type GameId = "aviator" | "tower";
export type PageId = "overview" | "games" | "earn" | "wallet" | "referrals" | "activity" | "admin" | "help";

export type PublicUser = {
  id: string;
  name: string;
  email: string;
  role: string;
  balanceCents: number;
  referralCode: string;
  createdAt: string;
};

export type TransactionView = {
  id: string;
  kind: string;
  amountCents: number;
  description: string;
  createdAt: string;
};

export type RequestView = {
  id: string;
  kind: string;
  amountCents: number;
  status: string;
  method: string;
  reference: string | null;
  createdAt: string;
};

export type AdminRequestView = RequestView & {
  userName: string;
  userEmail: string;
  payoutDetails: string | null;
};

export type LiveRound = {
  id: string;
  game: GameId;
  status: "active" | "cashed_out" | "crashed" | "settled";
  betCents: number;
  payoutCents: number;
  winRate: number;
  startedAt: string;
  serverTime: string;
  multiplierBps: number;
  // A pre-selected crash point is never revealed until the round is over.
  crashMultiplierBps: number | null;
};

export type PlayView = {
  id: string;
  game: string;
  status: string;
  betCents: number;
  payoutCents: number;
  cashoutMultiplierBps: number | null;
  won: boolean;
  createdAt: string;
};

export type DashboardData = {
  user: PublicUser | null;
  content: SiteContent;
  settings: { winRate: number; bankrollCents: number; referralBonusCents: number };
  transactions: TransactionView[];
  requests: RequestView[];
  plays: PlayView[];
  activeRound: LiveRound | null;
  completions: string[];
  referral: { invited: number; earnedCents: number };
  admin: {
    totalPlayers: number;
    totalPlays: number;
    pending: AdminRequestView[];
    recent: AdminRequestView[];
    fundingTotalCents: number;
  } | null;
};

export function formatMoney(cents: number) {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(cents / 100);
}

export function formatDate(value: string) {
  return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric" }).format(new Date(value));
}
