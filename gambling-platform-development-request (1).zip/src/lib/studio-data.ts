import "server-only";
import { and, desc, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  featureRequests, gamePlays, ledgerEntries, platformSettings, siteContent,
  studioAudit, studioInvites, users, walletRequests,
} from "@/db/schema";
import { ensureSettings } from "@/lib/dashboard";
import { reconcileExpiredRounds } from "@/lib/live-games";
import { decryptPrivate, requireStudioUser } from "@/lib/security";
import { getContentRecord } from "@/lib/site-content";
import type { StudioData, StudioPlayer } from "@/lib/studio-types";

export const playerSelection = {
  id: users.id, name: users.name, email: users.email, role: users.role,
  isSuspended: users.isSuspended, balanceCents: users.balanceCents,
  referralCode: users.referralCode, createdAt: users.createdAt,
  playCount: sql<number>`(select count(*)::int from game_plays gp where gp.user_id = ${users.id})`,
  inviteCount: sql<number>`(select count(*)::int from users invited where invited.referred_by = ${users.id})`,
};

export function serializePlayer(row: {
  id: string; name: string; email: string; role: string; isSuspended: boolean;
  balanceCents: number; referralCode: string; createdAt: Date; playCount: number; inviteCount: number;
}): StudioPlayer {
  return { ...row, createdAt: row.createdAt.toISOString() };
}

export async function loadStudioData(): Promise<StudioData> {
  const operator = await requireStudioUser();
  await ensureSettings();
  await reconcileExpiredRounds();
  const [content, settingsRows, playerCount, suspendedCount, playCount, activeCount, pendingCount, deposits, withdrawals, recentRows, requestRows, features, audits, team, invites, activity] = await Promise.all([
    getContentRecord(),
    db.select().from(platformSettings).where(eq(platformSettings.id, 1)).limit(1),
    db.select({ count: sql<number>`count(*)::int` }).from(users).where(eq(users.role, "player")),
    db.select({ count: sql<number>`count(*)::int` }).from(users).where(and(eq(users.role, "player"), eq(users.isSuspended, true))),
    db.select({ count: sql<number>`count(*)::int` }).from(gamePlays),
    db.select({ count: sql<number>`count(*)::int` }).from(gamePlays).where(eq(gamePlays.status, "active")),
    db.select({ count: sql<number>`count(*)::int` }).from(walletRequests).where(eq(walletRequests.status, "pending")),
    db.select({ cents: sql<number>`coalesce(sum(${walletRequests.amountCents}), 0)::int` }).from(walletRequests).where(and(eq(walletRequests.kind, "deposit"), eq(walletRequests.status, "approved"))),
    db.select({ cents: sql<number>`coalesce(sum(${walletRequests.amountCents}), 0)::int` }).from(walletRequests).where(and(eq(walletRequests.kind, "withdrawal"), eq(walletRequests.status, "paid"))),
    db.select(playerSelection).from(users).where(eq(users.role, "player")).orderBy(desc(users.createdAt)).limit(5),
    db.select({ request: walletRequests, userName: users.name, userEmail: users.email })
      .from(walletRequests).innerJoin(users, eq(walletRequests.userId, users.id))
      .orderBy(desc(walletRequests.createdAt)).limit(60),
    db.select().from(featureRequests).orderBy(desc(featureRequests.createdAt)).limit(50),
    db.select({ entry: studioAudit, actorName: users.name }).from(studioAudit)
      .leftJoin(users, eq(studioAudit.actorId, users.id)).orderBy(desc(studioAudit.createdAt)).limit(25),
    db.select({ id: users.id, name: users.name, email: users.email, createdAt: users.createdAt })
      .from(users).where(eq(users.role, "admin")).orderBy(desc(users.createdAt)),
    db.select({ email: studioInvites.email, expiresAt: studioInvites.expiresAt,
      usedAt: studioInvites.usedAt, createdAt: studioInvites.createdAt })
      .from(studioInvites).orderBy(desc(studioInvites.createdAt)).limit(15),
    db.select({ day: sql<string>`to_char(${gamePlays.createdAt} at time zone 'UTC', 'YYYY-MM-DD')`, count: sql<number>`count(*)::int` })
      .from(gamePlays).where(gte(gamePlays.createdAt, new Date(Date.now() - 7 * 86_400_000)))
      .groupBy(sql`to_char(${gamePlays.createdAt} at time zone 'UTC', 'YYYY-MM-DD')`),
  ]);
  const countsByDay = new Map(activity.map((row) => [row.day, row.count]));
  const activitySeries = Array.from({ length: 7 }, (_, index) => {
    const day = new Date(Date.now() - (6 - index) * 86_400_000);
    const key = day.toISOString().slice(0, 10);
    return { label: day.toLocaleDateString("en-US", { weekday: "short", timeZone: "UTC" }), count: countsByDay.get(key) ?? 0 };
  });
  const settings = settingsRows[0];
  return {
    operator: { id: operator.id, name: operator.name, email: operator.email, createdAt: operator.createdAt.toISOString() },
    counts: {
      players: playerCount[0]?.count ?? 0, suspended: suspendedCount[0]?.count ?? 0,
      totalPlays: playCount[0]?.count ?? 0, activeRounds: activeCount[0]?.count ?? 0,
      pending: pendingCount[0]?.count ?? 0,
      depositsCents: deposits[0]?.cents ?? 0, withdrawalsCents: withdrawals[0]?.cents ?? 0,
    },
    activitySeries,
    settings: { winRate: settings.winRate, bankrollCents: settings.bankrollCents, referralBonusCents: settings.referralBonusCents },
    content: {
      draft: content.draft, published: content.published, version: content.version,
      publishedAt: content.publishedAt?.toISOString() ?? null,
      draftUpdatedAt: content.draftUpdatedAt.toISOString(),
    },
    requests: requestRows.map(({ request, userName, userEmail }) => ({
      id: request.id, userId: request.userId, userName, userEmail,
      kind: request.kind, amountCents: request.amountCents,
      status: request.status, method: request.method, reference: request.reference,
      payoutDetails: request.payoutDetails ? decryptPrivate(request.payoutDetails) : null,
      createdAt: request.createdAt.toISOString(),
    })),
    recentPlayers: recentRows.map(serializePlayer),
    features: features.map((item) => ({
      id: item.id, title: item.title, description: item.description,
      priority: item.priority, status: item.status, assistantPlan: item.assistantPlan,
      createdAt: item.createdAt.toISOString(), updatedAt: item.updatedAt.toISOString(),
    })),
    audit: audits.map(({ entry, actorName }) => ({
      id: entry.id, actorName: actorName ?? "System", action: entry.action,
      details: entry.details, createdAt: entry.createdAt.toISOString(),
    })),
    team: team.map((item) => ({ ...item, createdAt: item.createdAt.toISOString() })),
    invites: invites.map((item) => ({ ...item, expiresAt: item.expiresAt.toISOString(),
      usedAt: item.usedAt?.toISOString() ?? null, createdAt: item.createdAt.toISOString() })),
    aiConfigured: Boolean(process.env.OPENAI_API_KEY),
  };
}
