import "server-only";

type AssistantReply = { reply: string; mode: "ai" | "planning" };

function planningGuide(message: string): AssistantReply {
  const lower = message.toLowerCase();
  let area = "the player experience";
  let first = "Sketch the player flow and the operator controls before development.";
  if (/game|aviator|tower|cash.?out|odds/.test(lower)) {
    area = "live games";
    first = "Define the round rules, server-side timing, payout reserves, and what players see before placing a stake.";
  } else if (/wallet|deposit|withdraw|payment|money/.test(lower)) {
    area = "wallet and payments";
    first = "Define the money movement, approval workflow, fraud checks, and an auditable ledger entry for each change.";
  } else if (/question|survey|reward|referral/.test(lower)) {
    area = "rewards";
    first = "Define who qualifies, how often they can earn, and how the prize pool covers every credit.";
  } else if (/profile|account|player|login|security/.test(lower)) {
    area = "accounts and access";
    first = "Define permissions, privacy requirements, abuse protections, and what operators can change.";
  } else if (/design|banner|copy|colour|color|home|content/.test(lower)) {
    area = "website content";
    first = "Check Site editor first: headings, announcement, and activity visibility can already be drafted and published here.";
  }
  return {
    mode: "planning",
    reply: `Planning guide for ${area}\n\n1. ${first}\n2. Turn your request into a short feature specification with acceptance criteria and edge cases.\n3. Review privacy, age restrictions, and gambling/payment compliance if money is involved.\n4. Save it to the Feature lab so development can implement and test it.\n\nSite editor changes can be published immediately. New functionality needs a developer to change code, validate it, and deploy it through your hosting pipeline. Connect OPENAI_API_KEY for conversational AI planning in this workspace.`,
  };
}

export async function planWithAssistant(message: string): Promise<AssistantReply> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return planningGuide(message);
  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        store: false,
        max_output_tokens: 600,
        instructions: "You are a practical product and engineering planning assistant inside Lumi Studio, an admin portal for a real-money games and rewards site built with Next.js and PostgreSQL. Help the operator turn their idea into a concise build plan, concrete acceptance criteria, and appropriate security/compliance considerations. The current site has Aviator and Tower Rush live cash-out games, questionnaires, referrals, manual deposit and withdrawal review, and an editable homepage. Be transparent: you cannot access source code, run deployments, change the site, or guarantee a feature has shipped. Studio's Site editor CAN publish text and activity-visibility changes immediately; code features require developer implementation, testing, and a deployment pipeline. Never suggest bypassing age verification, regulatory review, game fairness, or funded payouts. Do not request player passwords or private payment data. Respond in concise plain text with no markdown tables.",
        input: message,
      }),
      signal: AbortSignal.timeout(20_000),
    });
    if (!response.ok) throw new Error(`Assistant returned ${response.status}`);
    const data = await response.json() as {
      output?: { type?: string; content?: { type?: string; text?: string }[] }[];
    };
    const text = data.output?.flatMap((item) => item.content ?? [])
      .filter((item) => item.type === "output_text" && typeof item.text === "string")
      .map((item) => item.text!.trim()).join("\n").trim();
    if (!text) throw new Error("Assistant returned no text");
    return { mode: "ai", reply: text.slice(0, 4500) };
  } catch (error) {
    console.error("Studio planning assistant unavailable", error);
    const guide = planningGuide(message);
    return { ...guide, reply: `AI service unavailable right now. Here is a non-AI planning guide.\n\n${guide.reply}` };
  }
}
