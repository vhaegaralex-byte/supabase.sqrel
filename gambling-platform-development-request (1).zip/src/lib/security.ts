import "server-only";
import { createCipheriv, createDecipheriv, createHash, randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { cookies } from "next/headers";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, studioSessions, users } from "@/db/schema";

const scrypt = promisify(scryptCallback);
const COOKIE_NAME = "lumi_session";
const STUDIO_COOKIE_NAME = "lumi_studio_session";
const SESSION_DAYS = 30;
const STUDIO_SESSION_DAYS = 7;

export class ActionError extends Error {
  constructor(message: string, public status = 400) {
    super(message);
    this.name = "ActionError";
  }
}

export function fail(message: string, status = 400): never {
  throw new ActionError(message, status);
}

export function handleActionError(error: unknown) {
  if (error instanceof ActionError) {
    return Response.json({ error: error.message }, { status: error.status });
  }
  console.error("An API operation failed", error);
  return Response.json({ error: "Something went wrong. Please try again." }, { status: 500 });
}

export function assertSameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (!origin) return;
  try {
    const originHost = new URL(origin).host;
    const hosts = [request.headers.get("host"), request.headers.get("x-forwarded-host"), new URL(request.url).host];
    if (hosts.includes(originHost)) return;
  } catch {
    // An invalid Origin is not an allowed browser request.
  }
  fail("This request is not allowed.", 403);
}

export function parseCents(value: unknown): number {
  if (typeof value !== "string" && typeof value !== "number") fail("Enter a valid amount.");
  const amount = String(value).trim();
  if (!/^(?:0|[1-9]\d{0,6})(?:\.\d{1,2})?$/.test(amount)) fail("Enter a valid amount with up to two decimals.");
  const [dollars, cents = ""] = amount.split(".");
  return Number(dollars) * 100 + Number(cents.padEnd(2, "0"));
}

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const key = (await scrypt(password, salt, 64)) as Buffer;
  return `${salt}:${key.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string) {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash || !/^[a-f0-9]{128}$/.test(hash)) return false;
  const storedKey = Buffer.from(hash, "hex");
  const key = (await scrypt(password, salt, 64)) as Buffer;
  return timingSafeEqual(storedKey, key);
}

function tokenHash(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

export async function getSessionUser() {
  const cookieStore = await cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const rows = await db
    .select({
      id: users.id,
      email: users.email,
      name: users.name,
      role: users.role,
      balanceCents: users.balanceCents,
      referralCode: users.referralCode,
      ageConfirmed: users.ageConfirmed,
      isSuspended: users.isSuspended,
      createdAt: users.createdAt,
    })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(and(eq(sessions.tokenHash, tokenHash(token)), gt(sessions.expiresAt, new Date())))
    .limit(1);
  const account = rows[0];
  return account && !account.isSuspended ? account : null;
}

export async function getStudioUser() {
  const cookieStore = await cookies();
  const token = cookieStore.get(STUDIO_COOKIE_NAME)?.value;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const rows = await db.select({
    id: users.id, name: users.name, email: users.email, role: users.role,
    isSuspended: users.isSuspended, createdAt: users.createdAt,
  }).from(studioSessions)
    .innerJoin(users, eq(studioSessions.userId, users.id))
    .where(and(eq(studioSessions.tokenHash, tokenHash(token)), gt(studioSessions.expiresAt, new Date())))
    .limit(1);
  const account = rows[0];
  return account?.role === "admin" && !account.isSuspended ? account : null;
}

export async function requireStudioUser() {
  const operator = await getStudioUser();
  if (!operator) fail("Sign in to Studio to continue.", 401);
  return operator;
}

export async function requireUser() {
  const user = await getSessionUser();
  if (!user) fail("Please sign in to continue.", 401);
  return user;
}

export async function requireAdmin() {
  const playerSession = await getSessionUser();
  if (playerSession?.role === "admin") return playerSession;
  const studioSession = await getStudioUser();
  if (studioSession) return studioSession;
  fail("You do not have access to this area.", 403);
}

export async function createStudioSession(userId: string) {
  const token = randomBytes(32).toString("hex");
  await db.insert(studioSessions).values({
    tokenHash: tokenHash(token), userId,
    expiresAt: new Date(Date.now() + STUDIO_SESSION_DAYS * 24 * 60 * 60 * 1000),
  });
  const cookieStore = await cookies();
  cookieStore.set(STUDIO_COOKIE_NAME, token, {
    httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict",
    path: "/", maxAge: STUDIO_SESSION_DAYS * 24 * 60 * 60,
  });
}

export async function deleteStudioSession() {
  const cookieStore = await cookies();
  const token = cookieStore.get(STUDIO_COOKIE_NAME)?.value;
  if (token) await db.delete(studioSessions).where(eq(studioSessions.tokenHash, tokenHash(token)));
  cookieStore.delete(STUDIO_COOKIE_NAME);
}

export async function createSession(userId: string) {
  const token = randomBytes(32).toString("hex");
  await db.insert(sessions).values({
    tokenHash: tokenHash(token),
    userId,
    expiresAt: new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000),
  });
  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/",
    maxAge: SESSION_DAYS * 24 * 60 * 60,
  });
}

export async function deleteSession() {
  const cookieStore = await cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;
  if (token) await db.delete(sessions).where(eq(sessions.tokenHash, tokenHash(token)));
  cookieStore.delete(COOKIE_NAME);
}

function encryptionKey() {
  const secret = process.env.PAYOUT_ENCRYPTION_KEY || process.env.DATABASE_URL;
  if (!secret) throw new Error("PAYOUT_ENCRYPTION_KEY or DATABASE_URL is required");
  return createHash("sha256").update(secret).digest();
}

export function encryptPrivate(value: string) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  return [iv.toString("base64url"), cipher.getAuthTag().toString("base64url"), encrypted.toString("base64url")].join(".");
}

export function decryptPrivate(value: string) {
  try {
    const [iv, tag, data] = value.split(".");
    const decipher = createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(iv, "base64url"));
    decipher.setAuthTag(Buffer.from(tag, "base64url"));
    return Buffer.concat([decipher.update(Buffer.from(data, "base64url")), decipher.final()]).toString("utf8");
  } catch {
    return "Unable to decrypt — check encryption key";
  }
}
