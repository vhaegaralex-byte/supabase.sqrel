import "server-only";
import { and, desc, eq, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import { gamePlays, ledgerEntries, platformSettings, surveyCompletions, users, walletRequests } from "@/db/schema";
import { decryptPrivate, getSessionUser } from "@/lib/security";
import { publicRound, reconcileExpiredRounds } from "@/lib/live-games";
import { getPublishedContent } from "@/lib/site-content";
import type { AdminRequestView, DashboardData } from "@/lib/shared";

export async function ensureSettings() {
  await db.insert(platformSettings).values({ id: 1 }).onConflictDoNothing();
}

export async function loadDashboard(): Promise<DashboardData> {
  await ensureSettings();
  const authenticatedUser = await getSessionUser();
  if (authenticatedUser) {
    await reconcileExpiredRounds(authenticatedUser.role === "admin" ? undefined : authenticatedUser.id);
  }
  const sessionUser = authenticatedUser ? await getSessionUser() : null;
  const [settings, content] = await Promise.all([
    db.select().from(platformSettings).where(eq(platformSettings.id, 1)).limit(1).then((rows) => rows[0]),
    getPublishedContent(),
  ]);

  const result: DashboardData = {
    content,
    user: sessionUser ? {
      id: sessionUser.id,
      email: sessionUser.email,
      name: sessionUser.name,
      role: sessionUser.role,
      balanceCents: sessionUser.balanceCents,
      referralCode: sessionUser.referralCode,
      createdAt: sessionUser.createdAt.toISOString(),
    } : null,
    settings: {
      winRate: settings.winRate,
      bankrollCents: settings.bankrollCents,
      referralBonusCents: settings.referralBonusCents,
    },
    transactions: [],
    requests: [],
    plays: [],
    activeRound: null,
    completions: [],
    referral: { invited: 0, earnedCents: 0 },
    admin: null,
  };

  if (!sessionUser) return result;

  const [transactions, requests, plays, completions, invitedRows, earningsRows] = await Promise.all([
    db.select().from(ledgerEntries)
      .where(and(eq(ledgerEntries.userId, sessionUser.id), ne(ledgerEntries.kind, "bankroll_funding")))
      .orderBy(desc(ledgerEntries.createdAt)).limit(30),
    db.select().from(walletRequests).where(eq(walletRequests.userId, sessionUser.id)).orderBy(desc(walletRequests.createdAt)).limit(25),
    db.select().from(gamePlays).where(eq(gamePlays.userId, sessionUser.id)).orderBy(desc(gamePlays.createdAt)).limit(20),
    db.select({ surveyId: surveyCompletions.surveyId }).from(surveyCompletions).where(eq(surveyCompletions.userId, sessionUser.id)),
    db.select({ count: sql<number>`count(*)::int` }).from(users).where(eq(users.referredBy, sessionUser.id)),
    db.select({ total: sql<number>`coalesce(sum(${ledgerEntries.amountCents}), 0)::int` }).from(ledgerEntries).where(and(eq(ledgerEntries.userId, sessionUser.id), eq(ledgerEntries.kind, "referral"))),
  ]);

  result.transactions = transactions.map((item) => ({
    id: item.id, kind: item.kind, amountCents: item.amountCents,
    description: item.description, createdAt: item.createdAt.toISOString(),
  }));
  result.requests = requests.map((item) => ({
    id: item.id, kind: item.kind, amountCents: item.amountCents,
    status: item.status, method: item.method, reference: item.reference,
    createdAt: item.createdAt.toISOString(),
  }));
  result.plays = plays.map((item) => ({
    id: item.id, game: item.game, status: item.status, betCents: item.betCents,
    payoutCents: item.payoutCents, cashoutMultiplierBps: item.cashoutMultiplierBps,
    won: item.won, createdAt: item.createdAt.toISOString(),
  }));
  const livePlay = plays.find((item) => item.status === "active");
  result.activeRound = livePlay ? publicRound(livePlay) : null;
  result.completions = completions.map((item) => item.surveyId);
  result.referral = { invited: invitedRows[0]?.count ?? 0, earnedCents: earningsRows[0]?.total ?? 0 };

  if (sessionUser.role === "admin") {
    const [pendingRows, recentRows, playersRows, playsRows, fundingRows] = await Promise.all([
      db.select({ request: walletRequests, userName: users.name, userEmail: users.email })
        .from(walletRequests).innerJoin(users, eq(walletRequests.userId, users.id))
        .where(eq(walletRequests.status, "pending")).orderBy(desc(walletRequests.createdAt)).limit(30),
      db.select({ request: walletRequests, userName: users.name, userEmail: users.email })
        .from(walletRequests).innerJoin(users, eq(walletRequests.userId, users.id))
        .where(ne(walletRequests.status, "pending")).orderBy(desc(walletRequests.createdAt)).limit(12),
      db.select({ count: sql<number>`count(*)::int` }).from(users),
      db.select({ count: sql<number>`count(*)::int` }).from(gamePlays),
      db.select({ total: sql<number>`coalesce(sum(${ledgerEntries.amountCents}), 0)::int` }).from(ledgerEntries).where(eq(ledgerEntries.kind, "bankroll_funding")),
    ]);
    const mapRequest = (row: (typeof pendingRows)[number]): AdminRequestView => ({
      id: row.request.id,
      kind: row.request.kind,
      amountCents: row.request.amountCents,
      status: row.request.status,
      method: row.request.method,
      reference: row.request.reference,
      createdAt: row.request.createdAt.toISOString(),
      userName: row.userName,
      userEmail: row.userEmail,
      payoutDetails: row.request.payoutDetails ? decryptPrivate(row.request.payoutDetails) : null,
    });
    result.admin = {
      totalPlayers: playersRows[0]?.count ?? 0,
      totalPlays: playsRows[0]?.count ?? 0,
      pending: pendingRows.map(mapRequest),
      recent: recentRows.map(mapRequest),
      fundingTotalCents: fundingRows[0]?.total ?? 0,
    };
  }

  return result;
}
