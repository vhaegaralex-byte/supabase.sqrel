export type SiteContent = {
  heroEyebrow: string;
  heroTitle: string;
  heroHighlight: string;
  heroDescription: string;
  announcement: string;
  announcementEnabled: boolean;
  aviatorEnabled: boolean;
  towerEnabled: boolean;
  surveysEnabled: boolean;
  referralsEnabled: boolean;
};

export const DEFAULT_SITE_CONTENT: SiteContent = {
  heroEyebrow: "THE GOOD STUFF STARTS HERE",
  heroTitle: "Play your way.",
  heroHighlight: "Enjoy the moment.",
  heroDescription: "Instant games, thoughtful rewards, and a wallet that keeps things clear. It's all yours to explore.",
  announcement: "",
  announcementEnabled: false,
  aviatorEnabled: true,
  towerEnabled: true,
  surveysEnabled: true,
  referralsEnabled: true,
};

export type StudioOperator = { id: string; name: string; email: string; createdAt: string };
export type StudioPlayer = { id: string; name: string; email: string; role: string; isSuspended: boolean; balanceCents: number; referralCode: string; createdAt: string; playCount: number; inviteCount: number };
export type StudioRequest = { id: string; userId: string; userName: string; userEmail: string; kind: string; amountCents: number; status: string; method: string; reference: string | null; payoutDetails: string | null; createdAt: string };
export type StudioFeature = { id: string; title: string; description: string; priority: string; status: string; assistantPlan: string | null; createdAt: string; updatedAt: string };
export type StudioAudit = { id: string; actorName: string; action: string; details: string; createdAt: string };
export type StudioInvite = { email: string; expiresAt: string; usedAt: string | null; createdAt: string };
export type StudioData = {
  operator: StudioOperator;
  counts: { players: number; suspended: number; totalPlays: number; activeRounds: number; pending: number; depositsCents: number; withdrawalsCents: number };
  activitySeries: { label: string; count: number }[];
  settings: { winRate: number; bankrollCents: number; referralBonusCents: number };
  content: { draft: SiteContent; published: SiteContent; version: number; publishedAt: string | null; draftUpdatedAt: string };
  requests: StudioRequest[];
  recentPlayers: StudioPlayer[];
  features: StudioFeature[];
  audit: StudioAudit[];
  team: { id: string; name: string; email: string; createdAt: string }[];
  invites: StudioInvite[];
  aiConfigured: boolean;
};

export type PlayerDetail = {
  player: StudioPlayer;
  ledger: { id: string; kind: string; amountCents: number; description: string; createdAt: string }[];
  requests: { id: string; kind: string; amountCents: number; status: string; createdAt: string }[];
  plays: { id: string; game: string; status: string; betCents: number; payoutCents: number; createdAt: string }[];
};
