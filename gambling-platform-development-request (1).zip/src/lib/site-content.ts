import "server-only";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { siteContent } from "@/db/schema";
import { fail } from "@/lib/security";
import { DEFAULT_SITE_CONTENT, type SiteContent } from "@/lib/studio-types";

export async function ensureSiteContent() {
  await db.insert(siteContent).values({
    id: 1,
    draft: DEFAULT_SITE_CONTENT,
    published: DEFAULT_SITE_CONTENT,
  }).onConflictDoNothing();
}

export async function getContentRecord() {
  await ensureSiteContent();
  const [row] = await db.select().from(siteContent).where(eq(siteContent.id, 1)).limit(1);
  return row;
}

export async function getPublishedContent(): Promise<SiteContent> {
  const row = await getContentRecord();
  return { ...DEFAULT_SITE_CONTENT, ...row.published };
}

export function validateSiteContent(value: unknown): SiteContent {
  if (!value || typeof value !== "object" || Array.isArray(value)) fail("Enter valid site content.");
  const data = value as Record<string, unknown>;
  function text(key: string, max: number, min = 1) {
    const content = data[key];
    if (typeof content !== "string") fail(`Check the ${key} field.`);
    const cleaned = content.trim().replace(/\s+/g, " ");
    if (cleaned.length < min || cleaned.length > max) fail(`${key} must be ${min}–${max} characters.`);
    return cleaned;
  }
  function flag(key: string) {
    if (typeof data[key] !== "boolean") fail(`Choose a value for ${key}.`);
    return data[key] as boolean;
  }
  const content: SiteContent = {
    heroEyebrow: text("heroEyebrow", 65),
    heroTitle: text("heroTitle", 60),
    heroHighlight: text("heroHighlight", 60),
    heroDescription: text("heroDescription", 260, 10),
    announcement: text("announcement", 160, 0),
    announcementEnabled: flag("announcementEnabled"),
    aviatorEnabled: flag("aviatorEnabled"),
    towerEnabled: flag("towerEnabled"),
    surveysEnabled: flag("surveysEnabled"),
    referralsEnabled: flag("referralsEnabled"),
  };
  if (content.announcementEnabled && !content.announcement) fail("Write an announcement before enabling it.");
  return content;
}
