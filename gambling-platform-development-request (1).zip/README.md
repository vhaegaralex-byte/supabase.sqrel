# LumiPlay

A responsive games-and-rewards dashboard built with Next.js App Router, PostgreSQL, and Drizzle ORM.

## What works

- Account registration and sign-in with salted scrypt password hashes and expiring HttpOnly sessions.
- Aviator and Tower Rush are **live cash-out games**: watch the multiplier rise, then cash out before a crash. Free demo rounds run in the browser and have no cash value. Paid crash points are preselected using server-side cryptographic randomness; the server decides cash-outs using its own clock, records the result, and credits the wallet once. A round can crash immediately. Surviving rounds cash out automatically at 3.00× after eight seconds.
- The operator's 1–75% setting is specifically the probability that a round **reaches 1.80×**. Cashing out earlier or later has different odds; no payout is guaranteed. The current setting is displayed before play and snapshotted when a round starts.
- A wallet ledger with manual deposit requests, reserved withdrawal requests, operator approval/decline, and refund on withdrawal decline.
- Operator prize-pool funding records. The full potential 3.00× payout is reserved at the start of each paid round; unused funds are released when it settles. Paid rounds and other rewards are rejected if the pool cannot cover them. An active paid round can be reopened after closing the dialog or reloading the page; expired rounds settle automatically when the dashboard or game service is used.
- Three one-time, non-sensitive questionnaires funded by the prize pool.
- Personal referral codes and a $5 reward after a referred user's first approved deposit of $10 or more, subject to available prize-pool funds. Unpaid qualified rewards are settled when funding is recorded.
- An operator review screen with encrypted payout destinations, request status, activity, and aggregate metrics.

## Local setup

1. Provide `DATABASE_URL` in `.env`.
2. Run `npm install`, then `npx drizzle-kit push` to create the tables.
3. Run `npm run dev`.
4. The first registered account becomes the operator. Before exposing a new installation to the public, set a private `ADMIN_SETUP_CODE` environment variable; the first signup must then enter that code. Set a stable, private `PAYOUT_ENCRYPTION_KEY` as well. If not provided in this sandbox, the payout encryption key is derived from `DATABASE_URL` so the demo remains usable.

## Important payment and compliance limits

This installation **does not connect to a payment processor, charge a card, receive a bank transfer, or send a payout**. A deposit is a request and credits a wallet only after an operator independently verifies external funds. A withdrawal reserves wallet funds; an operator must send the money outside the application before marking it paid. Recording prize-pool funding is an accounting action, not a transfer. Do not approve unverified deposits or record unfunded prize money.

This is a working product prototype, not a guarantee of security, solvency, earnings, or regulatory compliance. Before any public real-money launch, obtain jurisdiction-specific gambling/legal review, licensing, identity and age verification, anti-money-laundering controls, responsible-gaming tools and limits, payment-provider integration, production rate limiting, security testing, monitoring, and an independently reviewed privacy policy. Games involve chance and losses are possible. Adults 18+ only.
